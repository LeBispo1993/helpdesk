import AdminRegistering from "@/app/component/adminRegister";

export default function RegisterAdminComponent() {
    return(
        <AdminRegistering/>
    )
}