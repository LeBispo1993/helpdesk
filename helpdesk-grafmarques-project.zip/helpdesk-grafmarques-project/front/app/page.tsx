import Image from "next/image";

import LoginPage from "./login/page";
import { UserContextProvider } from "./context/userContext";

import './styles/homePage.module.css'

export default function Home() {
  return (
    <>
      <LoginPage/>
    </>
  );
}
