export default interface APIResponse {
    status: number,
    response:any
}