import Role from "../enum/Role"

export default interface User {
    id?: string
    name: string
    sector: {id:string, name:string}
    email: string
    createdAt?: string
    active?: boolean|string
    role?: Role
    password? :string
}