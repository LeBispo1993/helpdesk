export default interface Comment {
    user: {name: string, id: string},
    createdAt: string
    content: string
}