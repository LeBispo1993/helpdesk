interface NotificationTicket {
    id: string,
    os: number
}

export default interface Notification {
    id:string
    content:string
    ticket?:NotificationTicket
    viewed:boolean
    createdAt:string
}