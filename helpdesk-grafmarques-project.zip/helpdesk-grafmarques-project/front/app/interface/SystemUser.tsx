export default interface SystemUser {
    role: string|null,
    userID: string|null
    jwtToken: string|null,
    currentPage: string|null
}