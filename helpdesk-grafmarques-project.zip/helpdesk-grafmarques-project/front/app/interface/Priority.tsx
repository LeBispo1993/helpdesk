export default interface Priority {
    priority: Array<"BAIXA"|"MÉDIA"|"ALTA"|"AGENDAMENTO"|null>
}