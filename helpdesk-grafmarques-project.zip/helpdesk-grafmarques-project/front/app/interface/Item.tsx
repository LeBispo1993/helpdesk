export default interface Item {
    name: string
    id: string
    createdAt?: string
    active?:string
    sector?:boolean
    server?:boolean
}
