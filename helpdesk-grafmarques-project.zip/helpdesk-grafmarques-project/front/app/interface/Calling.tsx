import Comment from "./Comment"
import Sector from "./Sector"

export default interface Calling {
    id:string,
    os:string,
    title: string,
    agent?: {name: string, id: string, sector: Sector},
    author: {id:string, name:string},
    applicant: string,
    sector: {id:string, name:string},
    category: {id:string, name:string},
    status:"ABERTO"|"PROCESSANDO"|"FECHADO"
    priority: "ALTA"|"MÉDIA"|"BAIXA",
    description: string,
    createdAt: string,
    updatedAt: string,
    assignedAt?: string,
    closedAt?: string,
    comments?: Array<Comment>
    active?: boolean
}