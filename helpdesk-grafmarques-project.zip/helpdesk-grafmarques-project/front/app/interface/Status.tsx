export default interface Status {
    status: Array<"ABERTO"|"FECHADO"|"PROCESSANDO"|null>
}