import Category from "./Category"
import Item from "./Item"
import Priority from "./Priority"
import Status from "./Status"

export default interface Filter {
    status: Status,
    priority: Priority,
    category: Item[],
    dateFrom: Date|string,
    dateUntil: Date|string
}