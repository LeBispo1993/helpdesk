export default interface Sector {
    id: string,
    name: string
}