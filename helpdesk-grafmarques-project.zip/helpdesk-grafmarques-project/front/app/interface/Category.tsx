export default interface Category {
    category: Array<string|null>
}