export default interface SplittedDate {
    month: string,
    day: string,
    year: string
}