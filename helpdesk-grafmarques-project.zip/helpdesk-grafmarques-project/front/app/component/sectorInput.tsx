import Image from "next/image"
import arrow_icon from '../../public/arrow_icon.svg'

import { Dispatch, SetStateAction } from "react"
import Item from "../interface/Item"

interface SectorProps {
    style: any
    setShowSector: Dispatch<SetStateAction<boolean>>,
    showSector: boolean
    getAllSectorsHandler: () => {},
    setSelectedSector: Dispatch<SetStateAction<Item>>
    selectedSector: Item,
    allSectors: Item[]
}

export default function SectorInput(props: SectorProps) {
    
    return(
        <div 
            className={`flex gap-4 md:w-[40%] items-center relative ${props.style.label_and_input}`}>

            <label htmlFor="setor" className='md:10rem'>
                <p className={`w-20 ${props.style.setor_p} font-bahnscrift_bold`}>Setor: <span className='text-[#DD1D8B]'>*</span></p>
            </label>

            <Image
                onClick={() => {props.setShowSector((prev: any) => !prev),
                    props.getAllSectorsHandler()}}
                src={arrow_icon}
                className={`${props.showSector ? null : 'rotate-180'} bg-white py-1 ] absolute right-2 hover:cursor-pointer z-30`}
                alt={"ícone_seta"}
                
            />

            <div className='w-[100%] relative'>
                
                <input 
                    readOnly={true}
                    onClick={() => {props.setShowSector((prev:any) => !prev),
                        props.getAllSectorsHandler()
                    }}
                    type="text" 
                    name="setor" 
                    id={props.selectedSector.id} 
                    value={props.selectedSector.name}
                    contentEditable={false}
                    className={`${props.style.sector_input} w-[100%] select-none px-5 z-10 ${props.selectedSector.name == 'Setor' ? 'text-[grey]' : null} hover:cursor-pointer`}
                />

                <div className={`${props.style.status_options} ${!props.showSector ? props.style.not_show_options : props.style.show_options} z-40 -mt-1 rounded-md grid gap-3 absolute w-[100%] h-[auto] bg-white pt-2 text-[#626262] select-none right-0 border-2 border-opacity-60 border-[#959595]`}>
                
                
                    {props.allSectors.map((element: any) => (
                        <p 
                            key={element.id}
                            onClick={(p) => {props.setSelectedSector(element), 
                                props.setShowSector(false)
                            }}
                            id={element.id} 
                            className={`text-center ${!props.showSector ? 'opacity-0' : null} hover:cursor-pointer`}>
                            
                            {element.name}
                        </p>
                    ))}

                </div>
                                    
            </div>
                                    
        </div>
    )
}