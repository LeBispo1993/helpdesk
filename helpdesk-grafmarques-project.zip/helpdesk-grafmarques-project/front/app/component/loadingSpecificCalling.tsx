import style from '../styles/callingDetails.module.css'

export default function LoadingSpecificCalling() {
    return(

        <div className={`${style.calling_box} relative`}>
                    

                        <h1 className={`${style.calling_title} font-bahnscrift_bold text-xl bg-slate-300  h-6 animate-pulse`}></h1>

                        <div className={`flex md:justify-between mt-5 sm:justify-center ${style.upper_info}`}>

                            <p className='bg-slate-300 w-24 h-4 animate-pulse'></p>

                            <p className='bg-slate-300 w-24 h-4 animate-pulse'></p>

                        </div>

                        <hr 
                            className='mt-4'
                        />

                        <div className={`${style.more_details} mt-5`}>

                            <div className='flex gap-5 w-[90%] justify-center flex-wrap'>
                                <p className='bg-slate-300 w-24 h-4 animate-pulse'></p>
                                <p className='bg-slate-300 w-24 h-4 animate-pulse'></p>
                                <p className='bg-slate-300 w-24 h-4 animate-pulse'></p>
                                <p className='bg-slate-300 w-24 h-4 animate-pulse'></p>
                            </div>

                            <div className='flex gap-20 w-[90%] justify-center flex-wrap mt-12'>
                                <p className='bg-slate-300 w-24 h-4 animate-pulse'></p>
                                <p className='bg-slate-300 w-24 h-4 animate-pulse'></p>
                            </div>

                        </div>

                        <p className='bg-slate-300 w-24 h-6 mt-12 animate-pulse'></p>
                        <textarea
                            readOnly={true}
                            maxLength={500}
                            className='bg-slate-300 animate-pulse focus:outline-none resize-none px-4 py-2 text-left w-[100%] mx-auto mt-2 rounded-md h-60'
                        />

                        <p className='bg-slate-300 w-40 h-6 mt-4 animate-pulse'></p>


                        <div className={`flex justify-end gap-8 ${style.last_buttons}`}>

                            <p className='bg-slate-300 w-40 h-6 mt-4 animate-pulse'></p>
                        
                            <p className='bg-slate-300 w-40 h-6 mt-4 animate-pulse'></p>

                        </div>

                </div>

    )
}