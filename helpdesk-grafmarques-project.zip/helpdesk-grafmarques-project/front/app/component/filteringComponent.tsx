'use client'

import arrow_icon from '../../public/arrow_icon.svg'

import { useState, useEffect, Dispatch, SetStateAction, useContext } from 'react'

import Image from 'next/image';

import UserContext from '../context/userContext';

import Filter from '@/app/interface/Filter';
import Status from '@/app/interface/Status';
import Priority from '@/app/interface/Priority';
import Category from '@/app/interface/Category';

import sendGridData from '@/app/functions/sendGridData';

import style from '../styles/filteringComponent.module.css'
import APIResponse from '../interface/ApiResponse';
import moment from 'moment';
import Item from '../interface/Item';
import { getAllCategories } from '../functions/category';
import { removeListener } from 'process';

interface ParentScreen {
    setFilter: Dispatch<SetStateAction<Filter | null | undefined>>
}

export default function FilteringComponent({setFilter}: ParentScreen) {

    const userSystemContext = useContext(UserContext)

    const todayDate = moment().format("YYYY-MM-DD")
    const lastWeekDate = moment().subtract(7, 'days').format("YYYY-MM-DD")

    const defaultFilter: Filter = {
        status: {status: [null]},
        category: [{id: "0", name: "Tudo"}],
        priority: {priority: [null]},
        dateFrom: lastWeekDate,
        dateUntil: todayDate
    }

    const [showStatusOptions, setShowStatusOptions]     = useState<boolean>(false)
    const [showPriorityOptions, setShowPriorityOptions] = useState<boolean>(false)
    const [showCategoryOptions, setShowCategoryOptions] = useState<boolean>(false)

    const [dateFrom, setDateFrom]                       = useState<Date|string>(lastWeekDate)
    const [dateUntil, setDateUntil]                     = useState<Date|string>(todayDate)
    const [statusState, setStatusState]                 = useState<Status>({status: [null]})
    const [priorityState, setPriorityState]             = useState<Priority>({priority: [null]})
    const [categoryState, setCategoryState]             = useState<Array<Item>>([{id: "0", name: "Tudo"}])

    const [allCategories, setAllCategories]             = useState<Item[]>([{id: "0", name: "Tudo"}, {id: "1", name: "---"}])

    const [generalFilter, setGeneralFilter]             = useState<any>(defaultFilter)
    const [applyButton, setApplyButton]                 = useState<boolean>(false)


    async function getAllCategoryHandler() {
        if(JSON.stringify(allCategories) == '[{"id":"0","name":"Tudo"},{"id":"1","name":"---"}]') {
            const allCategories:APIResponse = await getAllCategories(userSystemContext.systemUser.jwtToken)
            const categoryList:Array<Item> = allCategories.response.map((element: Item) => {
                return(
                    {
                        id: element.id,
                        name: element.name
                    }
                )
            })
            setAllCategories((prev:any) => {
                return([prev[0], ...categoryList])
            })
        }
    }

    const onHandleToggleStatusOptions = () => {
        setShowStatusOptions((prevState) => {
            return !prevState
        })
    }

    const onHandleTogglePriorityOptions = () => {
        setShowPriorityOptions((prevState) => {
            return !prevState
        })
    }

    const onHandleToggleCategoryOptions = () => {
        setShowCategoryOptions((prevState) => {
            return !prevState
        })
    }

    const onHandleShowFilters = () => {
        if(applyButton) {
            setApplyButton(false)
            setGeneralFilter(
                {
                    category: categoryState,
                    dateFrom: dateFrom,
                    dateUntil: dateUntil,
                    priority: priorityState,
                    status: statusState
                }
            )
            setFilter(
                {
                    category: categoryState,
                    dateFrom: dateFrom,
                    dateUntil: dateUntil,
                    priority: priorityState,
                    status: statusState
                }
            )
        }
    }


    const onHandleChangeGeneralState = (whichFilter:"status"|"priority"|"category", filter:any) => {

        const generalStatus: Status = generalFilter.status
        const generalCategory: Category = generalFilter.category
        const generalPriority: Priority = generalFilter.priority

        if(whichFilter == "status") {

            const status: any = filter?.toUpperCase()
            let removeElement: boolean = false
            const statusStateLength: number = statusState.status.length
            
            statusState.status.forEach((element) => {
                if(element == status) {
                    removeElement = true
                }
            })

            if(filter == null) {
                setStatusState({status: [null]})
            }
            else if(statusStateLength == 1 && removeElement) {
                
                setStatusState({status: [null]})
            }else if(removeElement) {

                const splicedStatus = statusState.status.filter(element => element !== status)
                setStatusState({status: [...splicedStatus]})
            } else if(!removeElement && statusStateLength == 1 && statusState.status[0] == null) {

                setStatusState({status: [status]})
            } else {
                setStatusState({status: [...statusState.status, status]})
            }

        }

        else if(whichFilter == "priority") {

            const priority: any = filter?.toUpperCase()
            let removeElement: boolean = false
            const priorityStateLength: number = priorityState.priority.length
            
            priorityState.priority.forEach((element) => {
                if(element == priority) {
                    removeElement = true
                }
            })

            if(filter == null) {
                setPriorityState({priority: [null]})
            }
            else if(priorityStateLength == 1 && removeElement) {            

                setPriorityState({priority: [null]})
            }else if(removeElement) {

                const splicedPriority = priorityState.priority.filter(element => element !== priority)
                setPriorityState({priority: [...splicedPriority]})
            } else if(!removeElement && priorityStateLength == 1 && priorityState.priority[0] == null) {
                 
                setPriorityState({priority: [priority]})
            }
            else {
                setPriorityState({priority: [...priorityState.priority, priority]})
            }

        }
        else if(whichFilter == "category"){

            const category: any = filter.name.toUpperCase()
            let removeElement: boolean = false
            const categoryStateLength: number = categoryState.length

            
            categoryState.forEach((element, i) => {


                if(element.name.toUpperCase() == category) {
                    removeElement = true
                }
            })


            let filterItems: Item[] = []
            filterItems.push(filter)


            if(category == null || category == "TUDO") {
                setCategoryState([{id: "0", name: "Tudo"}])
            }
            else if(categoryStateLength == 1 && removeElement) {            
                setCategoryState([{id: "0", name: "Tudo"}])
            }else if(removeElement) {
                const splicedCategory = categoryState.filter((element) => element.name.toUpperCase() !== category)

                setCategoryState([...splicedCategory])
            } else if(!removeElement && categoryStateLength == 1 && categoryState[0].name.toUpperCase() == "TUDO") {
                setCategoryState([{id: filter.id, name: filter.name}])
            } else {
                setCategoryState((prev: any) => {
                    return([...prev, ...filterItems])
                })
            }

        }
    }
    

    function compareArrayOfObjects(arr1: Array<any>, arr2: Array<any>) {
        return JSON.stringify(arr1) === JSON.stringify(arr2)
    }

    useEffect(() => {

        const compareGeneralToStatus    = compareArrayOfObjects(statusState.status, generalFilter.status.status)
        const compareGeneralToPriority  = compareArrayOfObjects(priorityState.priority, generalFilter.priority.priority)
        const compareGeneralToCategory  = compareArrayOfObjects(categoryState, generalFilter.category)
        const compareGeneralToDateUntil = dateUntil == generalFilter.dateUntil
        const compareGeneralToDateFrom = dateFrom == generalFilter.dateFrom

       if(compareGeneralToCategory == false || compareGeneralToPriority == false || compareGeneralToStatus == false
         || compareGeneralToDateUntil == false || compareGeneralToDateFrom == false) {
            setApplyButton(true)
       } else {
            setApplyButton(false)
       }

    }, [statusState, priorityState, categoryState, dateFrom, dateUntil])

    return(
        <div className={`${style.filtering_box}`}>

                    <div className={`font-bahnscrift_bold text-center bg-white rounded-md w-fit m-auto p-[2rem] flex mt-5 shadow-lg shadow-gray-500 z-100 gap-7`}>

                        <div className={`w-fit`}>

                            <div onClick={onHandleToggleStatusOptions} 
                                 className='flex justify-center hover:cursor-pointer'>

                                <h2
                                    className={`text-[#181818] relativ select-none`}>
                                    Status
                                </h2>

                                <Image
                                    src={arrow_icon}
                                    className={`${showStatusOptions ? null : 'rotate-180'} ml-2`}
                                    alt={"ícone_seta"}
                                />

                            </div>
                            
                            <div className={`${style.status_options} ${!showStatusOptions ? style.not_show_options : style.show_options} mt-2 rounded-md grid gap-3 absolute -ml-3 bg-white text-[#626262] z-50 select-none`}>
                                <hr />
                                <p 
                                    onClick={() => {onHandleChangeGeneralState("status",  null)}
                                    }
                                    className={`hover:cursor-pointer hover:text-[#181818] ${statusState.status[0] == null && statusState.status.length == 1 ? 'text-[#181818] underline' : null} `}>{statusState.status[0] == null && statusState.status.length == 1 ? '>' : null}Tudo</p>
                                <p 
                                    onClick={() => {onHandleChangeGeneralState("status", "aberto")}
                                    }
                                    className={`hover:cursor-pointer hover:text-[#181818] ${statusState.status.includes("ABERTO") ? 'text-[#181818] underline' : null} `}>{statusState.status.includes("ABERTO") ? '>' : null}Aberto</p>
                                <p 
                                    onClick={() => {onHandleChangeGeneralState("status", "processando")}
                                    }
                                    className={`hover:cursor-pointer hover:text-[#181818] ${statusState.status.includes("PROCESSANDO") ? 'text-[#181818] underline' : null}`}>{statusState.status.includes("PROCESSANDO") ? '>' : null}Processando</p>
                                <p 
                                    onClick={() => {onHandleChangeGeneralState("status", "fechado")}
                                    }
                                    className={`hover:cursor-pointer hover:text-[#181818] ${statusState.status.includes("FECHADO") ? 'text-[#181818] underline' : null}`}>{statusState.status.includes("FECHADO") ? '>' : null}Fechado</p>
                            </div>

                        </div>
                                
                        <div className={`w-fit`}>

                            <div onClick={onHandleTogglePriorityOptions} 
                                 className='select-none flex justify-center hover:cursor-pointer'>
                                <h2
                                 className={`text-[#181818] select-none`}>
                                    Prioridade
                                </h2>

                                <Image
                                    src={arrow_icon}
                                    className={`${showPriorityOptions ? null : 'rotate-180'} ml-2`}
                                    alt={"ícone_seta"}
                                />
                            </div>

                            <div className={`${style.status_options} ${!showPriorityOptions ? style.not_show_options : style.show_options} mt-2 rounded-md grid gap-3 absolute -ml-[.2rem] bg-white text-[#626262] z-50 select-none`}>
                                <hr />

                                <div 
                                    onClick={() => {onHandleChangeGeneralState("priority", null)
                                    }}
                                    className='flex justify-center'>
                                    <p className={`hover:cursor-pointer hover:text-[#181818] ${priorityState.priority[0] == null && priorityState.priority.length == 1? 'text-[#181818] underline' : null}`}>{priorityState.priority[0] == null && priorityState.priority.length == 1 ? '>' : null}Tudo</p>
                                </div>

                                <div 
                                    onClick={() => {onHandleChangeGeneralState("priority", "baixa")
                                    }}
                                    className='flex justify-center'>
                                    <p className={`hover:cursor-pointer hover:text-[#181818] ${priorityState.priority.includes("BAIXA") ? 'text-[#181818] underline' : null}`}>{priorityState.priority.includes("BAIXA") ? '>' : null}Baixa</p>
                                    <span className={`bg-green-500 w-2 h-2 absolute ml-14 animate-pulse rounded-lg`}/>
                                </div>
                                
                                <div 
                                    onClick={() => {onHandleChangeGeneralState("priority", "média")
                                    }}
                                    className='flex justify-center'>
                                    <p className={`hover:cursor-pointer hover:text-[#181818] ${priorityState.priority.includes("MÉDIA") ? 'text-[#181818] underline' : null}`}>{priorityState.priority.includes("MÉDIA") ? '>' : null}Média</p>
                                    <span className={`bg-yellow-500 w-2 h-2 absolute ml-14 animate-pulse rounded-lg`}/>
                                </div>

                                <div 
                                    onClick={() => {onHandleChangeGeneralState("priority", "alta")
                                    }}
                                    className='flex justify-center'>
                                    <p className={`hover:cursor-pointer hover:text-[#181818] ${priorityState.priority.includes("ALTA") ? 'text-[#181818] underline' : null}`}>{priorityState.priority.includes("ALTA") ? '>' : null}Alta</p>
                                    <span className={`bg-red-500 w-2 h-2 absolute ml-12 animate-pulse rounded-lg`}/>
                                </div>
                                

                                <div 
                                    onClick={() => {onHandleChangeGeneralState("priority", "agendamento")
                                    }}
                                    className='flex justify-center'>
                                    <p className={`hover:cursor-pointer hover:text-[#181818] ${priorityState.priority.includes("AGENDAMENTO") ? 'text-[#181818] underline' : null}`}>{priorityState.priority.includes("AGENDAMENTO") ? '>' : null}Agendamento</p>
                                    <span className={`bg-blue-500 w-2 h-2 absolute ml-28 animate-pulse rounded-lg`}/>
                                </div>
                                
                            </div>

                        </div>
                                
                        <div className={`w-fit`}>
                                
                            <div onClick={() => {getAllCategoryHandler(),
                            onHandleToggleCategoryOptions()}} 
                                 className='select-none flex justify-center hover:cursor-pointer'>
                                
                                <h2
                                 className={`text-[#181818] select-none`}>
                                    Categoria
                                </h2>

                                <Image
                                    src={arrow_icon}
                                    className={`${showCategoryOptions ? null : 'rotate-180'} ml-2`}
                                    alt={"ícone_seta"}
                                />

                            </div>

                            <div className={`${style.status_options} ${!showCategoryOptions ? style.not_show_options : style.show_options} mt-2 rounded-md grid gap-3 absolute -ml-4 bg-white pb-[10rem]  text-[#626262] z-50 outline-black outline-2 select-none`}>
                                <hr />
                                {allCategories.map((element) => (
                                        <p 
                                            onClick={() => onHandleChangeGeneralState("category", {name: element.name, id: element.id})}
                                            key={element.name}
                                            id={element.id} 
                                            className={`text-center ${categoryState.find((item: Item) => item.id == element.id) == undefined ? null : 'text-[#181818] underline'} 
                                            ${categoryState[0].name == "Tudo" && element.name == "Tudo" ? 'text-[#181818] underline' : null} hover:cursor-pointer`}>
                                                
                                            {categoryState.find((item: Item) => item.id === element.id) == undefined ? element.name : '> ' + element.name}
                                        </p>
                                    ))}
                            </div>

                        </div>

                    </div>

                    <div className={`font-bahnscrift_bold text-center bg-white rounded-md w-fit m-auto p-[1rem] flex mt-5 items-center shadow-lg shadow-gray-500`}> 

                        <div
                            className='flex justify-center ml-3'>

                            <h2
                                className={`text-[#181818] relativ select-none`}>
                                Data de:
                            </h2>

                            <input 
                                max={todayDate}
                                defaultValue={lastWeekDate}
                                onChange={(ev) => {
                                    setDateFrom(ev.target.value)
                                }}
                                className='hover:cursor-pointer outline-none pr-3 ml-1 -mt-[.03rem] w-[8.2rem]' type="date" name="" id="" />

                        </div>

                        <div
                            className='flex justify-center'>

                            <h2
                                className={`text-[#181818] relativ select-none`}>
                                Data até:
                            </h2>

                            <input
                                max={todayDate}
                                defaultValue={todayDate}
                                onChange={(ev) => {
                                    setDateUntil(ev.target.value)
                                }}
                                className={`${style.date_until} hover:cursor-pointer outline-none pr-3 ml-1 -mt-[.05rem] w-[8.2rem]`} type="date" name="" id="" />

                        </div>

                    </div>

                    <h1
                        onClick={onHandleShowFilters}
                        className={`${style.apply_button}
                        ${applyButton ? 'bg-[#8BCB1A] border-[#8BCB1A] font-bold hover:cursor-pointer' : 'text-white'}
                        select-none font-bahnscrift_regular rounded-lg text-white text-center my-5 px-7 py-2 mx-auto border-2 w-fit`}>
                        APLICAR
                    </h1>

                </div>
    )
}