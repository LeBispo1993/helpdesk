'use state'

import styles from '../styles/pagination.module.css'

import { JSX } from 'react/jsx-runtime'

import { Dispatch, SetStateAction, useState, useEffect } from 'react'

interface Pages {
    pages: number
    currentPage: number
    setCurrentPage: Dispatch<SetStateAction<number>>
}

export default function PaginationComponent({pages, currentPage, setCurrentPage}: Pages) {

    let field: JSX.Element[] = [];

    for (let i = 1; i <= pages; i++) {

        if(pages == 1) {
            return
        }

        if(i === 1) {
            field.push(<p
                onClick={() => currentPage > 1 ? setCurrentPage(currentPage - 1) : null} 
                className={`hover:cursor-pointer select-none`}>{"<"}</p>)
        }

        if(i <= 4) {
            field.push(<p 
                            onClick={() => setCurrentPage(i)}
                            className={`hover:cursor-pointer select-none ${i == currentPage ? 'text-[#8BCB1A]' : null}`}>{i}</p>)
        } else if(i == 5) {
            field.push(<p className={`hover:cursor-pointer select-none`}>...</p>)
        } 

        if(i === pages) {
            field.push(<p 
                onClick={() => i <= pages ? setCurrentPage(currentPage + 1) : null} 
                className={`hover:cursor-pointer select-none`}>{">"}</p>)
        }
    }


    return(
        <div className={`flex gap-2 text-md m-auto justify-center w-full`}>
            {field}
        </div>
    )
}