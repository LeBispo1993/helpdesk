'use client'

import grayProfileIcon from '../../public/gray_profile_icon.svg'
import closeIcon from '../../public/close_icon.svg'

import Image from 'next/image'
import { useRouter } from 'next/navigation'

import style from '../styles/profile.module.css'
import sectorInputStyle from '../styles/itemRegister.module.css'

import User from '@/app/interface/User'

import { CiRead } from "react-icons/ci";
import { CiUnread } from "react-icons/ci";

import { useState, useEffect, useContext, Dispatch, SetStateAction } from 'react'

import UserContext from '@/app/context/userContext'
import { editUser, getUserByID } from '@/app/functions/user'
import SectorInput from './sectorInput'
import Item from '../interface/Item'
import APIResponse from '../interface/ApiResponse'
import { getAllSectors } from '../functions/sector'
import PopupMessage from './popupMessage'
import PopupContext from '../context/popupMessageContext'
import ItemRegister from './itemRegister'
import Where from '../enum/Where'
import RoleInput from './roleInput'
import Role from '../enum/Role'

interface AdminProps {
    userID?: string
    profileScreen?: Dispatch<SetStateAction<boolean>>,
    setOperationDone: Dispatch<SetStateAction<boolean>>
}

export default function UserProfile({userID, profileScreen, setOperationDone}: AdminProps) {

    const router = useRouter()
    const systemUserContext = useContext(UserContext)
    const popupContext      = useContext(PopupContext)

    const [user, setUser] = useState<User>({
        id: "---",
        email: "-----",
        name: "------",
        sector: {id:"0", name: "----"}
    })

    const [showRole, setShowRole]               = useState(false)
    const [selectedRole, setSelectedRole]       = useState<Role|any>("---")
        
    const [showSector, setShowSector]           = useState(false)
    const [allSectors, setAllSectors]           = useState<Item[]>([{id: "0", name: "----"}])
    const [selectedSector, setSelectedSector]   = useState<Item>({id:"0", name:"Setor"})

    const [newName, setNewName]                 = useState<string>("")
    const [newEmail, setNewEmail]               = useState<string>("")
    const [newPassword, setNewPassword]         = useState<string>("")

    const [pwdScreen, setPwdScreen]             = useState<boolean>(false)
    
    async function getAllSectorsHandler() {
        if(JSON.stringify(allSectors) == '[{"id":"0","name":"----"}]') {

            const sectorResponse:APIResponse = await getAllSectors(systemUserContext.systemUser.jwtToken)

            const sectorList:Array<Item> = sectorResponse.response.map((element: Item) => {
                return(
                    {
                        id: element.id,
                        name: element.name
                    }
                )
            })
            setAllSectors(sectorList)
        }
    }

    async function editUserHandler() {

        let updatedUser: User = {
            id: user.id,
            name: user.name,
            email: user.email,
            sector: {name: user.sector.name, id: user.sector.id},
            role: selectedRole
        }

        if(newName.trim() !== "") {
            updatedUser.name = newName
        }

        if(newEmail.trim() !== "") {
            updatedUser.email = newEmail
        }

        if(selectedSector.id !== "0") {
            updatedUser.sector = selectedSector
        }

        if(newPassword.trim() !== "") {
            updatedUser.password = newPassword
        }

        const result: APIResponse = await editUser(systemUserContext.systemUser.jwtToken, updatedUser)

        if(result.status == 200) {
            popupContext.setSuccessMessage("Usuário editado com sucesso")
            popupContext.setShowSuccess(true)
            if(setOperationDone) {
                setOperationDone((prev) => {
                    return !prev
                })
            }
            backToLastPage()

        } else {
            popupContext.setErrorMessage(result.response.title)
            popupContext.setShowError(true)
        }

    }

    function backToLastPage() {

        if(!userID) {
            let lastPage = systemUserContext.systemUser.currentPage
            if(lastPage == "perfil") {
                lastPage = 'home'
            }
            router.push(`/main/${lastPage}`)
        } else {
            profileScreen ? profileScreen(false) : null
        }
    }

    async function getCurrentUser() {

        let currentUserID: string|null

        if(!userID) {
            currentUserID = systemUserContext.getUserID()
        } else {
            currentUserID = userID
        }

        const jwtToken: string|null = systemUserContext.getStorageToken()
    
        const result = await getUserByID(jwtToken, currentUserID)

        if(result.status == 200) {
            setUser(
                {
                    email: result.response.email,
                    name: result.response.name,
                    sector: result.response.sector,
                    id: result.response.id
                }
            )

            let userRole: string
            if(result.response.role == "AGENT") {
                userRole = "Agente"
            } else if(result.response.role == "ADMIN") {
                userRole = "Admin"
            } else {
                userRole = "Usuário"
            }
            
            setSelectedRole(userRole)
        }

        if(userID) {
            setSelectedSector({id: "0", name: result.response.sector.name})
        }
        
    }

    useEffect(() => {
        getCurrentUser()

        !userID ? systemUserContext.setCurrentPage("perfil") : null
    }, [])

    return(
        <div className={`${style.container}`}>

            <PopupMessage/>

            {pwdScreen
                ?
                    <ItemRegister
                        itemA={{field: "Senha atual", placeholder: "Senha"}}
                        itemB={{field: "Nova senha", placeholder: "Confirme sua senha"}}
                        setOperationDone={setOperationDone}
                        where={Where.profile}
                        setRegisterScreen={setPwdScreen}
                    />
                :
                    null
                }
            
            <div className={`${style.profile_box}`}>

                <div className={`${style.profile_box_header} relative`}>

                    <Image
                        width={50}
                        alt='ícone_perifl'
                        src={grayProfileIcon}
                    />

                    <h1 className='font-bahnscrift_bold text-xl'>Tela de usuário</h1>

                    <div className={`flex absolute right-0 top-0 gap-5 ${style.top_icons}`}>

                        {userID
                            ?
                                <button 
                                    onClick={() => editUserHandler()}
                                    className=' text-[#8BCB1A] border-solid border-[.1rem] border-[#8BCB1A] px-2 rounded-md hover:bg-[#8BCB1A] hover:text-[white]'>
                                    SALVAR
                                </button>
                            :
                                null
                            }

                        <Image
                            alt="ícone_fechar"
                            src={closeIcon}
                            width={20}
                            className='hover:cursor-pointer'
                            onClick={backToLastPage}
                        />

                    </div>

                </div>

                <div className={`${style.profile_data}`}>

                    <div className='flex gap-7 items-center'>
                        <p className='font-bahnscrift_bold'>Nome:</p>
                        <input 
                            onChange={(ev) => {
                                setNewName(ev.target.value)
                            }}
                            placeholder={`${user.name}`}
                            readOnly={!userID ? true : false}
                            type="text"
                            value={!userID ? user.name : undefined}
                            className={`${style.dynamic_value} placeholder:text-black`}
                        />
                    </div>

                        {!userID 
                            ?
                            <div className='flex gap-7 items-center'>
                                <p className='font-bahnscrift_bold'>Setor:</p>
                                <input 
                                    placeholder={`${user.sector.name}`}
                                    readOnly={!userID ? true : false}
                                    type="text"
                                    value={!userID ? user.sector.name : undefined}
                                    className={`${style.dynamic_value} placeholder:text-black`}
                                />
                                </div>
                            :
                                <SectorInput
                                    allSectors={allSectors}
                                    getAllSectorsHandler={getAllSectorsHandler}
                                    selectedSector={selectedSector}
                                    setSelectedSector={setSelectedSector}
                                    setShowSector={setShowSector}
                                    showSector={showSector}
                                    style={style}
                                />
                            }

                            {userID 
                                ?
                                    <RoleInput
                                        setShowRole={setShowRole}
                                        selectedRole={selectedRole}
                                        setSelectedRole={setSelectedRole}
                                        showRole={showRole}
                                        style={style}
                                    />
                                : 
                                    null
                            }

                    <div className='flex gap-7 items-center'>
                        <p className='font-bahnscrift_bold'>Email:</p>
                        <input
                            onChange={(ev) => {
                                setNewEmail(ev.target.value)
                            }}
                            placeholder={`${user.email}`}
                            readOnly={!userID ? true : false}
                            type="text"
                            value={!userID ? user.email : undefined}
                            className={`${style.dynamic_value} placeholder:text-black`}
                        />
                    </div>

                    {userID 
                        ?
                            <div className='flex gap-7 items-center'>
                                <p className='font-bahnscrift_bold'>Senha:</p>
                                <input
                                    onChange={(ev) => {
                                        setNewPassword(ev.target.value)
                                    }}
                                    placeholder={`*****`}
                                    readOnly={!userID ? true : false}
                                    type="text"
                                    className={`${style.dynamic_value} placeholder:text-black`}
                                />
                            </div>
                    
                        :
                            null
                    }
                    
                    {!userID 
                        ?
                            <div
                            className='flex gap-7 items-center relative w-fit'>

                                <button
                                     onClick={() => setPwdScreen(true)}
                                    className='border-2 border-solid rounded-md hover:bg-[grey] hover:border-none hover:text-white h-8'>
                                    <h3 className='text-center w-[10rem]'>
                                        Trocar senha
                                    </h3>
                                </button>

                            </div>
                        :
                            null
                        }

                </div>

            </div>

        </div>
    )
}