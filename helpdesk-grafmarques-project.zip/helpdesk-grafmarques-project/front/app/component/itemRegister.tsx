import Where from '../enum/Where'
import { createNewSector, getAllSectors } from '../functions/sector'
import APIResponse from '../interface/ApiResponse'
import Item from '../interface/Item'
import style from '../styles/itemRegister.module.css'

import Image from 'next/image'

import arrow_icon from '../../public/arrow_icon.svg'
import { CiRead } from "react-icons/ci";
import { CiUnread } from "react-icons/ci";

import { Dispatch, SetStateAction, useState, useContext } from 'react'

import SectorInput from './sectorInput'
import RoleInput from './roleInput'
import Role from '../enum/Role'
import PopupMessage from './popupMessage'

import UserContext from '../context/userContext'
import PopupContext from '../context/popupMessageContext'
import { PiEyedropperSample } from 'react-icons/pi'
import { postUserRegistration } from '../functions/user'
import User from '../interface/User'
import Sector from '../interface/Sector'
import LoadingComponent from './loadingComponent'
import { createNewCategory } from '../functions/category'
import { changePassword, changePasswordFromRecovery } from '../functions/authentication'

interface AdminItems {
    setRegisterScreen: Dispatch<SetStateAction<boolean>>
    setOperationDone: Dispatch<SetStateAction<boolean>>
    where: Where,
    itemA: {placeholder: string, field:string},
    itemB?: {placeholder: string, field:string},
    itemC?: {placeholder: string, field:string},
    itemD?: {placeholder: string, field:string},
    itemE?: {placeholder: string, field:string},
    userID?: string
}

export default function ItemRegister(items: AdminItems) {

    const userSystemContext = useContext(UserContext)
    const popupContext = useContext(PopupContext)

    const [seePwd, setSeePwd]                   = useState(false)
    const [seePwdB, setSeePwdB]                 = useState(false)

    const [showSector, setShowSector]           = useState(false)
    const [allSectors, setAllSectors]           = useState<Item[]>([{id: "0", name: "----"}])
    const [selectedSector, setSelectedSector]   = useState<Item>({id:"0", name:"Setor"})

    const [showRole, setShowRole]               = useState(false)
    const [selectedRole, setSelectedRole]       = useState<Role>(Role.USER)

    const [submitLoading, setSubmitLoading]     = useState<boolean>(false)

    const [checkBoxValue, setCheckBoxValue]     = useState<boolean>(false)

    async function getAllSectorsHandler() {
        if(JSON.stringify(allSectors) == '[{"id":"0","name":"----"}]') {

            const sectorResponse:APIResponse = await getAllSectors(userSystemContext.systemUser.jwtToken)

            const sectorList:Array<Item> = sectorResponse.response.map((element: Item) => {
                return(
                    {
                        id: element.id,
                        name: element.name
                    }
                )
            })
            setAllSectors(sectorList)
        }
    }

    async function submitHandler(formData:any) {

        if(!submitLoading) {

            setSubmitLoading(true)
            let apiCalling: APIResponse = {response: "", status: 0}

            if(items.where === Where.pwd_recovery) {
                const newPassword = formData.target[0].value 
                const pwdConfirmation = formData.target[1].value

                if(newPassword !== pwdConfirmation) {
                    popupContext.setErrorMessage("As senhas precisam ser iguais")
                    popupContext.setShowError(true)
                    return setSubmitLoading(false)
                }

                if(newPassword.length < 8) {
                    popupContext.setErrorMessage("Sua nova senha precisa ter mais de 8 caracteres")
                    popupContext.setShowError(true)
                    return setSubmitLoading(false)
                }

                if(items.userID) {
                    apiCalling = await changePasswordFromRecovery({id: items.userID, pwd: newPassword})
                }

                if(apiCalling.status == 200) {
                    popupContext.setSuccessMessage("Senha alterada com sucesso!")
                    popupContext.setShowSuccess(true)
                    items.setRegisterScreen(false)
                    return
                }
                else {
                    popupContext.setErrorMessage(apiCalling.response.title)
                    popupContext.setShowError(true)
                    return
                }

            }
            else if(items.where === Where.profile) {
                const oldPassword = formData.target[0].value 
                const newPassword = formData.target[1].value

                if(oldPassword.trim().length < 8 || newPassword.trim().length < 8) {
                    popupContext.setErrorMessage("Ambas as senhas devem ter 8 ou mais caracteres")
                    popupContext.setShowError(true)
                    setSubmitLoading(false)
                    return
                } 

                const result = await changePassword(userSystemContext.systemUser.jwtToken, userSystemContext.systemUser.userID, oldPassword.trim(), newPassword.trim())



                if(result.status == 200) {
                    popupContext.setSuccessMessage("Senha alterada com sucesso!")
                    popupContext.setShowSuccess(true)
                    items.setRegisterScreen(false)
                }
                else {
                    popupContext.setErrorMessage(result.response.title)
                    popupContext.setShowError(true)
                }
                
            }
            else if(items.where === Where.sector) {
                const sector:string = formData.target[0].value
                const answerForCallings = checkBoxValue

                if(sector.length <= 1) {
                    popupContext.setErrorMessage("O setor deve ter mais de 1 caractere")
                    popupContext.setShowError(true)
                    setSubmitLoading(false)
                    return
                } 

                apiCalling = await createNewSector(userSystemContext.systemUser.jwtToken, {name: sector, answerForCallings})

                if(apiCalling.status == 201) {
                    popupContext.setSuccessMessage("Setor criado com sucesso")
                    popupContext.setShowSuccess(true)
                    items.setRegisterScreen(false)
                } else {
                    popupContext.setErrorMessage(apiCalling.response.title)
                    popupContext.setShowError(true)
                }
            } else if(items.where === Where.user) {

                const userName:string = formData.target[0].value
                const sector: Sector = selectedSector
                const email: string = formData.target[2].value
                const role:Role = selectedRole
                const password: string = formData.target[4].value

                if(selectedSector.id == "0") {
                    popupContext.setErrorMessage("É necessário selecionar um setor")
                    popupContext.setShowError(true)
                    setSubmitLoading(false)
                    return
                } else if(userName.trim() == "" || email.trim() == "") {
                    popupContext.setErrorMessage("Todos os campos precisam ser preenchidos")
                    popupContext.setShowError(true)
                    setSubmitLoading(false)
                    return
                } 

                const user: User = {
                    email,
                    name: userName,
                    sector,
                    role,
                    password
                }

                apiCalling = await postUserRegistration(userSystemContext.systemUser.jwtToken, user)

                if(apiCalling.status == 201) {
                    popupContext.setSuccessMessage("Usuário criado com sucesso")
                    popupContext.setShowSuccess(true)
                    items.setRegisterScreen(false)
                    setSubmitLoading(false)
                } else {
                    popupContext.setErrorMessage(apiCalling.response.title)
                    popupContext.setShowError(true)
                    setSubmitLoading(false)
                }

            } else if(items.where == Where.category) {
                const category:string = formData.target[0].value
                    
                if(category.length <= 1) {
                    popupContext.setErrorMessage("A categoria deve ter mais de 1 caractere")
                    popupContext.setShowError(true)
                    setSubmitLoading(false)
                    return
                } 

                apiCalling = await createNewCategory(userSystemContext.systemUser.jwtToken, category)

                if(apiCalling.status == 201) {
                    popupContext.setSuccessMessage("Categoria criada com sucesso")
                    popupContext.setShowSuccess(true)
                    items.setRegisterScreen(false)
                } else {
                    popupContext.setErrorMessage(apiCalling.response.title)
                    popupContext.setShowError(true)
                }
        }

        setSubmitLoading(false)
        items.setOperationDone((prev) => {
            return !prev
        })
        }
    }

    return(
        <div className={`${style.container} ${items.where !== Where.user ? style.smaller_container : null}`}>
            
            {submitLoading 
                ?
                    <div className='absolute -mt-12 z-40'>
                        <LoadingComponent/>
                    </div>
                :
                    null
                }

            <form
                onSubmit={(ev: any) => {ev.preventDefault(),
                    submitHandler(ev)}}>

                <div className={`${style.input_box}`}>

                    <div className={`${style.input_couple}`}>

                        <div>
                            {items.where != Where.profile && items.where != Where.pwd_recovery
                                ?
                                    <label 
                                        htmlFor="name"
                                        className='font-bahnscrift_bold'>
                                            {items.itemA.field}:
                                    </label>
                                :
                                    null
                            }

                            {items.where == Where.profile || items.where == Where.pwd_recovery
                                ?   
                                    <div className='relative'>

                                        <label 
                                            htmlFor="name"
                                            className='font-bahnscrift_bold'>
                                            {items.itemA.field}:
                                        </label>

                                        <input
                                            placeholder={`${items.itemA.placeholder}`}
                                            type={seePwd ? 'text' : 'password'}
                                            name={items.itemA.field}
                                            id={items.itemA.field}
                                        />
                                        
                                        {seePwd
                                            ?
                                                <CiRead 
                                                    onClick={() => setSeePwd((prev) => {
                                                        return(!prev)
                                                    })}
                                                    className='absolute right-0 top-1 mr-3 hover:cursor-pointer'/>
                                            :
                                                <CiUnread 
                                                    onClick={() => setSeePwd((prev) => {
                                                        return(!prev)
                                                    })}
                                                    className='absolute right-0 top-1 mr-3 hover:cursor-pointer'/>
                                        }
                                    </div>
                                :
                                    <input
                                        placeholder={`${items.itemA.placeholder}`}
                                        type="text" 
                                        name={items.itemA.field}
                                        id={items.itemA.field}
                                    />
                                }
                        </div>

                        {items.where == Where.user
                            ?
                                <SectorInput
                                    allSectors={allSectors}
                                    getAllSectorsHandler={getAllSectorsHandler}
                                    selectedSector={selectedSector}
                                    setSelectedSector={setSelectedSector}
                                    setShowSector={setShowSector}
                                    showSector={showSector}
                                    style={style}
                                />
                            :
                                    null
                        }

                        {items.itemB && items.where !== Where.user && items.where !== Where.sector && items.where !== Where.profile && items.where !== Where.pwd_recovery
                            ?
                                <div>
                                    <label 
                                        htmlFor="name"
                                        className='font-bahnscrift_bold'>
                                            {items.itemB?.field}:
                                    </label>
                                    <input
                                        placeholder={`${items.itemB?.placeholder}`}
                                        type="text" 
                                        name={items.itemB.field} 
                                        id={items.itemB.field} 
                                    />
                                </div>
                            :
                                null
                        }

                        {items.where == Where.profile || items.where == Where.pwd_recovery
                            ?
                                <div className='relative'>
                                    <label 
                                        htmlFor="name"
                                        className='font-bahnscrift_bold'>
                                            {items.itemB?.field}:
                                    </label>
                                    <input
                                        placeholder={`${items.itemB?.placeholder}`}
                                        type={seePwdB ? 'text' : 'password'}
                                        name={items.itemB?.field} 
                                        id={items.itemB?.field} 
                                    />

                                    {seePwdB
                                        ?
                                            <CiRead 
                                                onClick={() => setSeePwdB((prev) => {
                                                    return(!prev)
                                                })}
                                                className='absolute right-0 top-1 mr-3 hover:cursor-pointer'/>
                                        :
                                            <CiUnread 
                                                onClick={() => setSeePwdB((prev) => {
                                                    return(!prev)
                                                })}
                                                className='absolute right-0 top-1 mr-3 hover:cursor-pointer'/>
                                    }

                                </div>
                            :
                                null
                        }

                        {items.itemB && items.where == Where.sector
                            ?
                                <div className='-ml-8'>
                                    <label className='font-bahnscrift_bold' htmlFor="atende_chamado">{items.itemB.placeholder}</label>
                                    <input 
                                        type="checkbox" 
                                        name="atende_chamado" 
                                        id="atende-chamado" 
                                        onClick={() => {
                                            setCheckBoxValue((prev) => {
                                                return !prev
                                            })
                                        }}
                                        />
                                </div>
                            :
                                null
                        }

                    </div>

                    <div className={`${style.input_couple}`}>
                        
                        {items.itemC
                            ?
                                <div>
                                    <label 
                                        htmlFor="name"
                                        className='font-bahnscrift_bold'>
                                            {items.itemC?.field}:
                                    </label>
                                    <input
                                        placeholder={`${items.itemC?.placeholder}`}
                                        type="text" 
                                        name={items.itemC.field}
                                        id={items.itemC.field}
                                    />
                                </div>
                            :
                                null
                        }   
    
                    
                        {items.where === Where.user
                            ?
                                <RoleInput
                                    setShowRole={setShowRole}
                                    selectedRole={selectedRole}
                                    setSelectedRole={setSelectedRole}
                                    showRole={showRole}
                                    style={style}
                                />
                            :
                                null
                        }
    
                        {items.itemD && items.where !== Where.user
                            ?
                                <div>
                                    <label 
                                        htmlFor="name"
                                        className='font-bahnscrift_bold'>
                                            {items.itemD?.field}:
                                    </label>
                                    <input
                                        placeholder={`${items.itemD?.placeholder}`}
                                        type="text" 
                                        name={items.itemD.field}
                                        id={items.itemD.field}
                                    />
                                </div>
                            :
                                null} 
    
                    </div>

                    <div className={`${style.input_couple}`}>
                        
                        {items.itemE
                            ?
                                <div>
                                    <label 
                                        htmlFor="name"
                                        className='font-bahnscrift_bold'>
                                            {items.itemE?.field}:
                                    </label>
                                    <input
                                        placeholder={`${items.itemE?.placeholder}`}
                                        type="text" 
                                        name={items.itemE.field}
                                        id={items.itemE.field}
                                    />
                                </div>
                            :
                                null
                        }   
    
                    </div>

                    <div className='absolute right-0 bottom-0 mb-2 mr-3'>
                        <button 
                            onClick={() => items.setRegisterScreen(false)}
                            className={`border-solid w-[10rem] border-[.1rem] px-2 py-1 rounded-md text-[#DD1D8B] border-[#DD1D8B] hover:bg-[#DD1D8B] hover:text-white`}>
                            Cancelar
                        </button>

                        <button 
                            type='submit'
                            className={`right-0 ml-3 border-solid w-[12rem]  border-[.1rem] px-2 py-1 rounded-md text-[#8BCB1A] border-[#8BCB1A] hover:bg-[#8BCB1A] hover:text-white`}>
                            {items.where == Where.pwd_recovery ? 'Aplicar' :  'Registrar'}
                        </button>
                    </div>

                </div>
            </form>
        </div>
    )
}