'use client'

import { CiRead } from "react-icons/ci";
import { CiUnread } from "react-icons/ci";


import React, { useState } from "react";
import { useRouter } from "next/navigation";

import { useContext, useEffect } from "react";

import Image from "next/image";

import logo_without_bg from '../../public/logo_without_background.png'
import styles from '../styles/loginPage.module.css'

import UserContext from "../context/userContext";

import ForgotPwdBox from "../component/forgotPwdBox";

import axios from 'axios'
import { loginUser, registerFirstAdmin } from "../functions/authentication";
import APIResponse from "../interface/ApiResponse";

import crypto from 'crypto'
import PopupMessage from "../component/popupMessage";
import User from "../interface/User";
import PopupContext from "../context/popupMessageContext";


export default function AdminRegistering() {

    const userSystemContext = useContext(UserContext)
    const popupContext      = useContext(PopupContext)
    const router = useRouter()

    const initialLoginError: {error: boolean, message: string} = {error: false, message: ""}

    const [loading, setLoading]                 = useState(false)
    const [loginError, setLoginError]           = useState(initialLoginError)
    const [openForgotPwd, setOpenForgotPwd]     = useState(false)

    const [seePassword, setSeePassword]         = useState<boolean>(false)

    const [emailSuggestion, setEmailSuggestion] = useState<string>(userSystemContext.emailSuggestion)

    async function loginIntoSystem(event:any) {
        event.preventDefault()

        setLoginError(
            initialLoginError
        )

        const userName: string = event.target[0].value
        const userEmail: string = event.target[1].value
        const userPWD: string = event.target[2].value
        const userPWDConfirmation: string = event.target[3].value

        const admin: User = {
            name: userName,
            email: userEmail,
            sector: {id: "0", name: "T.I"},
            password: userPWD,
        }

        if(userName.length < 2) {
            setLoginError(
                {
                    error: true,
                    message: "O campo 'Nome' deve ter pelo menos 2 caracteres"
                }
            )
            event.target[0].value = ""
            return
        }
        else if(userPWD.length < 8) {
            setLoginError(
                {
                    error: true,
                    message: "O campo 'Senha' deve ter pelo menos 8 caracteres"
                }
            )
            event.target[2].value = ""
            return
        }
        else if(userPWDConfirmation.length < 8) {
            setLoginError(
                {
                    error: true,
                    message: "O campo 'Confirmação de Senha' deve ter pelo menos 8 caracteres"
                }
            )
            event.target[3].value = ""
            return
        }
        else if(userPWD != userPWDConfirmation) {
            setLoginError(
                {
                    error: true,
                    message: "As senhas não coincidem"
                }
            )
            return
        }

        setLoading(true)

        const registerResponse: APIResponse = await registerFirstAdmin(admin)


        if(registerResponse.status == 201) {
            popupContext.setSuccessMessage("Administrador registrado com sucesso")
            popupContext.setShowSuccess(true)
            router.push('/')
        } else{
            setLoginError(
                {
                    error: true,
                    message: registerResponse.response.title
                }
            )
        }

        setLoading(false)
    }

    useEffect(() => {
        localStorage.setItem("logged", "false")
    }, [])



    return(
        <div className={`${styles.container} font-bahnscrift_bold`}>

            <PopupMessage/>

            <div className={`${loginError.error ? styles.show_error : styles.dont_show}`}>
                <p>{loginError.message}</p>
            </div>

            <div className={`${styles.login_section}`}>
            
                <div className={`${styles.logo}`}>
                    <Image
                        src={logo_without_bg}
                        width={450}
                        className={`${styles.logo_img}`}
                        alt="imagem_da_logo"
                    />            

                    <h1 className="font-bahnscrift">SISTEMA DE CHAMADOS</h1>
                </div>

                <h1 className="font-bahnscrift text-white">Criação de usuário administrador</h1>

                <form onSubmit={(event) => loginIntoSystem(event)}
                    className={`flex flex-col gap-4 w-full ${styles.input_area}`}>
                    
                    <input 
                        type="text" 
                        placeholder='Nome'
                        name="username" 
                        id="username" 
                    />
                    
                    <input 
                        type="email" 
                        placeholder='Email'
                        name="email" 
                        id="email" 
                        value={emailSuggestion}
                        onChange={(ev) => {
                            setEmailSuggestion(ev.target.value)
                        }}
                    />

                    <div className={`${styles.password_div}`}>

                        <input 
                            type={`${seePassword ? "text" : "password"}`} 
                            placeholder="Senha" 
                            name="password" 
                            id="password" 
                            className={`${openForgotPwd ? styles.disappear : null}`}
                            />  

                        {seePassword
                            ?
                                <CiUnread 
                                    onClick={() => {
                                        setSeePassword((prev:boolean) => {
                                            return(!prev)
                                        })
                                    }} 
                                    className="text-2xl text-[#0860A8] absolute right-5 top-0 mt-3 hover:cursor-pointer"/>
                            :
                                <CiRead 
                                    onClick={() => {
                                        setSeePassword((prev:boolean) => {
                                            return(!prev)
                                        })
                                    }} 
                                    className="text-2xl text-[#0860A8] absolute right-5 top-0 mt-3 hover:cursor-pointer"/>
                            }

                    </div>

                        <input 
                            type={`${seePassword ? "text" : "password"}`} 
                            placeholder="Confirmação de Senha" 
                            name="passwordConfirmation" 
                            id="passwordConfirmation" 
                            className={`${openForgotPwd ? styles.disappear : null}`}
                        />  

                    
                    {loading 
                        ? 
                            <div className={`${styles.loading} m-auto mt-4`}></div>
                        :
                            <button 
                                type="submit"
                                className={`${openForgotPwd ? styles.disappear : null}`}
                                >  
                                <p>Registrar</p>
                            </button>
                    }

                </form>

            </div>

        </div>
    )
}