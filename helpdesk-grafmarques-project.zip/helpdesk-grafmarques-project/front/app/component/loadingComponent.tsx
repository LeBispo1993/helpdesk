import style from '../styles/loadingComponent.module.css'

export default function LoadingComponent() {
    return(
        <div className={`${style.container}`}>

            <span className={`${style.loading}`}></span>

        </div>
    )
}