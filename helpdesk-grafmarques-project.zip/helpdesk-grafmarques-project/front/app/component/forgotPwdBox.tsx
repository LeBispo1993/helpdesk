'use client'

import { passwordRecovery } from '../functions/authentication';
import APIResponse from '../interface/ApiResponse';
import style from '../styles/popupBox.module.css'
import { FiX } from "react-icons/fi";
import PopupMessage from './popupMessage';

import { useContext, useState, useEffect } from 'react';
import PopupContext from '../context/popupMessageContext';


interface ForgotPwdBoxProps {
    setOpenForgotPwd: React.Dispatch<React.SetStateAction<boolean>>
}

export default function ForgotPwdBox({ setOpenForgotPwd }: ForgotPwdBoxProps) {

    const [loadingButton, setLoadingButton] = useState(false)

    const popupContext = useContext(PopupContext)

    async function getNewPassword(event: any) {

        const email:string = event.target[0].value

        if(email.length == 0) {
            popupContext.setErrorMessage("O campo de email deve ser preenchido")
            popupContext.setShowError(true)
            setLoadingButton(false)
            return
        }

        if(!loadingButton) {

            setLoadingButton(true)
                
            const result: APIResponse = await passwordRecovery(email)
            
            if(result.status == 200) {
                popupContext.setSuccessMessage(result.response.message)
                popupContext.setShowSuccess(true)
                setLoadingButton(false)
                setOpenForgotPwd(false)
            } else {
                popupContext.setErrorMessage(result.response.title)
                popupContext.setShowError(true)
                setLoadingButton(false)
            }
        }

    }

    return(
        <div className={`${style.container}`}>


            <div className={`${style.white_bg}`}>

                <h1>Esqueceu a senha?</h1>

                <FiX
                    className={`${style.close_page} hover:cursor-pointer`}
                    onClick={() => setOpenForgotPwd(false)}
                />

                <form onSubmit={(e) => {
                    e.preventDefault();
                    getNewPassword(e)
                    }}>
                        
                    <input 
                        type="email" 
                        name="login" 
                        id="login"
                        placeholder='Informe seu login'  
                        className={`${style.email_input}`}
                    />

                    <p>
                        Ao confirmar, você receberá uma senha nova no seu email
                    </p>

                    {!loadingButton
                        ?
                        <button type='submit' className={`${style.confirmation_bttn}`}>CONFIRMAR</button>
                        :
                        <span className='w-11 h-11 bottom-0 -mb-3 right-0 left-0 m-auto border-t-2 border-t-[#DD1D8B] border-r-2 border-r-[#DD1D8B] rounded-full absolute block animate-spin '></span>
                        }

                </form>
            </div>


        </div>
    )
} 