'use client'

import React, { useState, useEffect, useCallback, useContext } from 'react';
import { Grid, _ } from 'gridjs-react';

import { useRouter } from 'next/navigation';

import "gridjs/dist/theme/mermaid.css"; // Import GridJS CSS
import style from '../styles/grid.module.css'
import { Cell, Component, PluginPosition, Row } from 'gridjs';
import CallingContext from '../context/callingContext';
import Method from '../enum/Method';

const SectorGridComponent = React.memo(({gridData, changeData, setIDFromGrid, setDoingOperation, setMethod}: any) => {

    const redButton: string = "border-[#DD1D8B] text-[#DD1D8B] hover:bg-[#DD1D8B]"
    const greenButton: string = "border-[#8BCB1A] text-[#8BCB1A] hover:bg-[#8BCB1A]"

    const callingContext = useContext(CallingContext)
    const [tableData, setTableData] = useState<any>([]);

    const route = useRouter()

    useEffect(() => {
        if (callingContext.sendCalling) {
            const sectorArray = localStorage.getItem("allSectors")
            let parsedSectorArray: Array<string> = []

            if(typeof sectorArray == "string") {
                parsedSectorArray = JSON.parse(sectorArray)
            }

            setTableData(parsedSectorArray);
        }
    }, [callingContext.sendCalling]);

    const customLanguage = {
        search: {
            placeholder: "🔍 Procurar por palavra-chave",
        },
        pagination: {
            previous: "◀️ Anterior",
            next: "▶️ Próximo",
            showing: "Mostrando",
            results: () => "itens",
            to: "de",
            of: "de um total de",
            noResults: "Nenhum resultado encontrado",
        },
        loading: "⏳ Carregando dados...",
        noRecordsFound: "Nenhum dado encontrado",
        error: "Ocorreu um erro na busca por dados",
    };
    const columns = [
        {
            name: 'ID',
            hidden: true
        },
        "Setor",
        "Estado",
        "Criado em",
        "Atende chamados?",
        {
            name: "",
            formatter: (cell:string, row:any) => {
                return _(
                    <h1 
                    onClick={() => {setDoingOperation(true), 
                        row.cells[2].data === "Ativo" ? setMethod(Method.Deactivation) : setMethod(Method.Activation),
                        setIDFromGrid((row.cells[0].data))
                    }}
                            className={`font-bold text-[.75rem] border-solid border-[1px] min-w-[100%] px-8 py-3 rounded-md m-auto text-center hover:cursor-pointer hover:text-white ${row.cells[2].data === "Ativo" ? redButton : greenButton}`}>{row.cells[2].data == "Ativo" ? "Desativar" : "Ativar"}</h1>
                )
            }
        }
    ]

    return (
        <div className={`${style.container}`}>
            <div className={`w-11/12 mx-auto ${style.grid_style}`}>
                {tableData.length > 0 && (
                    <Grid
                        data={tableData}
                        columns={columns}
                        search={true}
                        sort={true}
                        height='25rem'
                        width='100%'
                        fixedHeader={true}
                        resizable={true}
                        language={customLanguage}
                        pagination={{
                            limit: 10,
                        }}
                        className={{
                            container: `${style.grid_container}`,
                            table: `${style.grid_table}`,
                            th: `${style.grid_th}`,
                            td: `${style.grid_td}`,
                        }}
                    />
                )}
            </div>
        </div>
    );
});

SectorGridComponent.displayName = 'Sector Grid Component'

export default SectorGridComponent;