'use client'

import style from '../styles/header.module.css'


import grafmarquesLogo from '../../public/logo_without_background.png'
import logo_without_text from '../../public/logo_without_text.svg'


import chamados_icon from '../../public/chamados_icon.svg'
import home_icon from '../../public/home_icon.svg'
import add_icon from '../../public/add_icon.svg'
import notification_icon from '../../public/notifications.svg'
import profile_icon from '../../public/profile_icon.svg'
import hamburger_menu from '../../public/hamburger_menu.svg'
import white_close_icon from '../../public/white_close_icon.svg'

import { FiTool } from "react-icons/fi";

import Image from 'next/image';

import { useRouter } from 'next/navigation'

import Link from 'next/link'
import { useEffect, useState, useContext } from 'react'

import UserContext from '../context/userContext'
import APIResponse from '../interface/ApiResponse'
import { getUserNotificationNumber } from '../functions/notification'

import crypto from 'crypto'

export default function PageHeader() {

    const systemUserContext = useContext(UserContext)

    const [windowWidth, setWindowWidth] = useState(0)
    const [lowWidth, setLowWidth]       = useState(false)
    const [openMenu, setOpenMenu]       = useState(false)

    const [smallerLogo, setSmallerLogo] = useState(false)

    const [isAdmin, setIsAdmin]         = useState<boolean>(false)

    const [notificationCount, setNotificationCount] = useState(0)

    const router = useRouter()
    let firstSection: string | null = ""

    useEffect(() => {

        if(sessionStorage.getItem('section') == null) {
            sessionStorage.setItem('section', 'home')
        } else {
            firstSection = sessionStorage.getItem('section')
        }
    }, [])

    useEffect(() => {
        notificationCounterHandler()
    }, [systemUserContext.systemUser.currentPage])

    function isAdminHandle() {
        const isAdmin: boolean = systemUserContext.isAdmin()
        setIsAdmin(isAdmin)
    }

    useEffect(() => {

        isAdminHandle()

        if(windowWidth == 0) {
            setWindowWidth(window.innerWidth)
        }

        const handleResize = () => {
            setWindowWidth(window.innerWidth)
        };
        window.addEventListener("resize", handleResize);
        return () => window.removeEventListener("resize", handleResize);
      }, []);

    useEffect(() => {

        if(windowWidth <= 1010) {
            setSmallerLogo(true)
        } else {
            setSmallerLogo(false)
        }
                    
        if(windowWidth <= 768) {
            setLowWidth(true)
        } else{
            setLowWidth(false)
        }
    }, [windowWidth])

    const [actualScreen, setActualScreen] = useState<string | null>(firstSection)

    const onHandleChangeSection = (section: string) => {
        sessionStorage.setItem('section', section)
        setActualScreen(section)
    }

    const onHandleRouteSection = (route:string) => {

        if(route == "notificacao") {
            return router.push(`/main/${route}?page=1`)
        }
        router.push(`/main/${route}`)
    }

    async function notificationCounterHandler() {

        const jwtToken:string|null = systemUserContext.getStorageToken()

        const notificationCount: APIResponse = await getUserNotificationNumber(jwtToken)

        if(notificationCount.status == 200) {
            setNotificationCount(notificationCount.response)
        }

    }


    return(
        <div className={`${style.container}`}>
            <div className={`${style.header}`}>
                

                <div
                    onClick={() => {onHandleChangeSection("home"),
                    onHandleRouteSection("home")
                    }} 
                    className={`z-10 hover:cursor-pointer flex flex-col-reverse items-center`}>
                
                    {!smallerLogo 
                        ?
                            <h1 className='text-sm font-bahnscrift_regular text-white ml-16 -mt-4'>
                            SISTEMA DE CHAMADOS
                            </h1>
                        :
                            null
                        }
                    
                    {!smallerLogo
                        ?
                            <Image
                            src={grafmarquesLogo}
                            width={200}
                            alt={"ícone_logo"}
                            className='z-5'
                            />
                        :
                            <Image
                            src={logo_without_text}
                            width={60}
                            alt={"ícone_logo"}
                            className='ml-5'
                            />
                        }

                </div>
            
                <div className={`${style.main_icons} ${lowWidth ? style.low_width : null} w-11/12 fixed left-0 right-0 flex justify-center`}>
                    
                    <div 
                        onClick={() => {onHandleChangeSection("home"), 
                        onHandleRouteSection('home')}
                        }
                        className={`${style.icon_and_desc} ${systemUserContext.systemUser.currentPage == 'home' ? style.highlight_home_option : style.no_highlight} flex text-white items-center gap-3 font-bahnscrift_regular hover:cursor-pointer select-none`}>

                        <h1 className={`${style.icon_desc}`}>INÍCIO</h1>

                        <Image
                            src={home_icon}
                            width={30}
                            alt={"ícone_início"}
                        />

                    </div>

                    <div
                        onClick={() => {onHandleChangeSection("myCallings"),
                        onHandleRouteSection('meus_chamados')}
                        }
                        className={`${style.icon_and_desc_large} ${systemUserContext.systemUser.currentPage == 'meus_chamados' ? style.highlight_myCallings_option : style.no_highlight} flex text-white items-center gap-3 font-bahnscrift_regular hover:cursor-pointer select-none`}>

                        <h1 className={`${style.icon_desc}`}>MEUS CHAMADOS</h1>

                        <Image
                            src={chamados_icon}
                            width={25}
                            alt={"ícone_chamados"}
                        />

                    </div>

                    <div 
                        onClick={() => {onHandleChangeSection("createCalling"),
                        onHandleRouteSection('criar_chamado')}
                        }
                        className={`${style.icon_and_desc_large}  ${systemUserContext.systemUser.currentPage == 'criar_chamado' ? style.highlight_createCalling_option : style.no_highlight} flex text-white items-center gap-3 font-bahnscrift_regular hover:cursor-pointer select-none`}>

                        <h1 className={`${style.icon_desc}`}>CRIAR CHAMADO</h1>

                        <Image
                            src={add_icon}
                            width={25}
                            alt={"adicionar_chamado"}
                        />

                    </div>

                </div>

                <div className={`${style.user_icons} flex gap-7 mr-8`}>
                    
                    <div
                        onClick={() => {onHandleChangeSection("notificacao"),
                        onHandleRouteSection("notificacao")
                        }} 
                        className={`hover:cursor-pointer z-10 ${systemUserContext.systemUser.currentPage == 'notificacao' ? style.highlight_notification_option : style.no_highlight} relative`}>
                        <Image
                            src={notification_icon}
                            width={30}
                            alt={"ícone_notificação"}
                        />

                        <span className={`${style.notification_number} font-bahnscrift_bold select-none ${notificationCount == 0 ? style.not_show : null}`}>{notificationCount}</span>

                    </div>
                
                    <div className={`hover:cursor-pointer z-10 ${systemUserContext.systemUser.currentPage == 'perfil' ? style.highlight_notification_option : style.no_highlight}`}>
                        <Image
                            onClick={() => {onHandleChangeSection("perfil"),
                            onHandleRouteSection("perfil")
                            }}
                            src={profile_icon}
                            width={30}
                            alt={"ícone_perfil"}
                        />
                    </div>
                            
                    {isAdmin 
                        ?
                            <div className={`hover:cursor-pointer z-10 ${systemUserContext.systemUser.currentPage == 'admin' ? style.highlight_notification_option : style.no_highlight}`}>
                                <FiTool
                                    onClick={() => {onHandleChangeSection("admin"),
                                    onHandleRouteSection("admin_page")
                                    }} 
                                    className='text-[2.1rem] text-white'
                                />

                            </div>
                        :
                            null
                        }

                    {lowWidth 
                        ?
                            <div className={`hover:cursor-pointer z-10 mt-[.3rem]`}>
                                <Image
                                    onClick={() => setOpenMenu((prev) => {
                                        return !prev
                                    })}
                                    src={hamburger_menu}
                                    width={30}
                                    alt={"menu_hamburger"}
                                />
                            </div>
                        :
                            null
                    }

                </div>
            </div>
            
            <div className={`${style.lateral_menu} ${lowWidth && openMenu ? style.show_lateral_menu : style.hide_lateral_menu} text-xl`}>

                <div className={`hover:cursor-pointer absolute z-10 mt-[2rem] right-8`}>
                    <Image
                        onClick={() => setOpenMenu((prev) => {
                            return !prev
                        })}
                        src={white_close_icon}
                        width={25}
                        alt={"menu_hamburger"}
                    />
                </div>


                <div className='flex flex-col items-center py-48 gap-8'>

                    <div 
                        onClick={() => {setOpenMenu(false),
                            onHandleChangeSection("home"), 
                        onHandleRouteSection('home')}
                        }
                        className={`flex text-white items-center gap-3 font-bahnscrift_regular hover:cursor-pointer select-none`}>

                        <h1 className={`${style.icon_desc}`}>INÍCIO</h1>

                        <Image
                            src={home_icon}
                            width={30}
                            alt={"ícone_início"}
                        />

                    </div>

                    <div
                        onClick={() => {setOpenMenu(false),
                            onHandleChangeSection("myCallings"),
                        onHandleRouteSection('meus_chamados')}
                        }
                        className={`flex text-white items-center gap-3 font-bahnscrift_regular hover:cursor-pointer select-none`}>

                        <h1 className={`${style.icon_desc}`}>MEUS CHAMADOS</h1>

                        <Image
                            src={chamados_icon}
                            width={25}
                            alt={"ícone_chamados"}
                        />

                    </div>

                    <div 
                        onClick={() => {setOpenMenu(false),
                            onHandleChangeSection("createCalling"),
                        onHandleRouteSection('criar_chamado')}
                        }
                        className={`flex text-white items-center gap-3 font-bahnscrift_regular hover:cursor-pointer select-none`}>

                        <h1 className={`${style.icon_desc}`}>CRIAR CHAMADO</h1>

                        <Image
                            src={add_icon}
                            width={25}
                            alt={"adicionar_chamado"}
                        />

                    </div>  

                </div>

            </div>

        </div>
    )
}