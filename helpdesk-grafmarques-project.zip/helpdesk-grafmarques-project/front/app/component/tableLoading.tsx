import style from '../styles/tableLoading.module.css'

export default function TableLoading() {
    return(
        <div className={`${style.container}`}>
            <span className='w-[50%] h-[15%] rounded-md bg-slate-300 block animate-pulse'></span>
            
            <span className='w-[100%] h-[15rem] mt-6 rounded-md bg-slate-300 block animate-pulse'/>
        </div>
    )
}