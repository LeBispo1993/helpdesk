'use client'

import styles from '../styles/popupMessage.module.css'
import { useEffect, useState, useContext } from 'react'

import PopupContext from '../context/popupMessageContext'
import UserContext from '../context/userContext'

interface ErrorMessageProps {
    successMessage: string;
    errorMessage: string;
    error: boolean;
    success: boolean
    setError: (error: boolean) => void;
    setSuccess: (sucess: boolean) => void;
}

export default function PopupMessage() {

    const systemUserContext = useContext(UserContext)
    const popupContext = useContext(PopupContext)

    const [message, setMessage] = useState<string>("")

    useEffect(() => {
        if (popupContext.showError) {
            setMessage(popupContext.errorMessage)
            const timer = setTimeout(() => {
                popupContext.setShowError(false);
            }, 2000);

            return () => clearTimeout(timer);
        }

        if (popupContext.showSuccess) {
            setMessage(popupContext.successMessage)
            const timer = setTimeout(() => {
                popupContext.setShowSuccess(false);
            }, 2000);

            return () => clearTimeout(timer);
        }
    }, [popupContext.showError, popupContext.showSuccess]);


    useEffect(() => {
        popupContext.setShowError(false)
        popupContext.setShowSuccess(false)
    }, [systemUserContext.systemUser.currentPage])


    return( 
        <div className={`${styles.container}`}>

            <div className={`${popupContext.showError ? styles.show_error : popupContext.showSuccess ? styles.show_sucess : styles.dont_show}`}>
                <p>{message}</p>
            </div>

        </div>
    )
}







/* export default function PopupMessage({successMessage, errorMessage, error, setError, success, setSuccess}:ErrorMessageProps) {

    const [message, setMessage] = useState<string>("")

    useEffect(() => {
        if (error) {
            setMessage(errorMessage)
            const timer = setTimeout(() => {
                setError(false);
            }, 2000);

            return () => clearTimeout(timer);
        }

        if (success) {
            setMessage(successMessage)
            const timer = setTimeout(() => {
                setSuccess(false);
            }, 2000);

            return () => clearTimeout(timer);
        }
    }, [error, setError, success, setSuccess]);


    return( 
        <div className={`${styles.container}`}>

            <div className={`${error ? styles.show_error : success ? styles.show_sucess : styles.dont_show}`}>
                <p>{message}</p>
            </div>

        </div>
    )
} */