import Image from "next/image"
import arrow_icon from '../../public/arrow_icon.svg'

import { Dispatch, SetStateAction } from "react"
import Item from "../interface/Item"
import Role from "../enum/Role"

interface SectorProps {
    style: any
    setShowRole: Dispatch<SetStateAction<boolean>>,
    showRole: boolean
    setSelectedRole: Dispatch<SetStateAction<Role>>|any,
    selectedRole: Role|any,
}

const allRoles: Role[] = [Role.USER, Role.AGENT, Role.ADMIN]

export default function RoleInput(props: SectorProps) {
    return(
        <div className={`flex gap-4 md:w-[40%] items-center relative ${props.style.label_and_input}`}>

            <label htmlFor="role" className='md:10rem'>
                <p className={`w-20 ${props.style.setor_p} font-bahnscrift_bold`}>Cargo: <span className='text-[#DD1D8B]'>*</span></p>
            </label>

            <Image
                onClick={() => props.setShowRole((prev: any) => !prev)}
                src={arrow_icon}
                className={`${props.showRole ? null : 'rotate-180'} bg-white py-1 ] absolute right-2 hover:cursor-pointer z-30`}
                alt={"ícone_seta"}
                
            />

            <div className='w-[100%] relative'>
                
                <input 
                    readOnly={true}
                    onClick={() => props.setShowRole((prev:any) => !prev)}
                    type="text" 
                    name="role" 
                    id={props.selectedRole.toString()} 
                    value={props.selectedRole}
                    contentEditable={false}
                    className={`${props.style.sector_input} w-[100%] select-none px-5 z-10 hover:cursor-pointer`}
                />

                <div className={`${props.style.status_options} ${!props.showRole ? props.style.not_show_options : props.style.show_options} z-40 -mt-1 rounded-md grid gap-3 absolute w-[100%] h-[auto] bg-white pt-2 text-[#626262] select-none right-0 border-2 border-opacity-60 border-[#959595]`}>
                
                
                    {allRoles.map((element: any) => (
                        <p 
                            key={element}
                            onClick={(p) => {props.setSelectedRole(element), 
                                props.setShowRole(false)
                            }}
                            id={element} 
                            className={`text-center ${!props.showRole ? 'opacity-0' : null} hover:cursor-pointer`}>
                            
                            {element}
                        </p>
                    ))}

                </div>
                                    
            </div>
                                    
        </div>
    )
}