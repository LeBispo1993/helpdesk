'use client'

import React, { useState, useEffect, useCallback, useContext } from 'react';
import { Grid, _ } from 'gridjs-react';

import { useRouter } from 'next/navigation';

import "gridjs/dist/theme/mermaid.css"; // Import GridJS CSS
import style from '../styles/grid.module.css'
import { Cell, Component, PluginPosition, Row } from 'gridjs';
import CallingContext from '../context/callingContext';

interface CallingsComponent {
    gridData: any,
    changeData: any,
    activeCollumn?: any
}

const GridComponent = React.memo(({gridData, changeData, activeCollumn}: CallingsComponent) => {

    const callingContext = useContext(CallingContext)
    const [tableData, setTableData] = useState<any>([]);

    const route = useRouter()

    useEffect(() => {
        if (callingContext.sendCalling == true) {
            const homeArray = localStorage.getItem("home_array")
            let parsedHomeArray: Array<string> = []

            if(typeof homeArray == "string") {
                parsedHomeArray = JSON.parse(homeArray)
            }

            setTableData(parsedHomeArray);
        }
    }, [callingContext.sendCalling]);

    const customLanguage = {
        search: {
            placeholder: "🔍 Procurar por palavra-chave",
        },
        pagination: {
            previous: "◀️ Anterior",
            next: "▶️ Próximo",
            showing: "Mostrando",
            results: () => "itens",
            to: "de",
            of: "de um total de",
            noResults: "Nenhum resultado encontrado",
        },
        loading: "⏳ Carregando dados...",
        noRecordsFound: "Nenhum dado encontrado",
        error: "Ocorreu um erro na busca por dados",
    };
    const columns = [
        {
            name: 'ID',
            hidden: true
        },
        'OS',
        {
            name: "Título",
            formatter: (cell:string, row:any) => {
                return _(
                    <h1 
                        onClick={() =>
                            route.push(`/main/chamado/${row.cells[0].data}`)
                        }
                        className='font-bold text-[.75rem] text-[#0860A8] hover:cursor-pointer'>{cell}</h1>
                )
            }
        },
        'Status', 
        'Prioridade', 
        'Categoria',
        'Setor', 
        'Data de Abertura', 
        'Última Atualização', 
        'Requerente', 
        'Autor'    
    ]

    return (
        <div className={`${style.container}`}>
            <div className={`w-11/12 mx-auto ${style.grid_style}`}>
                {tableData.length > 0 && (
                    <Grid
                        data={tableData}
                        columns={columns}
                        search={true}
                        sort={true}
                        height='25rem'
                        width='100%'
                        fixedHeader={true}
                        resizable={true}
                        language={customLanguage}
                        pagination={{
                            limit: 10,
                        }}
                        className={{
                            container: `${style.grid_container}`,
                            table: `${style.grid_table}`,
                            th: `${style.grid_th}`,
                            td: `${style.grid_td}`,
                        }}
                    />
                )}
            </div>
        </div>
    );
});

GridComponent.displayName = 'Grid Component'

export default GridComponent;