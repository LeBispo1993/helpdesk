'use client'

import { createContext, useState, useEffect, Dispatch, SetStateAction } from 'react';

let successMessage: string = ""
let errorMessage: string = ""
let showError: boolean = false
let showSuccess: boolean = false
let setShowError: Dispatch<SetStateAction<boolean>>|any
let setShowSuccess: Dispatch<SetStateAction<boolean>>|any
let setSuccessMessage: Dispatch<SetStateAction<string>>|any
let setErrorMessage: Dispatch<SetStateAction<string>>|any

const PopupContext = createContext({
    successMessage,
    errorMessage,
    showError,
    showSuccess,
    setShowError,
    setShowSuccess,
    setSuccessMessage,
    setErrorMessage
})

export function PopupProvider(props: any) {

    const [errorMessage, setErrorMessage]           = useState<string>("")
    const [successMessage, setSuccessMessage]        = useState<string>("")

    const [showError, setShowError]                 = useState<boolean>(false)
    const [showSuccess, setShowSuccess]             = useState<boolean>(false)

    const context = {
        successMessage,
        errorMessage,
        showError,
        showSuccess,
        setShowError,
        setShowSuccess,
        setSuccessMessage,
        setErrorMessage
    }

    return (
        <PopupContext.Provider value={context}>
            {props.children}
        </PopupContext.Provider>
    )

}


export default PopupContext