'use client'

import { createContext, useState, useEffect, Dispatch, SetStateAction } from 'react';
import SystemUser from '../interface/SystemUser'
import { getUserByID } from '../functions/user';

import crypto from 'crypto'

const systemUser: SystemUser = {
    role: null,
    userID: null,
    jwtToken: null,
    currentPage: null
}

let emailSuggestion: string = ""
let setEmailSuggestion: any

const UserContext = createContext({
    systemUser,
    emailSuggestion,
    setEmailSuggestion,
    
    setCurrentPage: function(page: string) {},
    setUserID: function(userID: string) {},
    setJWTToken: function(jwtToken: string) {},
    setRole: function(role:string) {},
    getStorageToken: function():string|null {
        const jwtToken:string|null = localStorage.getItem("jwtToken")
        return jwtToken
    },
    getUserID: function():string|null {
        const userID:string|null = localStorage.getItem("userID")
        return userID
    },
    isAdmin: function():boolean {

        const hash = crypto.createHash('sha256')
        hash.update('ADMIN')

        const userRole:string|null = localStorage.getItem("userRole")
        if(userRole === hash.digest('base64')) {
            return true
        } else {
            return false
        }
    },
    isUser: function():boolean {

        const hash = crypto.createHash('sha256')
        hash.update('USER')

        const userRole:string|null = localStorage.getItem("userRole")
        if(userRole === hash.digest('base64')) {
            return true
        } else {
            return false
        }
    }
})


export function UserContextProvider(props: any) {

    const [changeUser, setChangeUser] = useState<SystemUser>(systemUser)

    const [emailSuggestion, setEmailSuggestion] = useState<string>("")

    useEffect(() => {

        const userID: string|null = localStorage.getItem("userID")
        const jwtToken: string|null = localStorage.getItem("jwtToken")
        const currentPage: string|null = localStorage.getItem("currentPage")
        const userRole: string|null = localStorage.getItem("userRole")

        if(jwtToken && currentPage && userID) {
            setChangeUser(
                {
                    role: userRole,
                    userID,
                    currentPage: currentPage,
                    jwtToken: jwtToken
                }
            )
        }else if(jwtToken && !currentPage) {
            setChangeUser(
                {
                    role: userRole,
                    userID,
                    jwtToken: jwtToken,
                    currentPage: null
                }
            )
        }

    }, [])

    function setUserIDHandler(userID: string) {
        setChangeUser((prev) => {
            return(
                {
                    userID,
                    role: prev.role,
                    jwtToken: prev.jwtToken,
                    currentPage: prev.currentPage
                }
            )
        })

        localStorage.setItem("userID", userID)
    }

    function setCurrentUserPageHandler(page: string) {
        setChangeUser((prev) => {
            return({
                role: prev.role,
                userID: prev.userID,
                jwtToken: prev.jwtToken,
                currentPage: page
            })
        })

        localStorage.setItem("currentPage", page)
    }

    function setJWTHandler(jwtToken: string) {
        setChangeUser((prev) => {
            return({
                role: prev.role,
                userID: prev.userID,
                jwtToken: jwtToken,
                currentPage: prev.currentPage
            })
        })

        localStorage.setItem("jwtToken", jwtToken)
    }

    function isAdminHandler() {
        const hash = crypto.createHash('sha256')
        hash.update('ADMIN')
        
        const userRole:string|null = localStorage.getItem("userRole")
        if(userRole === hash.digest('base64')) {
            return true
        } else {
            return false
        }
    }

    function isUserHandler() {
        const hash = crypto.createHash('sha256')
        hash.update('USER')

        const userRole:string|null = localStorage.getItem("userRole")
        if(userRole === hash.digest('base64')) {
            return true
        } else {
            return false
        }
    }

    function setRoleHandler(role: string) {
        setChangeUser((prev) => {
            return({
                role: role,
                userID: prev.userID,
                jwtToken: prev.jwtToken,
                currentPage: prev.currentPage
            })
        })

        localStorage.setItem("userRole", role)
    }

    function getStorageTokenHandler(): string|null {
        const jwtToken:string|null = localStorage.getItem("jwtToken")

        return jwtToken
    }

    function getUserIDHandler(): string|null {
        const userID:string|null = localStorage.getItem("userID")
        return userID
    }

    const context = {
        systemUser: changeUser,
        emailSuggestion: emailSuggestion,
        setEmailSuggestion: setEmailSuggestion,
        setCurrentPage: setCurrentUserPageHandler,
        setRole: setRoleHandler,
        setJWTToken: setJWTHandler,
        setUserID: setUserIDHandler,
        getStorageToken: getStorageTokenHandler,
        getUserID: getUserIDHandler,
        isAdmin: isAdminHandler,
        isUser: isUserHandler
    }

    return (
    <UserContext.Provider value={context}>
        {props.children}
    </UserContext.Provider>)
}


export default UserContext