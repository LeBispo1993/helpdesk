'use client'

import { createContext, useState, Dispatch, SetStateAction } from "react";
import Calling from "../interface/Calling";

let sendCalling: boolean = false
let setSendCalling: Dispatch<SetStateAction<boolean>>|any

const CallingContext = createContext({
    sendCalling,
    setSendCalling
})

export function CallingProvider(props: any) {

    const [sendCalling, setSendCalling] = useState<boolean>(false)

    const context = {
        sendCalling,
        setSendCalling
    }   

    return(
        <CallingContext.Provider value={context}>{props.children}</CallingContext.Provider>
    )

}

export default CallingContext