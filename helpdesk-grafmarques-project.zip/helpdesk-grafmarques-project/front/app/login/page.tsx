'use client'

import { CiRead } from "react-icons/ci";
import { CiUnread } from "react-icons/ci";


import React, { useState } from "react";
import { useRouter } from "next/navigation";

import { useContext, useEffect } from "react";

import Image from "next/image";

import logo_without_bg from '../../public/logo_without_background.png'
import styles from '../styles/loginPage.module.css'

import UserContext from "../context/userContext";

import ForgotPwdBox from "../component/forgotPwdBox";

import axios from 'axios'
import { hasActiveAdmin, loginUser } from "../functions/authentication";
import APIResponse from "../interface/ApiResponse";

import crypto from 'crypto'
import PopupMessage from "../component/popupMessage";

require("dotenv").config()

export default function LoginPage() {

    const adminDefaultPassword = process.env.NEXT_PUBLIC_ADMIN_DEFAULT_PASSWORD

    const userSystemContext = useContext(UserContext)
    const router = useRouter()

    const initialLoginError: {error: boolean, message: string} = {error: false, message: ""}

    const [loading, setLoading]                 = useState(false)
    const [loginError, setLoginError]           = useState(initialLoginError)
    const [openForgotPwd, setOpenForgotPwd]     = useState(false)

    const [seePassword, setSeePassword]         = useState<boolean>(false)

    async function loginIntoSystem(event:any) {
        event.preventDefault()

        console.log("ESSA É A SENHA DEFAULT DO ADMIN: " + adminDefaultPassword)

        setLoginError(
            initialLoginError
        )

        const userName: string = event.target[0].value
        const userPWD: string = event.target[1].value

        if(userName.length < 5) {
            setLoginError(
                {
                    error: true,
                    message: "O campo 'Login' deve ter pelo menos 8 caracteres"
                }
            )
            event.target[0].value = ""
            return
        }
        else if(userPWD.length < 8) {
            setLoginError(
                {
                    error: true,
                    message: "O campo 'Senha' deve ter pelo menos 8 caracteres"
                }
            )
            event.target[1].value = ""
            return
        }

        setLoading(true)

        if(userPWD.trim() == adminDefaultPassword) {

            console.log("Isso significa que o usuário digitou a senha do admin!!!")

            const hasAdmin: APIResponse = await hasActiveAdmin()

            if(!hasAdmin.response.value) {
                userSystemContext.setEmailSuggestion(userName)
                return router.push('/registrar_admin')
            }
        }

        const loginResponse: APIResponse = await loginUser(userName, userPWD)

        if(loginResponse.status == 200) {

            const hash = crypto.createHash('sha256')
            hash.update(loginResponse.response.userRole)

            userSystemContext.setRole(hash.digest('base64'))
            userSystemContext.setUserID(loginResponse.response.userId)
            userSystemContext.setJWTToken(loginResponse.response.token)
            localStorage.setItem("logged", "true")
            router.push('/main/home')
        } else{
            setLoginError(
                {
                    error: true,
                    message: loginResponse.response.title
                }
            )
        }

        setLoading(false)
    }

    useEffect(() => {
        localStorage.clear()
        localStorage.setItem("logged", "false")
    }, [])



    return(
        <div className={`${styles.container} font-bahnscrift_bold`}>

            <PopupMessage/>

            <div className={`${loginError.error ? styles.show_error : styles.dont_show}`}>
                <p>{loginError.message}</p>
            </div>

            <div className={`${styles.login_section}`}>
            
                <div className={`${styles.logo}`}>
                    <Image
                        src={logo_without_bg}
                        width={450}
                        className={`${styles.logo_img}`}
                        alt="imagem_da_logo"
                    />            

                    <h1 className="font-bahnscrift">SISTEMA DE CHAMADOS</h1>
                </div>

                <form onSubmit={(event) => loginIntoSystem(event)}
                    className={`flex flex-col gap-4 w-full ${styles.input_area}`}>
                    
                    <input 
                        type="text" 
                        placeholder='Login'
                        name="username" 
                        id="username" />

                    <div className={`${styles.password_div}`}>

                        <input 
                            type={`${seePassword ? "text" : "password"}`} 
                            placeholder="Senha" 
                            name="password" 
                            id="password" 
                            className={`${openForgotPwd ? styles.disappear : null}`}
                            />  

                        {seePassword
                            ?
                                <CiUnread 
                                    onClick={() => {
                                        setSeePassword((prev:boolean) => {
                                            return(!prev)
                                        })
                                    }} 
                                    className="text-2xl text-[#0860A8] absolute right-5 top-0 mt-3 hover:cursor-pointer"/>
                            :
                                <CiRead 
                                    onClick={() => {
                                        setSeePassword((prev:boolean) => {
                                            return(!prev)
                                        })
                                    }} 
                                    className="text-2xl text-[#0860A8] absolute right-5 top-0 mt-3 hover:cursor-pointer"/>
                            }

                    </div>
                    
                    {loading 
                        ? 
                            <div className={`${styles.loading} m-auto mt-4`}></div>
                        :
                            <button 
                                type="submit"
                                className={`${openForgotPwd ? styles.disappear : null}`}
                                >  
                                <p>Entrar</p>
                            </button>
                    }

                </form>

                {loading 
                    ?
                        null
                    :
                        <p
                        onClick={!openForgotPwd ? () => setOpenForgotPwd(true) : () => setOpenForgotPwd(false)} 
                        className={`${styles.forgot_password} ${openForgotPwd ? styles.disappear : null}`}>Esqueceu a senha? <span className="hover:cursor-pointer">Clique aqui</span></p>
                }

                {openForgotPwd 
                    ?
                        <ForgotPwdBox
                            setOpenForgotPwd={setOpenForgotPwd}
                        />
                    :
                        null
                }


            </div>

        </div>
    )
}