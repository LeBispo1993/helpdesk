import { Inter } from "next/font/google";
import "./globals.css";

import { useContext, useMemo } from "react";

import PageHeader from './component/pageHeader'

import * as path from 'path'

import localfont from 'next/font/local'
import { Router } from "next/router";
import { UserContextProvider } from "./context/userContext";
import { PopupProvider } from "./context/popupMessageContext";
import { CallingProvider } from "./context/callingContext";
import UserContext from "./context/userContext";

const inter = Inter({ subsets: ["latin"] });

const bahnschriftBold = localfont(
  {
    src: 
    [
      {
        path: '../public/fonts/bahnschrift.ttf',
        weight: '700'
      }
    ],
    variable: "--font-bahnschrift-bold"
  }
)

const bahnschriftRegular = localfont(
  {
    src: 
    [
      {
        path: '../public/fonts/bahnschrift.ttf',
        weight: '500'
      }
    ],
    variable: "--font-bahnschrift-regular"
  }
)


export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) 
{

  return (

    <UserContextProvider>
      <PopupProvider>
        <CallingProvider>
      <html lang="en">
        <body className={`${bahnschriftBold.variable}`}>
          {children}
        </body>
      </html>
      </CallingProvider>
      </PopupProvider>
      </UserContextProvider>
  );
}
