'use client'

import style from '../../styles/homePage.module.css'

import ItemRegister from "@/app/component/itemRegister";
import Where from "@/app/enum/Where";
import { Params } from "next/dist/shared/lib/router/utils/route-matcher";
import Image from 'next/image';

import logo_without_text from '../../../public/logo_with_text.jpg'

import { useEffect, useState } from "react";
import PopupMessage from '@/app/component/popupMessage';

import { useRouter } from 'next/navigation';

export default function PasswordRecovery({params}: any) {

    const route = useRouter()

    const [operationDone, setOperationDone] = useState<boolean>(false)
    const [registerScreen, setRegisterScreen] = useState<boolean>(true)

    
    useEffect(() => {
        
        if(!registerScreen) {
            setTimeout(() => {
                route.push('/')
            }, 1000)
        }
        
    }, [registerScreen])

    return(
        <div className={`${style.container}`}>

            <PopupMessage/>

            <Image
                src={logo_without_text}
                alt={"logo"}
                className='m-auto -mt-9'
            />

            <h1 className='font-bahnscrift_bold text-white text-center text-xl mt-4'>Recuperação de senha</h1>

            {registerScreen
                ?
                    <ItemRegister
                    itemA={{field: "Nova senha", placeholder: "Insira sua nova senha"}}
                    itemB={{field: "Confirmação", placeholder: "Confirme sua senha"}}
                    where={Where.pwd_recovery}
                    setOperationDone={setOperationDone}
                    setRegisterScreen={setRegisterScreen}
                    userID={params.slug}
                    />
                :
                    null}
        </div>
    )

}