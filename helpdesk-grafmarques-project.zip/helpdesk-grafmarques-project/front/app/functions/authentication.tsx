'use server'

import axios from 'axios'
import APIResponse from '../interface/ApiResponse'
import APIError from '../enum/APIError';
import User from '../interface/User';
require("dotenv").config();

const apiLink = process.env.NEXT_PUPLIC_API_LINK

export async function checkIfTokenIsValid(jwtToken: string|null): Promise<APIResponse> {

    const result: APIResponse = await axios.get(`${apiLink}/auth/check-token`, {
        headers: {
            Authorization: jwtToken
        }
    })

    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {
        return(
            {
                status:err.status,
                response:err.response
            }
        )
    })

    return result

}

export async function hasActiveAdmin(): Promise<APIResponse> {

    const result: APIResponse = await axios.get(`${apiLink}/api/v1/users/hasActiveAdmin`)
    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {
        console.log(err)
        return(
            {
                status:err.status,
                response:err.response.data
            }
        )
    })

    return result

}

export async function registerFirstAdmin(admin: User): Promise<APIResponse> {

    const result: APIResponse = await axios.post(`${apiLink}/auth/register-first-admin`, 
        {
            name: admin.name,
            email: admin.email,
            password: admin.password,
            role: "ADMIN",
            sector: {
                name: "T.I"
            }
        }
    )
    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {
        return(
            {
                status:err.status,
                response:err.response.data
            }
        )
    })

    return result

}

export async function changePasswordFromRecovery(userToChange: {id: string, pwd: string}): Promise<APIResponse> {

    const result: APIResponse = await axios.post(`${apiLink}/auth/recover-password`, 
        {   
            id: userToChange.id.trim(),
            password: userToChange.pwd.trim()
        }
    )
    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {
        return(
            {
                status:err.status,
                response:err.response.data
            }
        )
    })

    return result

}

export async function changePassword(jwtToken:string|null, userID: string|null, oldPassword: string, newPassword: string) : Promise<APIResponse> {

    const result = await axios.put(`${apiLink}/api/v1/users/change-password/${userID}` , 
        {
            oldPassword: oldPassword,
            newPassword: newPassword
        },
        {
            headers: {
                Authorization: jwtToken
            }
        }
    )
    .then((data) => {
        return(
            {
                status: data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {
        return(
            {
                status: err.status,
                response: err.response.data
            }
        )
    })
    
    return result

}

export async function passwordRecovery(userEmail:string): Promise<APIResponse> {

    const result = await axios.post(`${apiLink}/auth/send-password-recovery-email` , 
        {
            email: userEmail
        }
    )
    .then((data) => {
        return(
            {
                status: data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {
        return(
            {
                status: err.status,
                response: err.response.data
            }
        )
    })
    
    return result
}


export async function loginUser(email:string, password:string): Promise<APIResponse> {


    try {
        const result = await axios.post(`${apiLink}/auth/login`, 
        {   
            email: email,
            password: password
        }
        ).then((data) => {
            return(
                {
                    status: data.status,
                    response: data.data
                }
            )
        })
        .catch((err) => {
            console.log(err)
            return(
                {
                    status: err.status,
                    response: err.response.data
                }
            )
        })

        return(result)
    }catch(err) {
        return {
            status: 500,
            response: APIError.Connection
        }
    }
}