import Filter from "../interface/Filter"

export default function sendGridData(place: string, callingID?:string):Array<string[]>|null {
    let oppenedFilteredData: Array<string[]>|null = null

    if(place == "home") {
        oppenedFilteredData = dataToFetch.filter(element => element[2].includes('Aberto') || element[2].includes("Fechado"))
    } else if (place == "myCallings") {
        oppenedFilteredData = dataToFetch.filter(element => element[2].includes('Processando'))
    } else if (place == "callingDetail") {
        oppenedFilteredData = dataToFetch.filter(element => element[0] == callingID)

    }
    
    return(oppenedFilteredData)
}


const dataToFetch: Array<string[]> = 
[
    ['1', 'Quebrei o mouse', 'Aberto', 'Média', 'Informática', '03/08/2024', '04/08/2024' ,'Requerente 01', 'Autor 10'],
    ['2', 'Trocar lâmpada', 'Aberto', 'Baixa', 'Manutenção', '02/08/2024', '03/08/2024' ,'Requerente 03', 'Autor 02'],
    ['3', 'Atualizar antivírus', 'Aberto', 'Alta', 'Informática', '01/08/2024', '04/08/2024' ,'Requerente 02', 'Autor 02'],
    ['4', 'Consertar cadeira', 'Aberto', 'Média', 'Manutenção', '03/08/2024', '04/08/2024' ,'Requerente 03', 'Autor 02'],
    ['5', 'Instalar impressora', 'Fechado', 'Baixa', 'Informática', '05/08/2024', '06/08/2024' ,'Requerente 02', 'Autor 03'],
    ['6', 'Reparar ar-condicionado', 'Processando', 'Alta', 'Manutenção', '06/08/2024', '07/08/2024' ,'Requerente 02', 'Autor 04'],
    ['7', 'Configurar Wi-Fi', 'Fechado', 'Média', 'Informática', '07/08/2024', '08/08/2024' ,'Requerente 03', 'Autor 03'],
    ['8', 'Substituir teclado', 'Processando', 'Baixa', 'Informática', '08/08/2024', '09/08/2024' ,'Requerente 05', 'Autor 03'],
    ['9', 'Trocar filtro de água', 'Processando', 'Média', 'Manutenção', '09/08/2024', '10/08/2024' ,'Requerente 05', 'Autor 04'],
    ['10', 'Atualizar sistema operacional', 'Processando', 'Alta', 'Informática', '10/08/2024', '11/08/2024' ,'Requerente 04', 'Autor 07'],
    ['11', 'Reparar elevador', 'Fechado', 'Alta', 'Manutenção', '11/08/2024', '12/08/2024', 'Pedro', 'Autor 04'],
    ['12', 'Configurar projetor', 'Processando', 'Média', 'Informática', '12/08/2024', '13/08/2024','Requerente 04', 'Autor 07']
]