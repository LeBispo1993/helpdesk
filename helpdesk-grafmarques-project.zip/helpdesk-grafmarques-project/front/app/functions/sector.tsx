'use server'

import axios from 'axios'
import APIResponse from '../interface/ApiResponse'

require("dotenv").config();

const apiLink = process.env.NEXT_PUPLIC_API_LINK

export async function activateSectorByID(jwtToken: string|null, sectorID:string): Promise<APIResponse> {

    const result: APIResponse = await axios.put(`${apiLink}/api/v1/sectors/activate/${sectorID}`, 
    {},
    {
      headers: {
      Authorization: jwtToken
      }
    }
  )
  .then((data) => {
    return(
      {
        status: data.status,
        response: data.data
      }
    )
  })
  .catch((err) => {
    return(
      {
        status: err.status,
        response: err.response.data
      }
    )
  })
  
  return result

}

export async function deleteSectorByID(jwtToken: string|null, sectorID:string): Promise<APIResponse> {

    const result: APIResponse = await axios.put(`${apiLink}/api/v1/sectors/deactivate/${sectorID}`, 
    {},
    {
      headers: {
      Authorization: jwtToken
      }
    }
  )
  .then((data) => {
    return(
      {
        status: data.status,
        response: data.data
      }
    )
  })
  .catch((err) => {
    return(
      {
        status: err.status,
        response: err.response.data
      }
    )
  })
  
  return result

}

export async function createNewSector(jwtToken: string|null, sector:{name: string, answerForCallings: boolean}): Promise<APIResponse> {
    
    const result: APIResponse = await axios.post(`${apiLink}/api/v1/sectors`, 
        {
            name: sector.name.trim(),
            server: sector.answerForCallings
        },
        {
            headers: {
                Authorization: jwtToken
            }
        }
    )
    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {

        return(
            {
                status:err.status,
                response:err.response.data
            }
        )
    })

    return result
}

export async function getAllSectorsForAdminPage(jwtToken:string|null): Promise<APIResponse> {

    const result: APIResponse = await axios.get(`${apiLink}/api/v1/sectors`, 
        {
            headers: {
                Authorization: `${jwtToken}`
            }
        }
    )
    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {

        return(
            {
                status:err.status,
                response:err.response.data
            }
        )
    })

    return result
}

export async function getAllSectors(jwtToken:string|null, onlyAgents?: boolean): Promise<APIResponse> {

  let setOnlyAgents:string = ""

  onlyAgents ? setOnlyAgents = "?server=true" : null

    const result: APIResponse = await axios.get(`${apiLink}/api/v1/sectors/list${setOnlyAgents}`, 
        {
            headers: {
                Authorization: `${jwtToken}`
            }
        }
    )
    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {

        return(
            {
                status:err.status,
                response:err.response.data
            }
        )
    })

    return result
}
