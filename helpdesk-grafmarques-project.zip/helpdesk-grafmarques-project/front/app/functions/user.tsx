'use server'

import axios from 'axios'
import APIResponse from '../interface/ApiResponse'
import User from '../interface/User';
import Role from '../enum/Role';
import APIError from '../enum/APIError';
require("dotenv").config();

const apiLink = process.env.NEXT_PUPLIC_API_LINK


export async function activateUser(jwtToken:string|null, userID:string): Promise<APIResponse> {

    const result: APIResponse = await axios.put(`${apiLink}/api/v1/users/activate/${userID}`, 
        {},
        {
            headers: {
                Authorization: jwtToken
            }
        }
    )
    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {
        return(
            {
                status:err.status,
                response:err.response.data
            }
        )
    })

    return result

}

export async function deactivateUser(jwtToken:string|null, userID:string): Promise<APIResponse> {

    const result: APIResponse = await axios.put(`${apiLink}/api/v1/users/deactivate/${userID}`, 
        {},
        {
            headers: {
                Authorization: jwtToken
            }
        }
    )
    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {
        return(
            {
                status:err.status,
                response:err.response.data
            }
        )
    })

    return result

}

export async function editUser(jwtToken: string|null, user: User): Promise<APIResponse> {

    let userRole: string

    if(user.role == "Usuário") {
        userRole = "USER"
    } else if(user.role == "Agente") {
        userRole = "AGENT"
    } else {
        userRole = "ADMIN"
    }

    const result: APIResponse = await axios.put(`${apiLink}/api/v1/users`, 
        {   
            id: user.id,
            name: user.name.trim(),
            email: user.email.trim(),
            password: user.password?.trim(),
            sector: {
                id: user.sector.id
            },
            role: userRole
        },
        {
            headers: {
                Authorization: jwtToken
            }
        }
    )
    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {
        return(
            {
                status:err.status,
                response:err.response.data
            }
        )
    })

    return result

}

export async function postUserRegistration(jwtToken: string|null, user:User): Promise<APIResponse> {

    let userRole: string = ""

    if(user.role == Role.ADMIN) {
        userRole = "ADMIN"
    } else if(user.role == Role.AGENT) {
        userRole = "AGENT"
    } else if(user.role == Role.USER) {
        userRole = "USER"
    }

        
    const result: APIResponse = await axios.post(`${apiLink}/auth/register`, 
        {
            name: user.name.trim(),
            email: user.email.trim(),
            role: userRole,
            password: user.password,
            sector: {
                id: user.sector.id
            }
        },
        {
            headers: {
                Authorization: jwtToken
            }
        }
    )
    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {
        return(
            {
                status:err.status,
                response:err.response.data
            }
        )
    })

    return result
}

export async function getAllUsers(jwtToken: string|null): Promise<APIResponse> {

    const result: APIResponse = await axios.get(`${apiLink}/api/v1/users`, {
        headers: {
            Authorization: jwtToken
        }
    })
    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {
        return(
            {
                status:err.status,
                response:err.response.data
            }
        )
    })


    return result

}

export async function getUserByID(jwtToken: string|null, userID: string|null): Promise<APIResponse> {

    const result: APIResponse = await axios.get(`${apiLink}/api/v1/users/${userID}`, {
        headers: {
            Authorization: jwtToken
        }
    })
    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {
        return(
            {
                status:err.status,
                response:err.response.data
            }
        )
    })
    
    return result
}