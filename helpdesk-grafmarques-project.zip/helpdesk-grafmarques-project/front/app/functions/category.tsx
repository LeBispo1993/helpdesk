'use server'

import axios from 'axios'
import APIResponse from '../interface/ApiResponse'

require("dotenv").config();

const apiLink = process.env.NEXT_PUPLIC_API_LINK

export async function activateCategoryByID(jwtToken: string|null, categoryID: string): Promise<APIResponse> {

  const result: APIResponse = await axios.put(`${apiLink}/api/v1/categories/activate/${categoryID}`, 
    {},
    {
      headers: {
      Authorization: jwtToken
      }
    }
  )
  .then((data) => {
    return(
      {
        status: data.status,
        response: data.data
      }
    )
  })
  .catch((err) => {
    return(
      {
        status: err.status,
        response: err.response.data
      }
    )
  })
  
  return result

}

export async function deleteCategoryByID(jwtToken: string|null, categoryID: string): Promise<APIResponse> {

  const result: APIResponse = await axios.put(`${apiLink}/api/v1/categories/deactivate/${categoryID}`, 
    {},
    {
      headers: {
      Authorization: jwtToken
      }
    }
  )
  .then((data) => {
    return(
      {
        status: data.status,
        response: data.data
      }
    )
  })
  .catch((err) => {
    return(
      {
        status: err.status,
        response: err.response.data
      }
    )
  })
  
  return result

}

export async function createNewCategory(jwtToken: string|null, categoryName:string): Promise<APIResponse> {

  const result: APIResponse = await axios.post(`${apiLink}/api/v1/categories`,
    {
      name: categoryName.trim()
    },
    {
      headers: {
        Authorization: jwtToken
      }
    }
  )
  .then((data) => {
    return(
      {
        status: data.status,
        response: data.data
      }
    )
  })
  .catch((err) => {
    return(
      {
        status: err.status,
        response: err.response.data
      }
    )
  })
  return result

}

export async function getAllCategoriesForAdminPage(jwtToken:string|null): Promise<APIResponse> {

  const allCategories = await axios.get(`${apiLink}/api/v1/categories`, 
  {
      headers: {
          Authorization: `Bearer ${jwtToken}`
      }
  }
) 
  .then((data) => {
    return(
      {
        status: data.status,
        response: data.data
      }
    )
  })
  .catch((err) => {
    return(
      {
        status: err.status,
        response: err.response.data
      }
    )
  })  

  return allCategories
}

export async function getAllCategories(jwtToken:string|null): Promise<APIResponse> {

    const allCategories = await axios.get(`${apiLink}/api/v1/categories/list`, 
    {
        headers: {
            Authorization: `Bearer ${jwtToken}`
        }
    }
) 
    .then((data) => {
      return(
        {
          status: data.status,
          response: data.data
        }
      )
    })
    .catch((err) => {
      return(
        {
          status: err.status,
          response: err.response.data
        }
      )
    })  


    return allCategories
}

