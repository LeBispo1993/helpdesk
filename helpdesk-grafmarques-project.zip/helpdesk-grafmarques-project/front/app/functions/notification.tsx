'use server'

import axios from 'axios'
import APIResponse from '../interface/ApiResponse'
import { useEffect } from 'react';
require("dotenv").config();

const apiLink = process.env.NEXT_PUPLIC_API_LINK

export async function getUserNotification(jwtToken:string|null, page:string): Promise<APIResponse> {

    const result = await axios.get(`${apiLink}/api/v1/notifications?page=${page}&size=7&direction=desc`, {
        headers: {
            Authorization: jwtToken
        }
    })
    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {
        return(
            {
                status:err.status,
                response:err.response.data
            }
        )
    })

    return result

}


export async function getUserNotificationNumber(jwtToken:string|null): Promise<APIResponse> {

    const result = await axios.get(`${apiLink}/api/v1/notifications/count-not-viewed`, {
        headers: {
            Authorization: jwtToken
        }
    })
    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {

        return(
            {
                status:err.status,
                response:err.response.data
            }
        )
    })
    return result
}

export async function setNotificationAsViewed(jwtToken:string|null, notificationsID: string[]) {

    const result = await axios.put(`${apiLink}/api/v1/notifications/view`, 
    {
        ids: notificationsID
    },
    {
        headers: {
            Authorization: jwtToken
        }
    }
    )
    .then((data) => {
        return(
            {
                status: data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {
        return(
            {
                status:err.status,
                response:err.response.data
            }
        )
    })

}

export async function deleteNotificationByID(jwtToken:string|null, notificationID: string) {

    const result = await axios.delete(`${apiLink}/api/v1/notifications/${notificationID}`, {
        headers: {
            Authorization: jwtToken
        }
    })
    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {
        return(
            {
                status:err.status,
                response:err.response
            }
        )
    })
    return result
}

export async function deleteAllNotifications(jwtToken:string|null): Promise<APIResponse> {

    const result = await axios.delete(`${apiLink}/api/v1/notifications/delete-all`, {
        headers: {
            Authorization: jwtToken
        }
    })
    .then((data) => {
        return(
            {
                status:data.status,
                response: data.data
            }
        )
    })
    .catch((err) => {
        return(
            {
                status:err.status,
                response:err.response.data
            }
        )
    })
    return result
}