'use server'

import axios from 'axios'
import APIResponse from '../interface/ApiResponse'
import Calling from '../interface/Calling'
import Filter from '../interface/Filter';
import moment from 'moment';
import Item from '../interface/Item';

require("dotenv").config();

const apiLink = process.env.NEXT_PUPLIC_API_LINK


export async function deleteCalling(jwtToken: string|null, ticketID: string|null) {

  const result: APIResponse = await axios.put(`${apiLink}/api/v1/tickets/deactivate/${ticketID}`, 
    {},
    {
      headers: {
      Authorization: jwtToken
    }
    }
  )
  .then((data) => {
    return(
      {
        status: data.status,
        response: data.data
      }
    )
  })
  .catch((err) => {
    return(
      {
        status: err.status,
        response: err.response.data
      }
    )
  })

  return result

}

export async function closeCallingPut(jwtToken: string|null, ticketID: string): Promise<APIResponse> {

  const result: APIResponse = await axios.put(`${apiLink}/api/v1/tickets/close/${ticketID}`, 
    {},
    {headers: {
      Authorization: jwtToken
    }}
  )
  .then((data) => {
    return(
      {
        status: data.status,
        response: data.data
      }
    )
  })
  .catch((err) => {
    return(
      {
        status: err.status,
        response: err.response.data
      }
    )
  })

  return result

}

export async function addCommentToTicket(jwtToken: string|null, comment:string, ticketID:string): Promise<APIResponse> {

  const result: APIResponse = await axios.post(`${apiLink}/api/v1/tickets/comments`, 
    {
      content: comment,
      ticket: {
        id: ticketID
      }
    },
    {
      headers: {
        Authorization: jwtToken
      }
    }
  )
  .then((data) => {
    return(
      {
        status: data.status,
        response: data.data
      }
    )
  })
  .catch((err) => {
    return(
      {
        status: err.status,
        response: err.response.data
      }
    )
  })

  return result

}

export async function assignTicketByID(jwtToken: string|null, ticketID: string) {

  const result: APIResponse = await axios.put(`${apiLink}/api/v1/tickets/assign/${ticketID}`, 
    {},
    {
      headers: {
      Authorization: jwtToken
    }
    }
  )
  .then((data) => {
    return(
      {
        status: data.status,
        response: data.data
      }
    )
  })
  .catch((err) => {
    return(
      {
        status: err.status,
        response: err.response.data
      }
    )
  })

  return result

}

export async function getCallingByID(jwtToken: string|null, ticketID: string): Promise<APIResponse> {

  const result: APIResponse = await axios.get(`${apiLink}/api/v1/tickets/${ticketID}`, {
    headers: {
      Authorization: jwtToken
    }
  })
  .then((data) => {
    return(
      {
        status: data.status,
        response: data.data
      }
    )
  })
  .catch((err) => {
    return(
      {
        status: err.status,
        response: err.response.data
      }
    )
  })

  return result

}

export async function getAdminPageCallings(jwtToken: string|null, filter?: Filter): Promise<APIResponse> {

  let callingStatus
  let todayDate: Date|string = ""
  let lastWeekDate: Date|string = ""
  let categoriesIDList
  let priorities

  if(!filter) {
    todayDate = moment().format("YYYY-MM-DD")
    lastWeekDate = moment().subtract(7, 'days').format("YYYY-MM-DD")

    callingStatus = ["ABERTO", "PROCESSANDO", "FECHADO"]
    priorities = ["BAIXA", "MÉDIA", "ALTA", "AGENDAMENTO"]

    categoriesIDList = null
  } else {
    todayDate = filter.dateUntil
    lastWeekDate = filter.dateFrom

    if(JSON.stringify(filter.status.status) == "[null]") {
      callingStatus = null
    } else {
      callingStatus = [...filter.status.status]
    }

    if(JSON.stringify(filter.priority.priority) == "[null]") {
      priorities = null
    } else {
      priorities = [...filter.priority.priority]
    }

    if(filter.category[0].id == '0') {
      categoriesIDList = null
    } else {
      categoriesIDList = filter.category.map((element: Item) => element.id)
    }
  }

  const result = await axios.post(`${apiLink}/api/v1/tickets/admin`,
  {
      startDate: lastWeekDate,
      endDate: todayDate,
      status: callingStatus,
      categories: categoriesIDList,
      priorities: priorities
  },
    {
      headers: {
        Authorization: jwtToken
      },
    }
  )
  .then((data) => {
    return(
      {
        status: data.status,
        response: data.data
      }
    )
  })
  .catch((err) => {
    return(
      {
        status: err.status,
        response: err.response.data
      }
    )
  })

  return result
}

export async function getDefaultUserCallings(jwtToken: string|null, filter?: Filter): Promise<APIResponse> {

  let callingStatus
  let todayDate: Date|string = ""
  let lastWeekDate: Date|string = ""
  let categoriesIDList
  let priorities

  if(!filter) {
    todayDate = moment().format("YYYY-MM-DD")
    lastWeekDate = moment().subtract(7, 'days').format("YYYY-MM-DD")

    callingStatus = ["ABERTO", "PROCESSANDO", "FECHADO"]
    priorities = ["BAIXA", "MÉDIA", "ALTA", "AGENDAMENTO"]

    categoriesIDList = null
  } else {
    todayDate = filter.dateUntil
    lastWeekDate = filter.dateFrom

    if(JSON.stringify(filter.status.status) == "[null]") {
      callingStatus = null
    } else {
      callingStatus = [...filter.status.status]
    }

    if(JSON.stringify(filter.priority.priority) == "[null]") {
      priorities = null
    } else {
      priorities = [...filter.priority.priority]
    }

    if(filter.category[0].id == '0') {
      categoriesIDList = null
    } else {
      categoriesIDList = filter.category.map((element: Item) => element.id)
    }
  }

  const result = await axios.post(`${apiLink}/api/v1/tickets/author`,
  {
      startDate: lastWeekDate,
      endDate: todayDate,
      status: callingStatus,
      categories: categoriesIDList,
      priorities: priorities
  },
    {
      headers: {
        Authorization: jwtToken
      },
    }
  )
  .then((data) => {
    return(
      {
        status: data.status,
        response: data.data
      }
    )
  })
  .catch((err) => {
    return(
      {
        status: err.status,
        response: err.response.data
      }
    )
  })

  return result
}

export async function getDefaultHomeCallings(jwtToken: string|null, filter?: Filter): Promise<APIResponse> {

  let callingStatus
  let todayDate: Date|string = ""
  let lastWeekDate: Date|string = ""
  let categoriesIDList
  let priorities

  if(!filter) {
    todayDate = moment().format("YYYY-MM-DD")
    lastWeekDate = moment().subtract(7, 'days').format("YYYY-MM-DD")

    callingStatus = ["ABERTO", "PROCESSANDO", "FECHADO"]
    priorities = ["BAIXA", "MÉDIA", "ALTA", "AGENDAMENTO"]

    categoriesIDList = null
  } else {
    todayDate = filter.dateUntil
    lastWeekDate = filter.dateFrom

    if(JSON.stringify(filter.status.status) == "[null]") {
      callingStatus = null
    } else {
      callingStatus = [...filter.status.status]
    }

    if(JSON.stringify(filter.priority.priority) == "[null]") {
      priorities = null
    } else {
      priorities = [...filter.priority.priority]
    }

    if(filter.category[0].id == '0') {
      categoriesIDList = null
    } else {
      categoriesIDList = filter.category.map((element: Item) => element.id)
    }
  }

  
  const result = await axios.post(`${apiLink}/api/v1/tickets/home`,
  {
      startDate: lastWeekDate,
      endDate: todayDate,
      status: callingStatus,
      categories: categoriesIDList,
      priorities: priorities
  },
    {
      headers: {
        Authorization: jwtToken
      },
    }
  )
  .then((data) => {
    return(
      {
        status: data.status,
        response: data.data
      }
    )
  })
  .catch((err) => {
    return(
      {
        status: err.status,
        response: err.response.data
      }
    )
  })

  return result
    
}

export async function createCalling(jwtToken: string|null, calling:Calling): Promise<APIResponse>{

    const result = await axios.post(`${apiLink}/api/v1/tickets`, 
        {
            title: calling.title,
            description: calling.description,
            applicant: calling.applicant,
            priority: calling.priority,
            sector: {
              id: calling.sector
            },
            category: {
              id: calling.category
            }
        },
        {
          headers: {
            Authorization: jwtToken
          }
        }
    )
    .then((data) => {
      return(
        {
          status: data.status,
          response: data.data
        }
      )
    })
    .catch((err) => {
      return(
        {
          status: err.status,
          response: err.response.data
        }
      )
    })

    return result

}