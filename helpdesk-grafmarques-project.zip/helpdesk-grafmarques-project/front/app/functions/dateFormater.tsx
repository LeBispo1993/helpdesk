export default function DateFormater(date:string): string {

    const responseDate: string = new Date(date).toLocaleDateString()
    const responseTime: string = new Date(date).toLocaleTimeString()

    return `${responseDate} ${responseTime}`
}