'use client'

import style from '../../styles/notification.module.css'

import notificationLetter from '../../../public/notification_letter.svg'
import notificationTrash from '../../../public/notification_trash.svg'

import { useState, useEffect, useContext, useRef } from 'react'

import { useRouter } from 'next/navigation'

import UserContext from '@/app/context/userContext'
import PopupContext from '@/app/context/popupMessageContext'

import Image from 'next/image'
import { Params } from 'next/dist/shared/lib/router/utils/route-matcher'
import { deleteAllNotifications, deleteNotificationByID, getUserNotification, setNotificationAsViewed } from '@/app/functions/notification'
import APIResponse from '@/app/interface/ApiResponse'
import Notification from '@/app/interface/Notification'
import PopupMessage from '@/app/component/popupMessage'
import PaginationComponent from '@/app/component/paginationComponent'

let notifications: Array<Notification|null> = []


export default function NotificationPage({searchParams}:any) {

    const router = useRouter()

    const userSystemContext = useContext(UserContext)
    const popupContext = useContext(PopupContext)
    
    const [notificationList, setNotificationList]   = useState<Array<Notification>|null>() 
    const [count, setCount]                         = useState(0)

    const [currentPage, setCurrentPage]             = useState<number>(1)
    const [totalPages, setTotalPages]               = useState<number>(0)

    const countRef = useRef(count)
    

    const onHandleDeleteNotification = (notificationID: string) => {

        if(notificationList != null) {
            const newList: Notification[] = notificationList.filter((element) => {
                return element.id != notificationID
            })
    
            setNotificationList(newList)
        }
    }

    const onHandleCleanItAll = () => {

        let emptyArray: Array<Notification> = []
        setNotificationList(emptyArray)

        deleteAllNotifications(userSystemContext.systemUser.jwtToken)

    }

    async function deleteNotificationByIDHandler(notificationID: string) {
        const apiResponse: APIResponse = await deleteNotificationByID(userSystemContext.systemUser.jwtToken, notificationID)
    }

    async function getAllNotifications() {

        const jwtToken:string|null = userSystemContext.getStorageToken()
        const apiResponse: APIResponse = await getUserNotification(jwtToken, (currentPage - 1).toString())

        if(apiResponse.status == 200 && apiResponse.response.page.totalElements > 0) {
            const currentPageNotification: Array<Notification> = apiResponse.response._embedded.notificationDTOList.map((element:Notification) => {

                const crudeDate:Date = new Date(element.createdAt)
                const formattedDate = crudeDate.toLocaleString()

                return(
                    {
                        id: element.id,
                        content: element.content,
                        createdAt: formattedDate,
                        viewed: element.viewed,
                        ticket: element.ticket
                    }
                )
            })

            setTotalPages(apiResponse.response.page.totalPages)
            setNotificationList(currentPageNotification)

            const notificationsID: string[] = currentPageNotification.map((element:Notification) => {
                return (
                    element.id
                )
            })
            await setNotificationAsViewed(jwtToken, notificationsID)
        }

    }

    async function redirectToCallingPage(callingID:string) {
        router.push(`/main/chamado/${callingID}`)
    }

    useEffect(() => {
        getAllNotifications()
        userSystemContext.setCurrentPage("notificacao")
    }, [countRef])

    useEffect(() => {
        getAllNotifications()
    }, [currentPage])

    return(
        <div className={`${style.container} text-white`}>

            <PopupMessage/>

            <div className={`flex gap-10 ${style.top_of_notification}`}>
                <h1 className='font-bahnscrift_bold text-2xl ml-12'>Todas as notificações</h1>

                <button
                    onClick={onHandleCleanItAll}
                    className={`border-solid border-[.1rem] px-3 rounded-md border-[#DD1D8B] text-[#DD1D8B] hover:bg-[#DD1D8B] hover:text-white ${style.clean_everything_button}`}>Limpar Tudo</button>
            </div>

            <div className={`${style.notification_box}`}>

                {notificationList == null
                    ?
                        <p className='block m-auto py-48 text-center text-xl w-1/2 h-[50vh]' >Sem notificações...</p>
                    :
                        notificationList.map((element) => (
                            <div
                            className={`${style.notification_item} relative`}
                            key={element.id}>

                                <div onClick={() => element.ticket ? redirectToCallingPage(element.ticket?.id) : null} >
                                    <div className={`${style.notification_header}`}>

                                        <Image
                                            alt="carta_notificacao_icone"
                                            src={notificationLetter}
                                        />

                                        <p className='font-bahnscrift_bold text-xl'>Notificação</p>

                                        <p className='opacity-55 font-bahnscrift_bold'>{element.createdAt}</p>

                                    </div>

                                    <p className='-mt-8 ml-[3.6rem] w-[80%]'>{element.content} {element.ticket?.os ? `(OS: ${element.ticket.os})` : null}</p>
                                </div>

                                <Image
                                    onClick={() => {deleteNotificationByIDHandler(element.id),
                                        onHandleDeleteNotification(element.id)
                                    }}
                                    alt="lixo_notificacao_icone"
                                    src={notificationTrash}
                                    className={`absolute right-0 top-0 hover:cursor-pointer ${style.trash_icon}`}
                                />

                                <hr 
                                    className='opacity-40 mt-3'
                                />
                                
                            </div>
                        ))}

            </div>

                <PaginationComponent
                    pages={totalPages}
                    currentPage={currentPage}
                    setCurrentPage={setCurrentPage}
                />
        </div>
    )
}