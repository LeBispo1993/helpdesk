'use client'

import PageHeader from "../component/pageHeader"
import { UserContextProvider } from "../context/userContext"
import UserContext from "../context/userContext"
import { useRouter } from "next/navigation"

import { useEffect, useContext } from 'react'
import { checkIfTokenIsValid } from "../functions/authentication"
import APIResponse from "../interface/ApiResponse"
import PopupContext from "../context/popupMessageContext"
import PopupMessage from "../component/popupMessage"

export default function MainLayout({children}: any) {

    const router = useRouter()
    const userContext = useContext(UserContext)
    const popupContext = useContext(PopupContext)

    async function takeUserToLogin() {

        const userLogged: string|null = localStorage.getItem("logged")
        if(userLogged == "false" || !userLogged) {
            popupContext.setShowError()
            router.push("/")
        }    

        const userJWT: string|null = userContext.getStorageToken()
        const expiredToken: APIResponse = await checkIfTokenIsValid(userJWT)

        if(expiredToken.status == 403) {
            router.push("/")
        }
    }

    useEffect(() => {
        takeUserToLogin()
    }, [])

    return(
        <>
            <PopupMessage/>
            <PageHeader/>
            {children}
        </>
    )
}