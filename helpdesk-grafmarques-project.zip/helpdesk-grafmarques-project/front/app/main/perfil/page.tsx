'use client'

import grayProfileIcon from '../../../public/gray_profile_icon.svg'
import closeIcon from '../../../public/close_icon.svg'

import Image from 'next/image'
import { useRouter } from 'next/navigation'

import style from '../../styles/profile.module.css'

import User from '@/app/interface/User'

import { CiRead } from "react-icons/ci";
import { CiUnread } from "react-icons/ci";

import { useState, useEffect, useContext } from 'react'

import UserContext from '@/app/context/userContext'
import { getUserByID } from '@/app/functions/user'
import UserProfile from '@/app/component/userProfile'

export default function ProfilePage() {

    const [operationDone, setOperationDone] = useState<boolean>(false)


    return(
        <UserProfile
            setOperationDone={setOperationDone}
        />
    )
}