'use client'

import { useState, useEffect, useContext } from 'react'

import { useRouter } from 'next/navigation';

import GridComponent from '@/app/component/gridComponent'

import userContext from '@/app/context/userContext';
import PopupContext from '@/app/context/popupMessageContext';
import CallingContext from '@/app/context/callingContext';

import style from '../../styles/myCallings.module.css'
import FilteringComponent from '@/app/component/filteringComponent'
import Filter from '@/app/interface/Filter';
import APIResponse from '@/app/interface/ApiResponse';
import { getDefaultUserCallings } from '@/app/functions/calling';
import Calling from '@/app/interface/Calling';
import TableLoading from '@/app/component/tableLoading';
import PopupMessage from '@/app/component/popupMessage';

export default function MyCallings() {


    const router                        = useRouter()
    const userSystemContext             = useContext(userContext)
    const callingContext                = useContext(CallingContext)
    const popupContext                  = useContext(PopupContext)

    const [gridData, setGridData]       = useState<Array<string[]>|null>([])
    const [changeData, setChangeData]   = useState<boolean>(false)
    const [filter, setFilter]           = useState<Filter|null>()
    const [loadingGrid, setLoadingGrid] = useState<boolean>(false)
    const [hasData, setHasData]         = useState<boolean>(false)

    const [windowWidth, setWindowWidth] = useState<number>(0)
    const [lowWidth, setLowWidth]       = useState<boolean>(false)


    async function getUserCallings(filter?: Filter) {

        const jwtToken:string|null = userSystemContext.getStorageToken()
        setLoadingGrid(true)

        const apiResponse: APIResponse = await getDefaultUserCallings(jwtToken, filter)

        if(apiResponse.status != 200) {
            setLoadingGrid(false)
            popupContext.setErrorMessage(apiResponse.response.title)
            popupContext.setShowError(true)
        }

        if(apiResponse.status == 200) {

            callingContext.setSendCalling(false)

            if(apiResponse.response.length > 0) {

                setHasData(true)
                
                const callingItems: Array<string[]> = apiResponse.response.map((element: Calling) => {

                const formattedCreatedAt:string = new Date(element.createdAt).toLocaleDateString()
                const formattedUpdatedAt:string = new Date(element.updatedAt).toLocaleDateString()

                return (
                    [
                        element.id,
                        element.os,
                        element.title,
                        element.status,
                        element.priority,
                        element.category.name,
                        element.sector.name,
                        formattedCreatedAt,
                        formattedUpdatedAt,
                        element.applicant,
                        element.author.name
                    ]
                )
                
            })
            setLoadingGrid(false)
            callingContext.setSendCalling(true)
            localStorage.setItem("home_array", JSON.stringify(callingItems))
            } else {
                setHasData(false)
                setLoadingGrid(false)
                callingContext.setSendCalling(true)
                localStorage.setItem("home_array", "[]")
            }
        }
        
    }

    useEffect(() => {
        if(filter != null) {
            getUserCallings(filter)
        }
    }, [filter])

    useEffect(() => {
        getUserCallings()
        userSystemContext.setCurrentPage("meus_chamados")
    }, [])

    useEffect(() => {

        if(windowWidth == 0) {
            setWindowWidth(window.innerWidth)
        }

        const handleResize = () => {
            setWindowWidth(window.innerWidth)
        };
        window.addEventListener("resize", handleResize);
        return () => window.removeEventListener("resize", handleResize);
      }, []);

    useEffect(() => {
                    
        if(windowWidth <= 768) {
            setLowWidth(true)
        } else{
            setLowWidth(false)
        }
    }, [windowWidth])

    return(

        <div className={`${style.container}`}>

            <PopupMessage/>

            {lowWidth
                ?
                    <div >
                        <h1 className={`text-white font-bahnscrift_bold text-xl text-center mt-2 mb-3`}>MEUS CHAMADOS</h1>
                        <hr className='text-grey opacity-35 w-[10%] mx-auto pb-5'/>
                    </div>
                :
                    null
            }   

            <h1 className={`font-bahnscrift_bold text-white text-center`}>
                FILTRAR POR
            </h1>

            <FilteringComponent
                setFilter={setFilter}
            />

                {loadingGrid 
                    ?
                        <TableLoading/>
                    :
                        !hasData 
                            ?   
                                <h1 className={`text-center text-white mt-[5rem] text-xl animate-bounce`}>Sem dados para esse filtro 🤨</h1>
                            :
                            <GridComponent
                                changeData={changeData}
                                gridData={gridData}
                        />
                }
        </div>
    )
}