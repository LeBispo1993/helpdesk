'use client'

import { useEffect, useState, useContext } from 'react'

import UserContext from '@/app/context/userContext'
import PopupContext	 from '@/app/context/popupMessageContext'

import closeIcon from '../../../../public/close_icon.svg'

import Image from 'next/image'
import { useRouter } from 'next/navigation'

import style from '../../../styles/callingDetails.module.css'
import sendGridData from '@/app/functions/sendGridData'
import Calling from '@/app/interface/Calling'
import APIResponse from '@/app/interface/ApiResponse'
import { addCommentToTicket, assignTicketByID, closeCallingPut, deleteCalling, getCallingByID } from '@/app/functions/calling'
import moment from 'moment'
import LoadingSpecificCalling from '@/app/component/loadingSpecificCalling'
import PopupMessage from '@/app/component/popupMessage'
import Comment from '@/app/interface/Comment'
import DateFormater from '@/app/functions/dateFormater'
import Role from '@/app/enum/Role'

type Slug = {
    slug: string
}

interface CallingID {
    params: Slug
}

export default function CallingScreen({params}: CallingID) {

    const router                                            = useRouter()
    const systemUserContext                                 = useContext(UserContext)
    const popupContext                                      = useContext(PopupContext)

    const [commentList, setCommentList]                     = useState<Array<Comment>|null>()

    const [reloadCalling, setReloadingCalling]              = useState<boolean>(false)
    const [assignLoading, setAssignLoading]                 = useState<boolean>(false)
    const [endCallingLoading, setEndCallingLoading]         = useState<boolean>(false)
    const [deleteCallingLoading, setDeleteCallingLoading]   = useState<boolean>(false)

    const [reloadNewComment, setReloadNewComment]           = useState<boolean>(false)

    const [calling, setCalling]                             = useState<Calling|null>()
    const [addComment, setAddComment]                       = useState<boolean>(false)
    const [textLength, setTextLength]                       = useState<number>(0)
    const [newComment, setNewComment]                       = useState<string>("")

    const [notFound, setNotFound]                           = useState<boolean>(false)


    function backToLastPage() {
        const lastPage = systemUserContext.systemUser.currentPage
        router.push(`/main/${lastPage}`)
    }

    async function getSpecificCalling() {

        const jwtToken: string|null = systemUserContext.getStorageToken()

        const calling: APIResponse = await getCallingByID(jwtToken, params.slug)

        if(calling.status == 200) {

            let formattedCreatedAt:string = "---"
            let formattedAssignedAtDate:string = "---"
            let formattedUpdatedAt:string = "---"
            let formattedClosedAtDate:string = "---"

            if(moment(calling.response.createdAt).isValid()) {
                formattedCreatedAt = DateFormater(calling.response.createdAt)
                formattedUpdatedAt = DateFormater(calling.response.updatedAt)

                if(calling.response.assignedAt) {
                    formattedAssignedAtDate = DateFormater(calling.response.assignedAt)
                }
                if(calling.response.closedAt) {
                    formattedClosedAtDate = DateFormater(calling.response.closedAt)
                }
            }

            const commentList: Array<Comment> = calling.response.comments.map((element:Comment) => {
            const formattedCommentCreatedAt = DateFormater(element.createdAt)

            return(
                {
                    user: {name: element.user.name, id: element.user.id},
                    createdAt: formattedCommentCreatedAt,
                    content: element.content
                }
            )
        })

        setCalling(
            {
                agent: calling.response.agent,
                applicant: calling.response.applicant,
                author: {name: calling.response.author.name, id: calling.response.author.id},
                category: calling.response.category,
                createdAt: formattedCreatedAt,
                description: calling.response.description,
                id: calling.response.id,
                os: calling.response.os,
                priority: calling.response.priority,
                sector: {name: calling.response.sector.name, id: calling.response.sector.id},
                status: calling.response.status,
                title: calling.response.title,
                updatedAt: formattedUpdatedAt,
                assignedAt: formattedAssignedAtDate,
                closedAt: formattedClosedAtDate,
                comments: commentList,
                active: calling.response.active
            }
        )

        setCommentList(commentList)
       } else {
            setNotFound(true)
       }

    }

    async function assignTicketToTeam() {

        let callingID: string = ""
        if(typeof calling?.id == "string") {
            callingID = calling.id
        }

        setAssignLoading(true)
        const result: APIResponse = await assignTicketByID(systemUserContext.systemUser.jwtToken, callingID)

        console.log(result.status)

        if(result.status == 200) {
            popupContext.setShowSuccess(true)
            popupContext.setSuccessMessage("Sua equipe foi atribuída ao chamado com sucesso!")
            setAssignLoading(false)
        }
        else if(result.status == 403) {
            popupContext.setShowError(true)
            popupContext.setErrorMessage("Você não tem permissão para executar essa ação")
            setAssignLoading(false)
        }
        else {
            popupContext.setShowError(true)
            popupContext.setErrorMessage(result.response.title)
            setAssignLoading(false)
        }

        setReloadingCalling((prev) => {
            return(!prev)
        })

    }

    async function addCommentToTicketHandle() {

        if(reloadNewComment) {
            return
        }

        if(newComment.trim().length == 0) {
            popupContext.setErrorMessage("Os comentários devem ter pelo menos um caractere")
            popupContext.setShowError(true)
            return
        }

        setReloadNewComment(true)
        const messageResponse: APIResponse = await addCommentToTicket(systemUserContext.systemUser.jwtToken, newComment, params.slug) 

        if(messageResponse.status == 201) {

            const jwtToken: string|null = systemUserContext.getStorageToken()
            const callingDetails: APIResponse = await getCallingByID(jwtToken, params.slug)
            setReloadingCalling((prev) => {
                return(!prev)
            })
            setReloadNewComment(false)
        } else {
            popupContext.setErrorMessage(messageResponse.response.title)
            popupContext.setShowError(true)
        }

    }

    async function closeCallingHandler() {

        setEndCallingLoading(true)
        const closeCalling: APIResponse = await closeCallingPut(systemUserContext.systemUser.jwtToken, params.slug)

        if(closeCalling.status == 200) {
            popupContext.setSuccessMessage("Chamado fechado com sucesso!")
            popupContext.setShowSuccess(true)
        }
        else if(closeCalling.status == 403) {
            popupContext.setShowError(true)
            popupContext.setErrorMessage("Você não tem permissão para executar essa ação")
            setAssignLoading(false)
        }
        else{
            popupContext.setErrorMessage(closeCalling.response.title)
            popupContext.setShowError(true)
        }

        setReloadingCalling((prev) => {
            return(!prev)
        })
        setEndCallingLoading(false)

    }

    async function deleteCallingHandler() {

        setDeleteCallingLoading(true)

        const result = await deleteCalling(systemUserContext.systemUser.jwtToken , params.slug)

        if(result.status == 200) {
            popupContext.setShowSuccess(true)
            popupContext.setSuccessMessage("Chamado deletado com sucesso!")
            setDeleteCallingLoading(false)
        }
        else {
            popupContext.setShowError(true)
            popupContext.setErrorMessage(result.response.title)
            setDeleteCallingLoading(false)
        }

        setReloadingCalling((prev) => {
            return(!prev)
        })

    }

    useEffect(() => {
        setAddComment(false)
        setTextLength(0)
        setNewComment("")
        getSpecificCalling()
    }, [reloadCalling])


    useEffect(() => {
        getSpecificCalling()
    }, [])


    return(
        <div className={`${style.container}`}>

            <PopupMessage/>

            {notFound
                ?
                    <h1 className='text-black bg-slate-400 w-[50%] absolute left-0 right-0 m-auto mt-52 text-center text-xl z-30'>Nenhum chamado para esse ID</h1>
                :
                    null
                }

            {calling == null
                ?
                    <LoadingSpecificCalling/>
                :
                    <div className={`${style.calling_box} relative ${calling.priority.toUpperCase() == "ALTA" ? style.high_priority : calling.priority.toUpperCase() == "MÉDIA" ? style.medium_priority : style.low_priority} relative`}>

                        <Image
                            width={20}
                            alt="icone_fechar"
                            src={closeIcon}
                            className={'absolute right-3 top-3 hover:cursor-pointer'}
                            onClick={backToLastPage}
                        />


                        <h1 className={`font-bahnscrift_bold text-xl ${style.calling_title}`}>{calling.title}</h1>

                        <div className={`flex md:justify-between mt-5 sm:justify-center ${style.upper_info}`}>

                            <p><span className='font-bahnscrift_bold'>Categoria:</span> {calling.category.name}</p>

                            <p><span className='font-bahnscrift_bold'>Atribuído à:</span> {calling.agent?.sector.name ? calling.agent.sector.name : '---'}</p>

                        </div>

                        <hr 
                            className='mt-4'
                        />

                        <div className={`${style.more_details} mt-5`}>

                            <div className='flex gap-10 w-[90%] justify-center flex-wrap'>
                                <p><span className='font-bahnscrift_bold pr-1'>Requerente: </span>{calling.applicant}</p>
                                <p><span className='font-bahnscrift_bold pr-1'>Prioridade: </span>{calling.priority}</p>
                                <p><span className='font-bahnscrift_bold pr-1'>Status: </span>{calling.status}</p>
                                <p><span className='font-bahnscrift_bold pr-1'>Autor: </span>{calling.author.name}</p>
                                <p><span className='font-bahnscrift_bold pr-1'>Setor: </span>{calling.sector.name}</p>
                            </div>

                            <div className='flex gap-10 w-[90%] justify-center flex-wrap mt-4'>
                                <p><span className='font-bahnscrift_bold pr-1'>Data de Abertura: </span>{calling.createdAt}</p>
                                <p><span className='font-bahnscrift_bold pr-1'>Data de Atualização: </span>{calling.updatedAt ? calling.updatedAt : '---'}</p>
                                <p><span className='font-bahnscrift_bold pr-1'>Data de Atribuição: </span>{calling.assignedAt ? calling.assignedAt : '---'}</p>
                                <p><span className='font-bahnscrift_bold pr-1'>Data de Fechamento: </span>{calling.closedAt ? calling.closedAt : '---'}</p>
                            </div>

                        </div>

                        <h1 className='font-bahnscrift_bold mt-5'>Descrição: </h1>
                        <textarea
                            readOnly={true}
                            value={calling.description}
                            maxLength={500}
                            className='focus:outline-none resize-none px-4 py-2 text-left w-[100%] mx-auto mt-2 border-solid border-[.1rem] border-[#B1B1B1] rounded-md h-60'
                        />

                        {commentList?.map((element) => (
                            <div
                                key={element.content}  
                                className='mx-auto my-14 relative'>
                                <p
                                    className='absolute right-0 -mt-4 opacity-55' 
                                    id={element.content}>
                                        {element.createdAt}
                                </p>                           
                                <textarea 
                                    readOnly={true}
                                    value={element.content}
                                    name="comment" 
                                    id={element.content} 
                                    className='focus:outline-none resize-none px-4 py-2 text-left w-[100%] mx-auto mt-2 border-solid border-[.1rem] border-[#B1B1B1] rounded-md'
                                />                         
                                <p
                                    className='absolute right-0 -mt-2 opacity-55' 
                                    id={element.content}>
                                        {element.user.name}
                                </p>
                            </div>
                        ))
                        }

                        {addComment 
                            ?
                                <div className='py-5 relative'>
                                    
                                    <h1 className='font-bahnscrift_bold'>Escreva seu comentário abaixo</h1>

                                    <textarea
                                        onChange={(ev) => {
                                            setNewComment(ev.target.value)
                                            setTextLength(ev.target.value.length)
                                        }}
                                        readOnly={false}
                                        maxLength={200}
                                        className='focus:outline-none resize-none px-4 py-2 text-left w-[100%] mx-auto mt-2 border-solid border-[.1rem] border-[#B1B1B1] rounded-md h-36'
                                    />

                                    <p className='absolute right-0'>{textLength}/200</p>
                                    
                                    {reloadNewComment
                                        ? 
                                            <span className='border-solid ml-2 border-t-2 border-r-2 animate-spin rounded-3xl border-[#0860A8] w-7 h-7 block'></span>
                                        :
                                            <button 
                                                onClick={() => addCommentToTicketHandle()}
                                                className={`border-solid  border-[.1rem] px-2 py-1 rounded-md text-[#0860A8] border-[#0860A8] hover:bg-[#0860A8] hover:text-white`}>
                                                Criar comentário
                                            </button>
                                    }

                                </div>
                            :
                                null
                            }

                            {calling.status !== "FECHADO" && calling.active
                                ?
                                    <div>
                                        <button
                                            onClick={() => setAddComment((prev) => {
                                                return(!prev)
                                            })} 
                                            className={`border-solid border-[.1rem] px-2 py-1 rounded-md 
                                            ${!addComment ? 'text-[#8BCB1A] border-[#8BCB1A] mt-2 hover:bg-[#8BCB1A] hover:text-white' : 'text-[#DD1D8B] border-[#DD1D8B] mt-2 hover:bg-[#DD1D8B] hover:text-white'}
                                            ${systemUserContext.isUser() && calling.author.id !== systemUserContext.getUserID() ? 'hidden' : null}`}>
                                            {!addComment ? 'Adicionar Comentário' : 'Cancelar comentário'}
                                        </button>
                                        
                                        {systemUserContext.isUser() === false || calling.author.id === systemUserContext.getUserID()
                                            ?
                                                <div className={`flex justify-end gap-8 ${style.last_buttons}`}>
                            
                                                {assignLoading
                                                    ?
                                                        <span className='border-solid mr-14 border-t-2 border-r-2 animate-spin rounded-3xl border-[#0860A8] w-7 h-7 block'></span>
                                                    :
                                                        <button
                                                            onClick={() => assignTicketToTeam()} 
                                                            className={`border-solid border-[.1rem] px-2 py-1 rounded-md text-[#0860A8] border-[#0860A8] hover:bg-[#0860A8] hover:text-white`}>
                                                            Atribuir à equipe
                                                        </button>
                                                }

                                                {endCallingLoading
                                                    ?
                                                        <span className='border-solid mr-14 border-t-2 border-r-2 animate-spin rounded-3xl border-[#DD1D8B] w-7 h-7 block'></span>
                                                    :
                                                        <button
                                                            onClick={() => closeCallingHandler()} 
                                                            className={`border-solid border-[.1rem] px-2 py-1 rounded-md text-[#DD1D8B] border-[#DD1D8B] hover:bg-[#DD1D8B] hover:text-white`}>
                                                            Finalizar Chamado
                                                        </button>
                                                }

                                                {systemUserContext.isAdmin() == true || calling.author.id === systemUserContext.getUserID()
                                                    ?
                                                        <button
                                                            onClick={() => deleteCallingHandler()} 
                                                            className={`${!deleteCallingLoading ? 'border-solid border-[.1rem] px-2 py-1 rounded-md text-[#FEA200] border-[#FEA200] hover:bg-[#FEA200] hover:text-white' : 'border-solid mr-14 border-t-2 border-r-2 animate-spin rounded-3xl border-[#FEA200] w-7 h-7 block'}`}>
                                                            {deleteCallingLoading ? '' : 'Deletar Chamado'}
                                                        </button>
                                                    :
                                                        null
                                                }

                                                </div>
                                            :
                                                null
                                        }

                                    </div>
                                :
                                    null
                            }

                </div>

            }

        
        </div>
    )
}