'use client'

import arrow_icon from '../../../public/arrow_icon.svg'

import style from '../../styles/createCalling.module.css'

import { useState, useEffect, useContext } from 'react'

import userContext from '@/app/context/userContext';
import PopupContext from '@/app/context/popupMessageContext';

import { useRouter } from 'next/navigation'

import Image from 'next/image'
import APIResponse from '@/app/interface/ApiResponse';
import Calling from '@/app/interface/Calling';
import { createCalling } from '@/app/functions/calling';
import { getAllSectors } from '@/app/functions/sector';
import { getAllCategories } from '@/app/functions/category';
import { json } from 'stream/consumers';
import Item from '@/app/interface/Item';


import PopupMessage from '@/app/component/popupMessage';
import LoadingComponent from '@/app/component/loadingComponent';
import SectorInput from '@/app/component/sectorInput';
import APIError from '@/app/enum/APIError';

export default function CreateCalling() {
    const router = useRouter()

    const userSystemContext = useContext(userContext)
    const popupContext = useContext(PopupContext)

    const allPriorities: Array<string>  = ["Baixa", "Média", "Alta", "Agendamento"]

    const [callingTitle, setCallingTitle]           = useState("")
    const [showSector, setShowSector]               = useState<boolean>(false)
    const [showCategory, setShowCategory]           = useState(false)
    const [showPriority, setShowPriority]           = useState(false)

    const [allSectors, setAllSectors]               = useState<Item[]>([{id: "0", name: "----"}])
    const [allCategories, setAllCategories]         = useState<Item[]>([{id: "0", name: "----"}])

    const [selectedSector, setSelectedSector]       = useState<Item>({id:"0", name:"Setor"})
    const [selectedCategory, setSelectedCategory]   = useState<Item>({id:"0", name:"Categoria"})
    const [selectedPriority, setSelectedPriority]   = useState<string>("Prioridade")

    const [callingText, setCallingText]             = useState<string>("")

    const [errorMessage, setErrorMessage]           = useState<string>("")
    const [successMessage, setSuccessMessage]        = useState<string>("")

    const [showError, setShowError]                 = useState<boolean>(false)
    const [showSuccess, setShowSuccess]             = useState<boolean>(false)

    const [loadingComponent, setLoadingComponent]   = useState<boolean>(false)

    async function getAllSectorsHandler() {
        if(JSON.stringify(allSectors) == '[{"id":"0","name":"----"}]') {

            const sectorResponse:APIResponse = await getAllSectors(userSystemContext.systemUser.jwtToken, true)

            if(sectorResponse.status == 200) {

                const sectorList:Array<Item> = sectorResponse.response.map((element: Item) => {
                    return(
                        {
                            id: element.id,
                            name: element.name
                        }
                    )
                })
                setAllSectors(sectorList)
            } else if(sectorResponse.status == 403) {
                popupContext.setErrorMessage(APIError.Forbidden)
                popupContext.setShowError(true)
            } else {
                popupContext.setErrorMessage(sectorResponse.response)
                popupContext.setShowError(true)
            }
        }
    }

    async function getAllCategoryHandler() {

        if(JSON.stringify(allCategories) == '[{"id":"0","name":"----"}]') {
            const allCategories:APIResponse = await getAllCategories(userSystemContext.systemUser.jwtToken)
            
            if(allCategories.status == 200) {
                
                const categoryList:Array<Item> = allCategories.response.map((element: Item) => {
                    return(
                        {
                            id: element.id,
                            name: element.name
                        }
                    )
                })
                setAllCategories(categoryList)
            }
            else {
                popupContext.setShowError(true)
                popupContext.setErrorMessage("Nenhuma categoria criada")
            }
        }
    }

    useEffect(() => {
        userSystemContext.setCurrentPage("criar_chamado")
    }, [])

    async function createCallingHandler(formData:any) {

        const calling: any = {
            title: callingTitle,
            applicant: formData.target[0].value,
            sector: formData.target[1].id,
            category: formData.target[2].id,
            priority: formData.target[3].value.toUpperCase(),
            description: formData.target[4].value,
        }

        if(callingTitle.length <= 5) {
            popupContext.setErrorMessage("O título deve ter mais de 5 caracteres")
            popupContext.setShowError(true)
            return
        }

        if(calling.sector == "0") {
            popupContext.setErrorMessage("Selecione um setor válido")
            popupContext.setShowError(true)
            return
        }

        if(calling.category == "0") {
            popupContext.setErrorMessage("Selecione uma categoria válida")
            popupContext.setShowError(true)
            return
        }


        if(!loadingComponent)

            setLoadingComponent(true)

            const callingAPIResult = await createCalling(userSystemContext.systemUser.jwtToken, calling)
    
            if(callingAPIResult.status == 400) {

                popupContext.setErrorMessage("Verifique o preenchimento dos campos")
                popupContext.setShowError(true)
            setLoadingComponent(false)

            } else if(callingAPIResult.status == 500) {
                popupContext.setErrorMessage("Você não tem permissão para realizar essa operação")
                popupContext.setShowError(true)
            setLoadingComponent(false)

            }
             else {
                popupContext.setSuccessMessage(`Chamado de número ${callingAPIResult.response.os} criado com sucesso!`)
                popupContext.setShowSuccess(true)
                
                setTimeout(() => {
                    backToHomePageHandler(true)
                }, 1000)  
            }
    }

    
    const backToHomePageHandler = (submit:boolean) => {


        if(submit) {
            return router.push('/main/home')
        }

        router.push('/main/home')
    }

    return(
        <div className={`${style.container}`}>

            {loadingComponent 
                ? 
                <div className='absolute -mt-12 z-40'>
                    <LoadingComponent/>
                </div>
                :
                null
            }

            <PopupMessage/>
            

            <div className={`${style.create_calling_box} ${loadingComponent ? style.loading_component : null}`}>

                <input 
                    type="text" 
                    name="calling_title" 
                    id="calling_title"
                    placeholder='Título do chamado'
                    className={`${style.calling_title} font-bahnscrift_bold`}
                    onChange={(ev) => setCallingTitle(ev.target.value)}
                    />

                    <div className={`${style.calling_details} font-bahnscrift_bold`}>

                        <form
                            onSubmit={(data) => {data.preventDefault(),
                                createCallingHandler(data)}} 
                            className={``}>

                            <div className={`${style.input_couple} md:w-[100%] md:items-center`}>

                                <div className={`flex gap-4 md:w-[50%] items-center ${style.label_and_input}`}>
                                    <label htmlFor="requerente">
                                        <p className='w-24'>Requerente: <span className='text-[#DD1D8B]'>*</span></p>
                                    </label>

                                    <input 
                                        minLength={3}
                                        maxLength={50}
                                        type="text" 
                                        name="requerente" 
                                        id="requerente" 
                                        className='w-[80%]'
                                        placeholder='Nome do requerente'
                                        />

                                </div>

                                <SectorInput
                                    allSectors={allSectors}
                                    getAllSectorsHandler={getAllSectorsHandler}
                                    selectedSector={selectedSector}
                                    setSelectedSector={setSelectedSector}
                                    setShowSector={setShowSector}
                                    showSector={showSector}
                                    style={style}
                                /> 

                            </div>

                            <div className={`${style.input_couple} ${style.input_couple_b} md:items-center mt-5`}>



                                    <div className={`flex gap-4 md:w-[40%] items-center relative z-20`}>
                                        <label htmlFor="categoria" className='10rem'>
                                            <p className='w-24'>Categoria: <span className='text-[#DD1D8B]'>*</span></p>
                                        </label>

                                        <Image
                                            onClick={() => {getAllCategoryHandler(), 
                                                setShowCategory((prev) => !prev)}}
                                            src={arrow_icon}
                                            className={`${showCategory ? null : 'rotate-180'} bg-white py-1 absolute right-2 hover:cursor-pointer z-10`}
                                            alt={"ícone_seta"}
                                            
                                        />

                                        <div className='w-[100%] relative'>

                                            <input 
                                                readOnly={true}
                                                onClick={() => {getAllCategoryHandler(),
                                                    setShowCategory((prev) => !prev)}}
                                                type="text" 
                                                name="categoria" 
                                                id={selectedCategory.id} 
                                                value={selectedCategory.name}
                                                contentEditable={false}
                                                className={`w-[100%] select-none px-5 z-10 ${selectedCategory.name == 'Categoria' ? 'text-[grey]' : null} hover:cursor-pointer`}
                                            />

                                            <div className={`${style.status_options} ${!showCategory ? style.not_show_options : style.show_options} z-10 pb-2 -mt-1 rounded-md grid gap-3 absolute w-[100%] h-[auto] bg-white pt-2 text-[#626262] select-none right-0 border-2 border-opacity-60 border-[#959595]`}>


                                                {allCategories.map((element) => (
                                                    <p 
                                                        key={element.id}
                                                        onClick={(p) => {setSelectedCategory(element),
                                                            setShowCategory(false)
                                                        }}
                                                        id={element.id} 
                                                        className={`text-center ${!showCategory ? 'opacity-0' : null} hover:cursor-pointer`}>

                                                        {element.name}
                                                    </p>
                                                ))}

                                            </div>

                                        </div>

                                    </div>

                                

                                <div className={`flex gap-4 md:w-[40%] items-center relative z-5`}>
                                        <label htmlFor="prioridade" className='10rem'>
                                            <p className='w-24'>Prioridade: <span className='text-[#DD1D8B]'>*</span></p>
                                        </label>
                                            
                                        <Image
                                            onClick={() => setShowPriority((prev) => !prev)}
                                            src={arrow_icon}
                                            className={`${showPriority ? null : 'rotate-180'} bg-white py-1 absolute right-2 hover:cursor-pointer z-10`}
                                            alt={"ícone_seta"}
                                            
                                        />
    
                                        <div className='w-[100%] relative'>
                                            
                                            <input 
                                                readOnly={true}
                                                onClick={() => setShowPriority((prev) => !prev)}
                                                type="text" 
                                                name="prioridade" 
                                                id={selectedPriority}
                                                value={selectedPriority}
                                                contentEditable={false}
                                                className={`w-[100%] select-none px-5 z-10 ${selectedPriority == 'Prioridade' ? 'text-[grey]' : null} hover:cursor-pointer`}
                                            />
    
                                            <div className={`${style.status_options} ${!showPriority ? style.not_show_options : style.show_options} z-10 pb-2  -mt-1 rounded-md grid gap-3 absolute w-[100%] h-[auto] bg-white pt-2 text-[#626262] select-none right-0 border-2 border-opacity-60 border-[#959595]`}>
                                            
                                            
                                                {allPriorities.map((element) => (
                                                    <p 
                                                        key={element}
                                                        onClick={(p) => {setSelectedPriority(element),
                                                            setShowPriority(false)
                                                        }}
                                                        id={element.toLowerCase()} 
                                                        className={`text-center ${!showPriority ? 'opacity-0' : null} hover:cursor-pointer`}>
                                                        
                                                        {element}
                                                    </p>
                                                ))}
    
                                            </div>
                                            
                                        </div>
                                            
                                    </div>

                            </div>  

                                <div className='relative'>
                                    <textarea
                                        maxLength={500}
                                        onChange={(ev) => setCallingText(ev.target.value)}
                                        placeholder='Disserte sobre seu problema aqui' 
                                        className=' resize-none px-4 py-4 w-[100%] mx-auto mt-10 border-solid border-2 border-[#0860A8] rounded-md h-60'
                                    />

                                    <p className='absolute right-0'>{callingText.length}/500</p>

                                </div>

                                <div className={`flex justify-end gap-8 mt-12`}>

                                    <p 
                                        onClick={() => backToHomePageHandler(false)}
                                        className='border-solid border-2 border-[#DD1D8B] px-5 py-3 rounded-md text-[#DD1D8B] hover:bg-[#DD1D8B] hover:text-white hover:cursor-pointer'>Cancelar</p>
                                    <button type='submit' className='border-solid border-2 border-[#8BCB1A] px-5 py-3 rounded-md text-[#8BCB1A] hover:bg-[#8BCB1A] hover:text-white'>Enviar Chamado</button>

                                </div>

                        </form>

                    </div>

            </div>

        </div>
    )
}