'use client'

import { useEffect, useContext } from "react"
import Role from "@/app/enum/Role"

import UserContext from "@/app/context/userContext"
import PopupContext from "@/app/context/popupMessageContext"

import { useRouter } from "next/navigation"
import PopupMessage from "@/app/component/popupMessage"
import PageHeader from "@/app/component/pageHeader"

export default function AdminLayout({children}: any) {

    const router = useRouter()

    const userContext   = useContext(UserContext)
    const popupContext  = useContext(PopupContext)

    function isAdminHandler() {
        if(!userContext.isAdmin()) {
            router.push('/main/home')
        }
    }

    useEffect(() => {
        isAdminHandler()
    }, [])

    return(
        <>
            {children}
        </>
    )
}