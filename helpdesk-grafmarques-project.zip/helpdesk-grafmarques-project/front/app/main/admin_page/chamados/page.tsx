'use client'

import style from '../../../styles/homePage.module.css'

import { useState, useEffect, useContext, useRef, Suspense } from 'react'

import { useRouter } from 'next/navigation'

import GridComponent from '@/app/component/gridComponent';

import sendGridData from '@/app/functions/sendGridData';
import FilteringComponent from '@/app/component/filteringComponent';

import userContext from '@/app/context/userContext';
import { getAdminPageCallings, getDefaultHomeCallings } from '@/app/functions/calling';
import APIResponse from '@/app/interface/ApiResponse';
import Calling from '@/app/interface/Calling';
import CallingContext from '@/app/context/callingContext';
import Filter from '@/app/interface/Filter';
import LoadingComponent from '@/app/component/loadingComponent';
import PopupMessage from '@/app/component/popupMessage';
import PopupContext from '@/app/context/popupMessageContext';
import TableLoading from '@/app/component/tableLoading';

import crypto from 'crypto'
import DateFormater from '@/app/functions/dateFormater';
import AdminGridComponent from '@/app/component/adminGridComponent';


export default function AdminPageCallings() {

    const [count, setCount] = useState(0)
    const countRef = useRef(count)

    const router                        = useRouter()
    const userSystemContext             = useContext(userContext)
    const callingContext                = useContext(CallingContext)
    const popupContext                  = useContext(PopupContext)

    const [gridData, setGridData]       = useState<Array<string[]>|null>([])
    const [changeData, setChangeData]   = useState<boolean>(false)
    const [filter, setFilter]           = useState<Filter|null>()
    const [loadingGrid, setLoadingGrid] = useState<boolean>(false)
    const [hasData, setHasData]         = useState<boolean>(false)


    async function getAdminCallingsHandler(filter?: Filter) {

        const jwtToken:string|null = userSystemContext.getStorageToken()
        setLoadingGrid(true)

        const apiResponse: APIResponse = await getAdminPageCallings(jwtToken, filter)

        if(apiResponse.status != 200) {
            setLoadingGrid(false)

            if(apiResponse.response.title) {
                popupContext.setErrorMessage(apiResponse.response.title)
                popupContext.setShowError(true)
            }
        }

        if(apiResponse.status == 200) {

            callingContext.setSendCalling(false)

            if(apiResponse.response.length > 0) {

                setHasData(true)
                
                const callingItems: Array<string[]> = apiResponse.response.map((element: Calling) => {

                let isActive: string

                element.active ? isActive = "Ativo" : isActive = "Inativo"

                const formattedCreatedAt:string = DateFormater(element.createdAt)
                const formattedUpdatedAt:string = DateFormater(element.updatedAt)

                return (
                    [
                        element.id,
                        element.os,
                        element.title,
                        element.status,
                        element.priority,
                        element.category.name,
                        element.sector.name,
                        formattedCreatedAt,
                        formattedUpdatedAt,
                        element.applicant,
                        element.author.name,
                        isActive
                    ]
                )
                
            })
            setLoadingGrid(false)
            callingContext.setSendCalling(true)
            localStorage.setItem("home_array", JSON.stringify(callingItems))
            } else {
                setHasData(false)
                setLoadingGrid(false)
                callingContext.setSendCalling(true)
                localStorage.setItem("home_array", "[]")
            }
        }
        
    }

    useEffect(() => {
        if(filter != null) {
            getAdminCallingsHandler(filter)
        }
    }, [filter])

    useEffect(() => {
        getAdminCallingsHandler()
    }, [])

    return(
        <div className={style.container}>

            <PopupMessage/>
                
            <h1 className={`text-white font-bahnscrift_bold text-xl text-center mt-1 mb-3`}>TODOS OS CHAMADOS</h1>
            <hr className='text-grey opacity-35 w-[10%] mx-auto pb-5'/>
            
            <h1
            className={`font-bahnscrift_bold text-white text-center`}>
                FILTRAR POR
            </h1>

            <FilteringComponent
                setFilter={setFilter}
            />

            {loadingGrid 
                ?
                    <TableLoading/>
                :
                    !hasData 
                        ?   
                            <h1 className={`text-center text-white mt-[5rem] text-xl animate-bounce`}>Sem dados para esse filtro 🤨</h1>
                        :
                        <AdminGridComponent
                            changeData={changeData}
                            gridData={gridData}
                        />
                }

        </div>
    )
}