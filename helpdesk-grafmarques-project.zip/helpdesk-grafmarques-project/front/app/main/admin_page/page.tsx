'use client'

import style from '../../styles/adminPage.module.css'
import profile_icon from '../../../public/profile_icon.svg'
import categories_icon from '../../../public/categories_icon.svg'
import sector_icon from '../../../public/sector_icon.svg'
import calling_icon from '../../../public/calling_icon.svg'

import { useContext, useEffect } from 'react'

import UserContext from '@/app/context/userContext'

import { CiPhone } from "react-icons/ci";

import { useRouter } from 'next/navigation'

import Image from 'next/image'
import PopupMessage from '@/app/component/popupMessage'

export default function AdminPage() {

    const systemUserContext = useContext(UserContext)

    const router = useRouter()

    const changeRouteHandler = (route:string) => {
        if(route == "usuario") {
            router.push('admin_page/usuarios')
        }else if(route == "categoria") {
            router.push('admin_page/categorias')
        } else if(route == "setores") {
            router.push('admin_page/setores')
        } else if(route == "chamados") {
            router.push('admin_page/chamados')
        }
    }

    useEffect(() => {
        systemUserContext.setCurrentPage("admin")
    }, [])

    return(
        <div className={`${style.container}`}>

            <h1 className='font-bahnscrift_bold text-2xl ml-12 text-white mb-8'>Administrador</h1>

            <div className={`${style.sections_list}`}>

                <div
                    onClick={() => {
                        changeRouteHandler("usuario")
                    }} 
                    className={`${style.section}`}>
                    <div>
                        <h1>Usuários</h1>
                        <p>Administrar usuários do sistema</p>
                    </div>

                    <Image
                        src={profile_icon}
                        alt='icone_perfil'
                        className={`${style.admin_icon}`}
                        width={50}
                    />

                </div>

                <hr className='w-[95%] mx-auto opacity-50'/>

                <div className={`${style.section}`}
                 onClick={() => {
                    changeRouteHandler("categoria")
                }}>
                    <div>
                        <h1>Categorias</h1>
                        <p>Administrar categorias de serviço do sistema</p>
                    </div>

                    <Image
                        src={categories_icon}
                        alt='icone_perfil'
                        className={`${style.admin_icon}`}
                        width={50}
                    />

                </div>

                <hr className='w-[95%] mx-auto opacity-50'/>

                <div 
                    onClick={() => changeRouteHandler("setores")}
                    className={`${style.section}`}>
                    <div>
                        <h1>Setores</h1>
                        <p>Administrar setores do sistema</p>
                    </div>

                    <div className='-mt-1 absolute right-0 mr-12'>
                        <Image
                            src={sector_icon}
                            alt='icone_perfil'
                            className={``}
                            width={70}
                        />
                    </div>

                </div>

                <hr className='w-[95%] mx-auto opacity-50'/>

                <div
                    onClick={() => changeRouteHandler("chamados")}
                    className={`${style.section}`}>
                    <div>
                        <h1>Chamados</h1>
                        <p>Administrar chamados do sistema</p>
                    </div>


                    <CiPhone
                        className={`text-[4rem] absolute right-0 mr-12`}
                    />

                </div>

            </div>

        </div>
    )
}