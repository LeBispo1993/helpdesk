'use client'

import GridComponent from "@/app/component/gridComponent"
import style from '../../../styles/adminSubPage.module.css'

import { useState, useEffect, useContext } from 'react'

import UserContext from "@/app/context/userContext"
import PopupContext from "@/app/context/popupMessageContext"
import CallingContext from "@/app/context/callingContext"

import TableLoading from "@/app/component/tableLoading"
import APIResponse from "@/app/interface/ApiResponse"
import { activateUser, deactivateUser, getAllUsers } from "@/app/functions/user"
import User from "@/app/interface/User"
import UserGridComponent from "@/app/component/userGridComponent"
import ItemRegister from "@/app/component/itemRegister"
import Where from "@/app/enum/Where"
import PopupMessage from "@/app/component/popupMessage"
import UserProfile from "@/app/component/userProfile"
import { getAllSectors } from "@/app/functions/sector"
import Item from "@/app/interface/Item"
import Method from "@/app/enum/Method"
import DateFormater from "@/app/functions/dateFormater"

export default function AdminUserPage() {

    const userSystemContext = useContext(UserContext)
    const popupContext = useContext(PopupContext)
    const callingContext = useContext(CallingContext)

    const [gridData, setGridData]                       = useState<Array<string[]>|null>([])
    const [changeData, setChangeData]                   = useState<boolean>(false)
    const [loadingGrid, setLoadingGrid]                 = useState<boolean>(false)
    const [hasData, setHasData]                         = useState<boolean>(false)

    const [operationDone, setOperationDone]             = useState<boolean>(false)

    const [registerScreen, setRegisterScreen]           = useState<boolean>(false)
    const [profileScreen, setProfileScreen]             = useState<boolean>(false)
    
    const [idForProfileScreen, setIDForProfileScreen]   = useState<string>("")

    const [method, setMethod]                           = useState<Method>()
    const [doingOperation, setDoingOperation]           = useState<boolean>(false)

    async function getAllUsersHandler() {

        const jwtToken:string|null = userSystemContext.getStorageToken()
        setLoadingGrid(true)

        const apiResponse: APIResponse = await getAllUsers(jwtToken)

        if(apiResponse.status != 200) {
            setLoadingGrid(false)
            popupContext.setErrorMessage(apiResponse.response.title)
            popupContext.setShowError(true)
        }

        if(apiResponse.status == 200) {

            callingContext.setSendCalling(false)

            if(apiResponse.response.length > 0) {

                setHasData(true)
                
                const usersList: Array<string[]> = apiResponse.response.map((element: User) => {
                
                let formattedCreatedAt: string = ""
                let activeUser: string = ""
                
                typeof element.createdAt == "string" ? formattedCreatedAt = DateFormater(element.createdAt) : null

                element.active ? activeUser = "Ativo" : activeUser = "Desativado"

                return (
                    [
                        element.id,
                        element.name,
                        element.email,
                        element.sector.name,
                        activeUser,
                        formattedCreatedAt
                    ]
                )
                
            })

            setLoadingGrid(false)
            callingContext.setSendCalling(true)
            localStorage.setItem("allUsers", JSON.stringify(usersList))
            } else {
                setHasData(false)
                setLoadingGrid(false)
                callingContext.setSendCalling(true)
                localStorage.setItem("allUsers", "[]")
            }
        }
        
    }

    async function toggleUserHandler() {

        if(doingOperation) {
            
        let result: APIResponse
        let successMessage: string = ""

        if(method == Method.Deactivation) {
            result = await deactivateUser(userSystemContext.systemUser.jwtToken, idForProfileScreen)
            successMessage = "Usuário desativado!"
        } else {
            result = await activateUser(userSystemContext.systemUser.jwtToken, idForProfileScreen)
            successMessage = "Usuário ativado!"
        }

        if(result.status == 200) {
            popupContext.setSuccessMessage(successMessage)
            popupContext.setShowSuccess(true)

            setOperationDone((prev) => {
                return !prev
            })

        } else {
            popupContext.setErrorMessage(result.response)
            popupContext.setShowError(true)
        }

        setDoingOperation(false)
        }
    }

    useEffect(() => {
        toggleUserHandler()
    }, [doingOperation])

    useEffect(() => {
        getAllUsersHandler()
    }, [operationDone])

    return(
        <div className={`${style.container}`}>

            <PopupMessage/>

                {profileScreen
                    ?
                    <div className="-mt-28">
                        <UserProfile
                            userID={idForProfileScreen}
                            profileScreen={setProfileScreen}
                            setOperationDone={setOperationDone}
                        />
                    </div>
                    :
                    null
                }

            {registerScreen 
                ?
                    <ItemRegister
                    setRegisterScreen={setRegisterScreen}
                    setOperationDone={setOperationDone}
                    where={Where.user}
                    itemA={{field: "Nome", placeholder: "Nome do usuário"}}
                    itemB={{field: "Setor", placeholder: "Setor do usuário"}}
                    itemC={{field: "Email", placeholder: "Email do usuário"}}
                    itemD={{field: "Cargo", placeholder: "Cargo do usuário"}}
                    itemE={{field: "Senha", placeholder: "Senha do usuário"}}
                    />
                :
                    null
            }

            {!profileScreen
                ?
                    <div>
                        <div>
                            <h1 className={`text-white font-bahnscrift_bold text-xl text-center my-5`}>USUÁRIOS DO SISTEMA</h1>
                        </div>

                        <hr className='text-grey opacity-35 -mt-2 w-[10%] mx-auto pb-5'/>

                        <button 
                            onClick={() => setRegisterScreen(true)}
                            className={`border-solid ml-[4.5vw] w-[10rem] border-[.1rem] px-2 py-1 rounded-md text-[#8BCB1A] border-[#8BCB1A] hover:bg-[#8BCB1A] hover:text-white`}>
                            Criar usuário
                        </button>


                        {loadingGrid 
                            ?
                                <TableLoading/>
                            :
                                !hasData 
                                    ?   
                                        <h1 className={`text-center text-white mt-[5rem] text-xl animate-bounce`}>Não tem ninguém por aqui 🧐</h1>
                                    :
                                        <UserGridComponent
                                            changeData={changeData}
                                            gridData={gridData}
                                            setProfileScreen={setProfileScreen}
                                            setIDForProfileScreen={setIDForProfileScreen}
                                            setMethod={setMethod}
                                            setDoingOperation={setDoingOperation}
                                        />
                        }

                    </div>

                :
                    null
                    
            }

    </div>
    )
}