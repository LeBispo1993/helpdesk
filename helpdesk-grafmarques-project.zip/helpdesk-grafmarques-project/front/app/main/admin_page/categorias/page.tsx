'use client'

import GridComponent from "@/app/component/gridComponent"
import style from '../../../styles/adminSubPage.module.css'

import { useState, useEffect, useContext } from 'react'

import UserContext from "@/app/context/userContext"
import PopupContext from "@/app/context/popupMessageContext"
import CallingContext from "@/app/context/callingContext"

import TableLoading from "@/app/component/tableLoading"
import APIResponse from "@/app/interface/ApiResponse"
import { getAllUsers } from "@/app/functions/user"
import User from "@/app/interface/User"
import UserGridComponent from "@/app/component/userGridComponent"
import ItemRegister from "@/app/component/itemRegister"
import Where from "@/app/enum/Where"
import PopupMessage from "@/app/component/popupMessage"
import { activateCategoryByID, deleteCategoryByID, getAllCategories, getAllCategoriesForAdminPage } from "@/app/functions/category"
import Category from "@/app/interface/Category"
import Item from "@/app/interface/Item"
import CategoryGridComponent from "@/app/component/CategoryGridComponent"
import DateFormater from "@/app/functions/dateFormater"
import Method from "@/app/enum/Method"

export default function AdminCategoriesPage() {

    const userSystemContext = useContext(UserContext)
    const popupContext = useContext(PopupContext)
    const callingContext = useContext(CallingContext)

    const [gridData, setGridData]               = useState<Array<string[]>|null>([])
    const [changeData, setChangeData]           = useState<boolean>(false)
    const [loadingGrid, setLoadingGrid]         = useState<boolean>(false)
    const [hasData, setHasData]                 = useState<boolean>(false)

    const [idFromGrid, setIDFromGrid]           = useState<string|null>()
    const [method, setMethod]                   = useState<Method|null>()

    const [operationDone, setOperationDone]     = useState<boolean>(false)

    const [registerScreen, setRegisterScreen]   = useState<boolean>(false)

    const [doingOperation, setDoingOperation]   = useState<boolean>(false)


    async function getAllCategoriesHandler() {

        const jwtToken:string|null = userSystemContext.getStorageToken()
        setLoadingGrid(true)

        const apiResponse: APIResponse = await getAllCategoriesForAdminPage(jwtToken)

        if(apiResponse.status != 200) {
            setLoadingGrid(false)
            popupContext.setErrorMessage(apiResponse.response.title)
            popupContext.setShowError(true)
        }

        if(apiResponse.status == 200) {

            callingContext.setSendCalling(false)

            if(apiResponse.response.length > 0) {

                setHasData(true)
                
                const categoryList: Array<string[]> = apiResponse.response.map((element: Item) => {
                
                let formattedCreatedAt: string = ""
                let active:string = ""

                element.active ? active = "Ativo" : active = "Desativada"

                if(element.createdAt) {
                    formattedCreatedAt = DateFormater(element.createdAt)
                }

                return (
                    [
                        element.id,
                        element.name,
                        active,
                        formattedCreatedAt,
                    ]
                )
                
            })

            setLoadingGrid(false)
            callingContext.setSendCalling(true)
            localStorage.setItem("allCategories", JSON.stringify(categoryList))
            } else {
                setHasData(false)
                setLoadingGrid(false)
                callingContext.setSendCalling(true)
                localStorage.setItem("allCategories", "[]")
            }
        }
        
    }

        async function toggleCategoryHandler() {

            if(doingOperation) {
                let result: APIResponse 
                let successMessage: string = ""
    
                if(idFromGrid) {
    
                    if(method == Method.Deactivation) {
                        result = await deleteCategoryByID(userSystemContext.systemUser.jwtToken, idFromGrid)   
                        successMessage = "Categoria desativada!"
                    } else {
                        result = await activateCategoryByID(userSystemContext.systemUser.jwtToken, idFromGrid)
                        successMessage = "Categoria ativada!"
                    }
              
                    if(result.status == 200) {
                        popupContext.setSuccessMessage(successMessage)
                        popupContext.setShowSuccess(true)
                        setOperationDone((prev) => {
                            return !prev
                        })
                    } else {
                        popupContext.setErrorMessage(result.response)
                        popupContext.setShowError(true)
                    }
    
                    }
    
                setDoingOperation(false)
            }
        }

    useEffect(() => {
        getAllCategoriesHandler()
    }, [operationDone])

    useEffect(() => {
        toggleCategoryHandler()
    }, [doingOperation])

    return(
        <div className={`${style.container}`}>

            <PopupMessage/>

            {registerScreen 
                ?
                    <ItemRegister
                    setRegisterScreen={setRegisterScreen}
                    setOperationDone={setOperationDone}
                    where={Where.category}
                    itemA={{field: "Categoria", placeholder: "Nome da categoria"}}
                    />
                :
                    null
            }

            <div>
                <h1 className={`text-white font-bahnscrift_bold text-xl text-center my-5`}>CATEGORIAS DO SISTEMA</h1>
            </div>

            <hr className='text-grey opacity-35 -mt-2 w-[10%] mx-auto pb-5'/>

            <button 
                onClick={() => setRegisterScreen(true)}
                className={`border-solid ml-[4.5vw] w-[10rem] border-[.1rem] px-2 py-1 rounded-md text-[#8BCB1A] border-[#8BCB1A] hover:bg-[#8BCB1A] hover:text-white`}>
                Criar categoria
            </button>


            {loadingGrid 
                ?
                    <TableLoading/>
                :
                    !hasData 
                        ?   
                            <h1 className={`text-center text-white mt-[5rem] text-xl animate-bounce`}>Nenhuma categoria criada 🫢</h1>
                        :
                        <CategoryGridComponent
                            changeData={changeData}
                            gridData={gridData}
                            setIDFromGrid={setIDFromGrid}
                            setMethod={setMethod}
                            setDoingOperation={setDoingOperation}
                        />
                }
    </div>
    )
}