enum Method {
    "Deactivation" = 1,
    "Activation"
}

export default Method