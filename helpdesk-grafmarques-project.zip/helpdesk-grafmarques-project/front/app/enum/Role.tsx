enum Role {
    "ADMIN" = "Admin",
    "AGENT" = "Agente",
    "USER" = "Usuário"
}

export default Role