enum Where {
    user = 1,
    category,
    sector,
    profile,
    pwd_recovery
}

export default Where