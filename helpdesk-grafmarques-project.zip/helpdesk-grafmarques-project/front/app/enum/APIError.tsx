enum APIError {
    "Forbidden" = "Você não tem permissão para executar essa operação",
    "Connection" = "Erro de conexão com o servidor"
}

export default APIError