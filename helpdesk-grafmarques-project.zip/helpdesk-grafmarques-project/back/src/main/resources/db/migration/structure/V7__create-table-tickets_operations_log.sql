CREATE TABLE tickets_operations_logs(
    id UUID PRIMARY KEY NOT NULL,
    ticket_id UUID REFERENCES tickets(id) NOT NULL,
    operation VARCHAR(50) NOT NULL,
    details VARCHAR(150) NOT NULL,
    user_id UUID REFERENCES users(id) NOT NULL,
    performed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);