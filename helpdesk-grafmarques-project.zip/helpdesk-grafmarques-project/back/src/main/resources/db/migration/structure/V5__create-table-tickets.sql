CREATE TABLE tickets (
    id UUID PRIMARY KEY NOT NULL,
    os INT GENERATED ALWAYS AS IDENTITY,
    title VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    status VARCHAR(11) NOT NULL,
    author_id UUID REFERENCES users(id) NOT NULL,
    applicant VARCHAR(50) NOT NULL,
    priority VARCHAR(12) NOT NULL,
    sector_id UUID REFERENCES sectors(id) NOT NULL,
    agent_id UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    assigned_at TIMESTAMP,
    closed_at TIMESTAMP,
    category_id UUID REFERENCES categories(id) NOT NULL,
    active BOOLEAN DEFAULT TRUE NOT NULL
);