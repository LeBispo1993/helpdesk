CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    -- Atualiza a coluna updated_at para o momento atual
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_updated_at
BEFORE UPDATE ON tickets
FOR EACH ROW
EXECUTE FUNCTION update_timestamp();


CREATE OR REPLACE FUNCTION update_ticket_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    -- Atualiza a coluna updated_at na tabela tickets
    UPDATE tickets
    SET updated_at = CURRENT_TIMESTAMP
    WHERE id = NEW.ticket_id;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_ticket_on_comment_insert
AFTER INSERT ON tickets_comments
FOR EACH ROW
EXECUTE FUNCTION update_ticket_timestamp();