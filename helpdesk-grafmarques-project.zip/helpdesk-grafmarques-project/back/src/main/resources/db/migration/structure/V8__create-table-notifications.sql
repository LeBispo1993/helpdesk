CREATE TABLE notifications(
    id UUID PRIMARY KEY NOT NULL,
    recipient_id UUID REFERENCES users(id) NOT NULL,
    content VARCHAR(100) NOT NULL,
    ticket_id UUID REFERENCES tickets(id),
    viewed BOOLEAN DEFAULT FALSE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);