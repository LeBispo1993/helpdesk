INSERT INTO sectors (id, name, server) VALUES
    (gen_random_uuid(), 'T.I', true);