CREATE TABLE tickets_comments(
    id UUID PRIMARY KEY NOT NULL,
    content VARCHAR(200) NOT NULL,
    ticket_id UUID REFERENCES tickets(id) NOT NULL,
    user_id UUID REFERENCES users(id) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);