package br.com.grafmarques.helpdesk.data.DTO.v1.auth;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.SectorDTO;
import br.com.grafmarques.helpdesk.model.enums.Role;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

public class RegisterDTO {

    @NotBlank
    @Size(min = 4, max = 50)
    private String name;

    @Email
    @Size(max = 60)
    private String email;

    @NotNull
    private Role role;

    @NotBlank
    @Size(min = 8, max = 50)
    private String password;

    @NotNull
    private SectorDTO sector;

    @JsonIgnore
    private LocalDateTime createdAt = LocalDateTime.now();

    @JsonIgnore
    private Boolean active = true;

    public RegisterDTO(String name, String email, Role role, String password, SectorDTO sector) {
        this.name = name;
        this.email = email;
        this.role = role;
        this.password = password;
        this.sector = sector;
    }

    public @NotBlank @Size(min = 8, max = 50) String getName() {
        return name;
    }

    public @Email @Size(max = 60) String getEmail() {
        return email;
    }

    public @NotNull Role getRole() {
        return role;
    }

    public void setRole(@NotNull Role role) {
        this.role = role;
    }

    public @NotBlank @Size(min = 8, max = 100) String getPassword() {
        return password;
    }

    public @NotNull SectorDTO getSector() {
        return sector;
    }

    public void setSector(@NotNull SectorDTO sector) {
        this.sector = sector;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public Boolean getActive() {
        return active;
    }
}
