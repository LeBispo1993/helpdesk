package br.com.grafmarques.helpdesk.data.DTO.v1.util;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class ChangePasswordDTO {

    @NotBlank
    @Size(min = 8, max = 50)
    private String oldPassword;

    @NotBlank
    @Size(min = 8, max = 50)
    private String newPassword;

    public ChangePasswordDTO(String oldPassword, String newPassword) {
        this.oldPassword = oldPassword;
        this.newPassword = newPassword;
    }

    public String getOldPassword() {
        return oldPassword;
    }

    public String getNewPassword() {
        return newPassword;
    }
}
