package br.com.grafmarques.helpdesk.model;

import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;

@Entity
@Table(name = "users_operations_logs")
public class UserOperationLog implements Serializable {

    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(unique = true, length = 50, nullable = false)
    private String operation;

    @Column(length = 200, nullable = false)
    private String details;

    @Column(name = "performed_at", nullable = false)
    private LocalDateTime performedAt;

    @ManyToOne @JoinColumn(name = "user_id", referencedColumnName = "id", nullable = false)
    private User user;

    public UserOperationLog() {}

    public UserOperationLog(UUID id, String operation, String details, LocalDateTime performedAt, User user) {
        this.id = id;
        this.operation = operation;
        this.details = details;
        this.performedAt = performedAt;
        this.user = user;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public LocalDateTime getPerformedAt() {
        return performedAt;
    }

    public void setPerformedAt(LocalDateTime performedAt) {
        this.performedAt = performedAt;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UserOperationLog that = (UserOperationLog) o;
        return Objects.equals(id, that.id)
                && Objects.equals(operation, that.operation)
                && Objects.equals(details, that.details)
                && Objects.equals(performedAt, that.performedAt)
                && Objects.equals(user, that.user);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, operation, details, performedAt, user);
    }
}
