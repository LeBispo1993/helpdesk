package br.com.grafmarques.helpdesk.services.auth;

import br.com.grafmarques.helpdesk.data.DTO.v1.auth.TokenDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.exceptions.auth.JwtCreationTokenException;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.User;
import br.com.grafmarques.helpdesk.services.UserOperationLogService;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.UUID;
import java.util.logging.Logger;

@Service
public class TokenService {
    private final Logger LOGGER = Logger.getLogger(TokenService.class.getName());
    private String subject;

    @Value("${security.jwt.token.secret}")
    private String secretKey;

    private final UserOperationLogService userOperationLogService;
    private final Mapper mapper;

    @Autowired
    public TokenService(
            UserOperationLogService userOperationLogService,
            Mapper mapper
    ) {
        this.userOperationLogService = userOperationLogService;
        this.mapper = mapper;
    }


    public TokenDTO generateToken(User user) {
        LOGGER.info("Generating token");

        try {
            Algorithm algorithm = Algorithm.HMAC256(secretKey);
            Instant createdAt = getIssueDate();
            Instant expireAt = generateExpirationDate(createdAt);
            String token = JWT.create()
                    .withIssuer("grafmarques")
                    .withSubject(user.getId().toString())
                    .withIssuedAt(createdAt)
                    .withExpiresAt(expireAt)
                    .sign(algorithm);
            
            userOperationLogService.registerOperationLog(
                    "Login",
                    "User login successfully (role: " + user.getRole() + ")",
                    mapper.map(user, UserDTO.class)
            );

            return new TokenDTO(user.getId(), user.getRole(), token, createdAt, expireAt);
        }
        catch (Exception e) {
            throw new JwtCreationTokenException("Erro durante a geração do token");
        }
    }

    public UUID validateToken(String token) {
        LOGGER.info("Validating token");

        try {
            Algorithm algorithm = Algorithm.HMAC256(secretKey);
            subject = JWT.require(algorithm)
                    .withIssuer("grafmarques")
                    .build()
                    .verify(token)
                    .getSubject();
            return UUID.fromString(subject);
        }
        catch (JWTVerificationException e) {
            LOGGER.warning("Erro na validação do token: " + e.getMessage());
            return null;
        }
    }

    private Instant generateExpirationDate(Instant createdAt) {
        return createdAt.plus(Duration.ofHours(12));
    }

    private Instant getIssueDate() {
        return Instant.now();
    }

    public UUID getUserId() {
        return UUID.fromString(subject);
    }
}
