package br.com.grafmarques.helpdesk.services.util;

import br.com.grafmarques.helpdesk.data.DTO.v1.util.TicketFilterDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.Dates;
import br.com.grafmarques.helpdesk.exceptions.general.DateFilterException;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Service
public class DateUtil {
    public static final TicketFilterDTO DEFAULT_DATE_FILTER = new TicketFilterDTO(null, null, null, null, null);
    private static final int RANGE_DAYS = 7;

    public static Dates setDateFilter(LocalDate startDate, LocalDate endDate) {
        if (endDate == null) endDate = LocalDate.now();
        if (startDate == null) startDate = endDate.minusDays(RANGE_DAYS);
        if (endDate.isBefore(startDate)) throw new DateFilterException("Data de início deve ser anterior a data final");
        LocalDateTime startDateTime = startDate.atTime(0, 0, 0);
        LocalDateTime endDateTime = endDate.atTime(23, 59, 59);
        return new Dates(startDateTime, endDateTime);
    }
}
