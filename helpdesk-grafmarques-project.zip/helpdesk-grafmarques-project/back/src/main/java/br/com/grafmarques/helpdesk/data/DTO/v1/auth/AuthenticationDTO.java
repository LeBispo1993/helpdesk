package br.com.grafmarques.helpdesk.data.DTO.v1.auth;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;

public class AuthenticationDTO {

    @Email
    private String email;

    @Size(min = 8, max = 100)
    private String password;

    public AuthenticationDTO(String email, String password) {
        this.email = email.trim();
        this.password = password.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
