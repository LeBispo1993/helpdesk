package br.com.grafmarques.helpdesk.data.DTO.v1.create;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

public class SectorCreateDTO {

    @NotBlank
    @Size(min = 2, max = 100)
    private String name;

    @NotNull
    private Boolean server;

    @JsonIgnore
    private LocalDateTime createdAt = LocalDateTime.now();

    @JsonIgnore
    private Boolean active = true;

    public SectorCreateDTO() {}

    public SectorCreateDTO(String name, Boolean server) {
        this.name = name;
        this.server = server;
    }

    public String getName() {
        return name;
    }

    public Boolean getServer() {
        return server;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public Boolean getActive() {
        return active;
    }
}
