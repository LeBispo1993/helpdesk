package br.com.grafmarques.helpdesk.data.DTO.v1.util;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;

import java.time.LocalDateTime;
import java.util.UUID;

public class UserOperationLogDTO {
    private UUID id;
    private String operation;
    private String details;
    private LocalDateTime performedAt;
    private UserDTO user;

    public UserOperationLogDTO() {}

    public UserOperationLogDTO(UUID id, String operation, String details, LocalDateTime performedAt, UserDTO user) {
        this.id = id;
        this.operation = operation;
        this.details = details;
        this.performedAt = performedAt;
        this.user = user;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public LocalDateTime getPerformedAt() {
        return performedAt;
    }

    public void setPerformedAt(LocalDateTime performedAt) {
        this.performedAt = performedAt;
    }

    public UserDTO getUser() {
        return user;
    }

    public void setUser(UserDTO user) {
        this.user = user;
    }
}
