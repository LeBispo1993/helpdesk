package br.com.grafmarques.helpdesk.data.DTO.v1.util;

import jakarta.validation.constraints.NotNull;

import java.util.List;
import java.util.UUID;

public class NotificationIdsDTO {

    @NotNull
    private List<UUID> ids;

    public NotificationIdsDTO() {}

    public NotificationIdsDTO(List<UUID> ids) {
        this.ids = ids;
    }

    public List<UUID> getIds() {
        return ids;
    }
}
