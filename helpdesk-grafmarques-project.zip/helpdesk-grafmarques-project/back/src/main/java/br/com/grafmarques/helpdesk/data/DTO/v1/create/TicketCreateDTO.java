package br.com.grafmarques.helpdesk.data.DTO.v1.create;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.CategoryDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.SectorDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.model.enums.Priority;
import br.com.grafmarques.helpdesk.model.enums.Status;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

public class TicketCreateDTO {

    @NotBlank
    @Size(min = 5, max = 50)
    private String title;

    @JsonIgnore
    private Status status = Status.ABERTO;

    @NotBlank
    @Size(min = 5, max = 500)
    private String description;

    @NotBlank
    @Size(min = 3, max = 50)
    private String applicant;

    @NotNull
    private Priority priority;

    @JsonIgnore
    private LocalDateTime createdAt = LocalDateTime.now();

    @JsonIgnore
    private LocalDateTime updatedAt = createdAt;

    @JsonIgnore
    private UserDTO author;

    @NotNull
    private SectorDTO sector;

    @NotNull
    private CategoryDTO category;

    @JsonIgnore
    private Boolean active = true;

    public TicketCreateDTO() {}

    public TicketCreateDTO(String title, Status status, String description, String applicant, Priority priority, UserDTO author, SectorDTO sector, CategoryDTO category) {
        this.title = title;
        this.status = status;
        this.description = description;
        this.applicant = applicant;
        this.priority = priority;
        this.author = author;
        this.sector = sector;
        this.category = category;
    }

    public String getTitle() {
        return title;
    }

    public Status getStatus() {
        return status;
    }

    public String getDescription() {
        return description;
    }

    public String getApplicant() {
        return applicant;
    }

    public Priority getPriority() {
        return priority;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public UserDTO getAuthor() {
        return author;
    }

    public void setAuthor(UserDTO author) {
        this.author = author;
    }

    public SectorDTO getSector() {
        return sector;
    }

    public CategoryDTO getCategory() {
        return category;
    }

    public Boolean getActive() {
        return active;
    }
}
