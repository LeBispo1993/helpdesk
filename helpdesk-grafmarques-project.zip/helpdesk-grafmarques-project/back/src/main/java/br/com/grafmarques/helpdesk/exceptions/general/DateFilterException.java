package br.com.grafmarques.helpdesk.exceptions.general;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class DateFilterException extends RuntimeException{
    public DateFilterException(String message) {
        super(message);
    }
}
