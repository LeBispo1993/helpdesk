package br.com.grafmarques.helpdesk.projections;

public interface UserAgentProjection {
    String getName();
    SectorProjection getSector();
}
