package br.com.grafmarques.helpdesk.data.DTO.v1.util;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public class UserEmailDTO {

    @Email
    @NotBlank
    private String email;

    public UserEmailDTO() {}

    public UserEmailDTO(String email) {
        this.email = email.trim();
    }

    public @Email @NotBlank String getEmail() {
        return email;
    }
}
