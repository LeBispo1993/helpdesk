package br.com.grafmarques.helpdesk.data.DTO.v1.util;

import br.com.grafmarques.helpdesk.model.enums.Priority;
import br.com.grafmarques.helpdesk.model.enums.Status;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public class TicketFilterDTO {
    private LocalDate startDate;
    private LocalDate endDate;
    private final List<Status> status;
    private final List<UUID> categories;
    private final List<Priority> priorities;

    public TicketFilterDTO(LocalDate startDate, LocalDate endDate, List<Status> status, List<UUID> categories, List<Priority> priorities) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
        this.categories = categories;
        this.priorities = priorities;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public List<Status> getStatus() {
        return status;
    }

    public @NotNull List<UUID> getCategories() {
        return categories;
    }

    public @NotNull List<Priority> getPriorities() {
        return priorities;
    }
}
