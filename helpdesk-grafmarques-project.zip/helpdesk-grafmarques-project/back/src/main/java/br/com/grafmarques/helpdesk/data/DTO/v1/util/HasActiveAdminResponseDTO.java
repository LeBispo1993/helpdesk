package br.com.grafmarques.helpdesk.data.DTO.v1.util;

public class HasActiveAdminResponseDTO {
    private Boolean value;

    public HasActiveAdminResponseDTO(Boolean value) {
        this.value = value;
    }

    public Boolean getValue() {
        return value;
    }
}
