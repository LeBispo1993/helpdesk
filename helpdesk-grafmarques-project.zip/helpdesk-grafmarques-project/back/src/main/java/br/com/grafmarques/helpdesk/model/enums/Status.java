package br.com.grafmarques.helpdesk.model.enums;

public enum Status {
    ABERTO("aberto"),
    PROCESSANDO("processando"),
    FECHADO("fechado");

    private String status;

    Status(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }
}
