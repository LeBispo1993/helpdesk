package br.com.grafmarques.helpdesk.services.email;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.exceptions.email.EmailSendingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.logging.Logger;

@Service
public class EmailService {
    private final Logger LOGGER = Logger.getLogger(EmailService.class.getName());

    @Value("${website.url}")
    private String WEBSITE_URL;

    private final JavaMailSender javaMailSender;

    @Autowired
    public EmailService(JavaMailSender javaMailSender) { this.javaMailSender = javaMailSender; }

    public void sendPasswordRecoveryEmail(UserDTO user) {
        LOGGER.info("Sending recovery password email to user");

        try {
            MimeMessage message = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setTo("<" + user.getEmail() + ">");
            helper.setFrom("noreply@grafmarques.com.br");
            helper.setSubject("Recuperação de senha");

            String template = getMailTemplate("templates/password-recovery.html");
            template = template.replace("${name}", user.getName());
            String url = WEBSITE_URL + "password_recovery/" + user.getId();
            template = template.replace("${url}", url);
            template = template.replace("${currentYear}", String.valueOf(LocalDate.now().getYear()));

            helper.setText(
                    "Acesse este link para alterar sua senha: " + url,
                    template
            );

            javaMailSender.send(message);
        }
        catch (Exception e) {
            throw new EmailSendingException("Erro ao tentar mandar e-mail");
        }
    }

    private String getMailTemplate(String path) throws IOException {
        ClassPathResource resource = new ClassPathResource(path);
        return new String(resource.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
    }
}
