package br.com.grafmarques.helpdesk.mapper.implementations;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.*;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.projections.*;
import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Primary
public class ModelMapperImpl implements Mapper {
    private static final ModelMapper modelMapper = new ModelMapper();

    public <O, D> D map(O origin, Class<D> destiny) {
        return modelMapper.map(origin, destiny);
    }

    public <O, D> List<D> map(List<O> origin, Class<D> destiny) {
        List<D> destinyList = new ArrayList<>();
        for (O object : origin) {
            destinyList.add(modelMapper.map(object, destiny));
        }
        return destinyList;
    }

    public TicketDTO map(TicketDetailsProjection origin) {
        UserDTO author = mapUserDTO(origin.getAuthor());
        SectorDTO sector = mapSectorDTO(origin.getSector());
        UserDTO agent = mapAgent(origin);
        List<TicketCommentDTO> comments = mapComments(origin.getComments());
        CategoryDTO category = mapCategoryDTO(origin.getCategory());

        return new TicketDTO(
                origin.getId(),
                origin.getOs(),
                origin.getTitle(),
                origin.getStatus(),
                origin.getDescription(),
                origin.getApplicant(),
                origin.getPriority(),
                origin.getCreatedAt(),
                origin.getUpdatedAt(),
                origin.getAssignedAt(),
                origin.getClosedAt(),
                author,
                sector,
                agent,
                comments,
                category,
                origin.getActive()
        );
    }

    private UserDTO mapUserDTO(UserAuthorProjection origin) {
        UserDTO author = new UserDTO();
        author.setId(origin.getId());
        author.setName(origin.getName());
        return author;
    }

    private SectorDTO mapSectorDTO(SectorProjection origin) {
        SectorDTO sector = new SectorDTO();
        sector.setId(origin.getId());
        sector.setName(origin.getName());
        return sector;
    }

    private UserDTO mapAgent(TicketDetailsProjection origin) {
        if (origin.getAgent() == null) return null;

        UserDTO agent = new UserDTO();
        agent.setName(origin.getAgent().getName());
        agent.setSector(mapSectorDTO(origin.getAgent().getSector()));
        return agent;
    }

    private List<TicketCommentDTO> mapComments(List<TicketCommentProjection> origin) {
        return origin.stream().map(
                comment -> {
                    TicketCommentDTO commentDTO = new TicketCommentDTO();
                    UserDTO userComment = mapUserDTO(comment.getUser());
                    commentDTO.setContent(comment.getContent());
                    commentDTO.setCreatedAt(comment.getCreatedAt());
                    commentDTO.setUser(userComment);
                    return commentDTO;
                }
        ).toList();
    }

    private CategoryDTO mapCategoryDTO(CategoryProjection origin) {
        CategoryDTO category = new CategoryDTO();
        category.setId(origin.getId());
        category.setName(origin.getName());
        return category;
    }

}
