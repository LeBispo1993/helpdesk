package br.com.grafmarques.helpdesk.controllers;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.auth.AuthenticationDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.auth.RegisterDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.auth.TokenDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.RecoverPasswordDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.ResponseDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.UserEmailDTO;
import br.com.grafmarques.helpdesk.exceptions.auth.WrongPasswordException;
import br.com.grafmarques.helpdesk.model.User;
import br.com.grafmarques.helpdesk.services.UserService;
import br.com.grafmarques.helpdesk.services.auth.TokenService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = {"http://localhost:8080", "http://localhost:3000", "https://sistema-de-chamados-vo59.vercel.app"})
@RestController
@RequestMapping("/auth")
@Tag(name = "Authentication", description = "Endpoints to register and log into to the system")
public class AuthenticationController {

    private final UserService userService;
    private final AuthenticationManager authenticationManager;
    private final TokenService tokenService;

    @Autowired
    public AuthenticationController(
            UserService userService,
            AuthenticationManager authenticationManager,
            TokenService tokenService
    ) {
        this.userService = userService;
        this.authenticationManager = authenticationManager;
        this.tokenService = tokenService;
    }

    @GetMapping(value = "/check-token")
    @Operation(
            summary = "Check if token is expired",
            description = "Check if token is expired",
            tags = {"Authentication"},
            method = "GET"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(responseCode = "200", description = "Success", content = @Content),
                    @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
                    @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content),
                    @ApiResponse(responseCode = "500", description = "Internal Error", content = @Content),
            }
    )
    public ResponseEntity<?> checkToken() {
        return ResponseEntity.ok().build();
    }

    @PostMapping(
            value = "/login",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    @Operation(
            summary = "Log into the system",
            description = "Log into the system with email and password",
            tags = {"Authentication"},
            method = "POST",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    content = @Content(
                            mediaType = "application/json",
                            examples = @ExampleObject(
                                    value = """
                                            { "email*": "string", "password*": "string" }
                                            """
                            )
                    )
            )
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success",
                            content = @Content(
                                    schema = @Schema(
                                            implementation = TokenDTO.class
                                    )
                            )
                    ),
                    @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
                    @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
                    @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content),
                    @ApiResponse(responseCode = "404", description = "Not Found", content = @Content),
                    @ApiResponse(responseCode = "500", description = "Internal Error", content = @Content),
            }
    )
    public ResponseEntity<TokenDTO> login(@Valid @RequestBody AuthenticationDTO data) {
        userService.checkActivity(data.getEmail());

        UsernamePasswordAuthenticationToken usernamePassword =
                new UsernamePasswordAuthenticationToken(data.getEmail(), data.getPassword());

        TokenDTO token;
        try {
            Authentication auth = authenticationManager.authenticate(usernamePassword);
            token = tokenService.generateToken((User) auth.getPrincipal());
        }
        catch (AuthenticationException e){
            throw new WrongPasswordException("Senha incorreta");
        }

        return ResponseEntity.ok(token);
    }

    @PostMapping(
            value = "/register",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    @Operation(
            summary = "Register into the system",
            description = "Register into the system with name, email, password, role and sector",
            tags = {"Authentication"},
            method = "POST",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    content = @Content(
                            mediaType = "application/json",
                            examples = @ExampleObject(
                                    value = """
                                            { "name*": "string", "email*": "string", "password*": "string", "role*": "USER", "sector*": { "id": "uuid" } }
                                            """
                            )
                    )
            )
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "201",
                            description = "Created",
                            content = @Content(
                                    schema = @Schema(
                                            implementation = UserDTO.class
                                    )
                            )
                    ),
                    @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
                    @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
                    @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content),
                    @ApiResponse(responseCode = "404", description = "Not Found", content = @Content),
                    @ApiResponse(responseCode = "500", description = "Internal Error", content = @Content),
            }
    )
    public ResponseEntity<UserDTO> register(@Valid @RequestBody RegisterDTO data) {
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(userService.register(data));
    }

    @PostMapping(
            value = "/register-first-admin",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    @Operation(
            summary = "Register first admin into the system",
            description = "Register first admin into the system with name, email, password, role and sector",
            tags = {"Authentication"},
            method = "POST",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    content = @Content(
                            mediaType = "application/json",
                            examples = @ExampleObject(
                                    value = """
                                            { "name*": "string", "email*": "string", "password*": "string", "role*": "ADMIN", "sector*": { "name": "string" } }
                                            """
                            )
                    )
            )
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "201",
                            description = "Created",
                            content = @Content(
                                    schema = @Schema(
                                            implementation = UserDTO.class
                                    )
                            )
                    ),
                    @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
                    @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
                    @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content),
                    @ApiResponse(responseCode = "404", description = "Not Found", content = @Content),
                    @ApiResponse(responseCode = "500", description = "Internal Error", content = @Content),
            }
    )
    public ResponseEntity<UserDTO> registerFirstAdmin(@Valid @RequestBody RegisterDTO data) {
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(userService.registerFirstAdmin(data));
    }

    @PostMapping(
            value = "/send-password-recovery-email",
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    @Operation(
            summary = "Send password recovery code",
            description = "Send password recovery code",
            tags = {"Authentication"},
            method = "POST",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    content = @Content(
                            mediaType = "application/json",
                            examples = @ExampleObject(
                                    value = """
                                            { "email*": "string" }
                                            """
                            )
                    )
            )
    )
    @ApiResponses(
            value = {
                    @ApiResponse(responseCode = "200", description = "Success", content = @Content),
                    @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
                    @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
                    @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content),
                    @ApiResponse(responseCode = "404", description = "Not Found", content = @Content),
                    @ApiResponse(responseCode = "500", description = "Internal Error", content = @Content),
            }
    )
    public ResponseEntity<ResponseDTO> sendPasswordRecoveryEmail(@Valid @RequestBody UserEmailDTO data) {
        userService.sendPasswordRecoveryEmail(data.getEmail());
        return ResponseEntity.ok(new ResponseDTO("E-mail enviado com sucesso! Verifique sua caixa de entrada"));
    }

    @PostMapping(
            value = "/recover-password",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    @Operation(
            summary = "Recover password",
            description = "Recover password",
            tags = {"Authentication"},
            method = "POST",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    content = @Content(
                            mediaType = "application/json",
                            examples = @ExampleObject(
                                    value = """
                                            { "id*": "uuid", "password*": "string" }
                                            """
                            )
                    )
            )
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success",
                            content = @Content(
                                    schema = @Schema(implementation = UserDTO.class)
                            )
                    ),
                    @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
                    @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
                    @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content),
                    @ApiResponse(responseCode = "404", description = "Not Found", content = @Content),
                    @ApiResponse(responseCode = "500", description = "Internal Error", content = @Content),
            }
    )
    public ResponseEntity<UserDTO> recoverPassword(@Valid @RequestBody RecoverPasswordDTO data) {
        return ResponseEntity.ok(userService.recoverPassword(data));
    }
}
