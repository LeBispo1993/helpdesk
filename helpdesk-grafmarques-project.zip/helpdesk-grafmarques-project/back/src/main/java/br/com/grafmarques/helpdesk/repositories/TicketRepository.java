package br.com.grafmarques.helpdesk.repositories;

import br.com.grafmarques.helpdesk.model.Ticket;
import br.com.grafmarques.helpdesk.projections.TicketDetailsProjection;
import br.com.grafmarques.helpdesk.projections.TicketProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface TicketRepository extends JpaRepository<Ticket, UUID> {
    Optional<TicketDetailsProjection> findTicketDetailsById(UUID id);
    List<TicketProjection> findByUpdatedAtBetweenOrderByUpdatedAtDesc(LocalDateTime startDate, LocalDateTime endDate);
    List<TicketProjection> findByUpdatedAtBetweenAndActiveTrueOrderByUpdatedAtDesc(LocalDateTime startDate, LocalDateTime endDate);
    List<TicketProjection> findByAuthorIdAndActiveIsTrueAndUpdatedAtBetweenOrderByUpdatedAtDesc(UUID authorId, LocalDateTime startDate, LocalDateTime endDate);
}
