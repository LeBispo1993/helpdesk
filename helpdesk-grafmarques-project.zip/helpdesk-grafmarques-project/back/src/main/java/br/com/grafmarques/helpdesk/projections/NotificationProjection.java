package br.com.grafmarques.helpdesk.projections;

import java.time.LocalDateTime;
import java.util.UUID;

public interface NotificationProjection {
    UUID getId();
    String getContent();
    UserRecipientProjection getRecipient();
    TicketNotificationProjection getTicket();
    Boolean getViewed();
    LocalDateTime getCreatedAt();
}
