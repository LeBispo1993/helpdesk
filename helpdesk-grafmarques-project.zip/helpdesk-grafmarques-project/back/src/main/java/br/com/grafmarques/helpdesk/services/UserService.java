package br.com.grafmarques.helpdesk.services;

import br.com.grafmarques.helpdesk.controllers.UserController;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.ChangePasswordDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.update.UserUpdateDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.auth.RegisterDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.HasActiveAdminResponseDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.RecoverPasswordDTO;
import br.com.grafmarques.helpdesk.exceptions.general.NotFoundException;
import br.com.grafmarques.helpdesk.exceptions.general.RepeatedDataException;
import br.com.grafmarques.helpdesk.exceptions.auth.EmailAlreadyInUseException;
import br.com.grafmarques.helpdesk.exceptions.auth.InactiveUserException;
import br.com.grafmarques.helpdesk.exceptions.auth.RegisterFirstAdminException;
import br.com.grafmarques.helpdesk.exceptions.auth.WrongPasswordException;
import br.com.grafmarques.helpdesk.exceptions.general.UnauthorizedException;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.Sector;
import br.com.grafmarques.helpdesk.model.User;
import br.com.grafmarques.helpdesk.model.enums.Role;
import br.com.grafmarques.helpdesk.repositories.UserRepository;
import br.com.grafmarques.helpdesk.services.auth.TokenService;
import br.com.grafmarques.helpdesk.services.email.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.logging.Logger;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Service
public class UserService {
    private final Logger LOGGER = Logger.getLogger(UserService.class.getName());

    private final UserRepository repository;
    private final SectorService sectorService;
    private final TokenService tokenService;
    private final UserOperationLogService userOperationLogService;
    private final NotificationService notificationService;
    private final EmailService emailService;
    private final Mapper mapper;

    @Autowired
    public UserService(
            UserRepository repository,
            SectorService sectorService,
            TokenService tokenService,
            UserOperationLogService userOperationLogService,
            NotificationService notificationService,
            EmailService emailService,
            Mapper mapper
    ) {
        this.repository = repository;
        this.sectorService = sectorService;
        this.tokenService = tokenService;
        this.userOperationLogService = userOperationLogService;
        this.notificationService = notificationService;
        this.emailService = emailService;
        this.mapper = mapper;
    }

    public UserDetails findUserDetailsByEmail(String email) {
        LOGGER.info("Finding user details by email");
        return repository.findByEmail(email);
    }

    public UserDTO findById(UUID id) {
        LOGGER.info("Finding user by id");
        UserDTO user = mapper.map(
                repository.findById(id)
                        .orElseThrow(() -> new NotFoundException("Nenhum usuário encontrado para este id")),
                UserDTO.class
        );
        return addHateoasLinks(user);
    }

    private User findEntityById(UUID id) {
        return repository.findById(id).orElseThrow(() -> new NotFoundException("Nenhum usuário encontrado para este id"));
    }

    public List<UserDTO> findAll() {
        LOGGER.info("Finding all users");
        List<UserDTO> users = mapper.map(repository.findAllBy(), UserDTO.class);
        return addHateoasLinksToList(users);
    }

    public void checkActivity(String email) {
        LOGGER.info("Checking if the user is active");
        if (isInactive(email)) throw new InactiveUserException("Usuário inativo");
    }

    public List<UserDTO> findBySectorId(UUID sectorId) {
        LOGGER.info("Finding users by sector");
        return mapper.map(repository.findBySectorId(sectorId), UserDTO.class);
    }

    @Transactional
    public UserDTO register(RegisterDTO data) {
        LOGGER.info("Registering a user");

        if ( emailAlreadyInUse(data.getEmail().trim()) ) throw new EmailAlreadyInUseException("Este e-mail já está em uso");

        String passwordEncoder = new BCryptPasswordEncoder().encode(data.getPassword().trim());
        User entity = mapper.map(data, User.class);
        entity.setName(entity.getName().trim());
        entity.setEmail(entity.getEmail().trim());

        entity.setPassword(passwordEncoder);

        UserDTO user = mapper.map(repository.save(entity), UserDTO.class);

        userOperationLogService.registerOperationLog(
                "Registration",
                "User registration completed successfully",
                user
        );

        notificationService.create(
                "Seja bem-vindo!",
                user,
                null
        );

        return addHateoasLinks(user);
    }

    public UserDTO registerFirstAdmin(RegisterDTO data) {
        LOGGER.info("Registering the first admin");
        if (hasActiveAdmin().getValue()) throw new RegisterFirstAdminException("Já existem usuários administradores");
        data.setSector(sectorService.findByName(data.getSector().getName().trim()));
        data.setRole(Role.ADMIN);
        return register(data);
    }

    public HasActiveAdminResponseDTO hasActiveAdmin() {
        LOGGER.info("Checking if there re admins");
        return new HasActiveAdminResponseDTO(repository.countUserIdByRoleAndActive(Role.ADMIN, true) != 0);
    }

    @Transactional
    public UserDTO update(UserUpdateDTO data) {
        LOGGER.info("Updating user");

        User entity = findEntityById(data.getId());
        StringBuilder fields = new StringBuilder();

        if (data.getName() != null) {
            entity.setName(data.getName().trim());
            fields.append(" name");
        }
        if (data.getEmail() != null) {
            if (emailAlreadyInUse(data.getEmail().trim(), data.getId())) throw new EmailAlreadyInUseException("Este e-mail já está em uso");

            entity.setEmail(data.getEmail().trim());
            fields.append(" email");
        }
        if (data.getPassword() != null) {
            entity.setPassword(new BCryptPasswordEncoder().encode(data.getPassword().trim()));
            fields.append(" password");
        }
        if (data.getRole() != null) {
            entity.setRole(data.getRole());
            fields.append(" role");
        }
        if (
                data.getSector() != null
                && data.getSector().getId() != null
        ) {
            entity.setSector(mapper.map(data.getSector(), Sector.class));
            fields.append(" sector");
        }

        UserDTO user = mapper.map(repository.save(entity), UserDTO.class);

        userOperationLogService.registerOperationLog(
                "Update",
                "User updated successfully. Field(s): " + fields,
                user
        );

        notificationService.create(
                "Alguns de seus dados foram alterados. Contate o administrador para mais informações",
                user,
                null
        );

        return addHateoasLinks(user);
    }

    private boolean emailAlreadyInUse(String email) {
        return repository.findIdByEmail(email).isPresent();
    }

    private boolean emailAlreadyInUse(String email, UUID id) {
        return repository.findIdByEmail(email, id).isPresent();
    }

    @Transactional
    public UserDTO changeActive(UUID id, boolean value) {
        LOGGER.info("Changing user activity to " + value);

        User entity = findEntityById(id);

        if (!value && id == tokenService.getUserId()) {
            throw new UnauthorizedException("Não é possível desativar sua própria conta");
        }

        entity.setActive(value);

        UserDTO user = mapper.map(repository.save(entity), UserDTO.class);

        userOperationLogService.registerOperationLog(
                "Change of activity",
                "User activity changed with successfully to " + value + " value",
                user
        );

        return addHateoasLinks(user);
    }

    @Transactional
    public UserDTO changePassword(UUID id, ChangePasswordDTO passwords) {
        LOGGER.info("Changing user password");

        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        if (passwords.getOldPassword().trim().equals(passwords.getNewPassword().trim())) throw new RepeatedDataException("As senhas são iguais");

        User entity = findEntityById(id);

        if (!encoder.matches(passwords.getOldPassword().trim(), entity.getPassword())) throw new WrongPasswordException("Senha incorreta");

        String newPassword = new BCryptPasswordEncoder().encode(passwords.getNewPassword().trim());
        entity.setPassword(newPassword);

        UserDTO user = mapper.map(repository.save(entity), UserDTO.class);

        userOperationLogService.registerOperationLog(
                "Change of password",
                "User password changed successfully",
                user
        );

        notificationService.create(
                "Sua senha foi alterada",
                user,
                null
        );

        return addHateoasLinks(user);
    }

    public void sendPasswordRecoveryEmail(String email) {
        checkActivity(email);
        UserDTO user = mapper.map(repository.findUserByEmail(email), UserDTO.class);
        emailService.sendPasswordRecoveryEmail(user);

        userOperationLogService.registerOperationLog(
                "Password recovery email sent",
                "Password recovery email sent successfully",
                user
        );

        notificationService.create(
                "Um email para a recuperação de senha foi enviado para seu e-mail. Verifique sua caixa de entrada",
                user,
                null
        );
    }

    public UserDTO recoverPassword(RecoverPasswordDTO passwordRecover) {
        User entity = findEntityById(passwordRecover.getId());
        checkActivity(entity.getEmail());
        String newPassword = new BCryptPasswordEncoder().encode(passwordRecover.getPassword().trim());
        entity.setPassword(newPassword);

        UserDTO user = mapper.map(repository.save(entity), UserDTO.class);

        userOperationLogService.registerOperationLog(
                "Password recovery",
                "User password changed successfully",
                user
        );

        notificationService.create(
                "Sua senha foi alterada",
                user,
                null
        );

        return user;
    }

    private Optional<UUID> findIdByEmail(String email) {
        LOGGER.info("Checking if the email is available");

        return repository.findIdByEmail(email);
    }

    private boolean isInactive(String email) {
        return !repository
                .findActiveByEmail(email)
                .orElseThrow(() -> new NotFoundException("Nenhum usuário encontrado para este e-mail"));
    }

    private UserDTO addHateoasLinks(UserDTO user) {
        user.add(linkTo(methodOn(UserController.class).findAll()).withRel("users"));
        user.add(linkTo(methodOn(UserController.class).findById(user.getId())).withSelfRel());
        return user;
    }

    private List<UserDTO> addHateoasLinksToList(List<UserDTO> users) {
        return users.stream().map(
                this::addHateoasLinks
        ).toList();
    }
}
