package br.com.grafmarques.helpdesk.repositories;

import br.com.grafmarques.helpdesk.model.Notification;
import br.com.grafmarques.helpdesk.projections.NotificationProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, UUID> {
    Page<NotificationProjection> findByRecipientIdOrderByCreatedAtDesc(UUID id, Pageable pageable);

    @Modifying
    @Query("DELETE FROM Notification n WHERE n.recipient.id = :userId")
    void deleteAllByUserId(UUID userId);

    @Query("SELECT COUNT(n.id) FROM Notification n WHERE n.recipient.id = :userId AND n.viewed = false")
    long countNotViewedByUserId(UUID userId);

}
