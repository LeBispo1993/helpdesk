package br.com.grafmarques.helpdesk.data.DTO.v1.update;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.SectorDTO;
import br.com.grafmarques.helpdesk.model.enums.Role;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.UUID;

public class UserUpdateDTO {

    @NotNull
    private UUID id;

    @Size(min = 4, max = 50)
    private String name;

    @Email
    private String email;

    @Size(min = 8, max = 50)
    private String password;

    private Role role;

    private SectorDTO sector;

    public UserUpdateDTO() {}

    public UserUpdateDTO(UUID id, String name, String email, String password, Role role, SectorDTO sector) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
        this.sector = sector;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public SectorDTO getSector() {
        return sector;
    }

    public void setSector(SectorDTO sector) {
        this.sector = sector;
    }
}
