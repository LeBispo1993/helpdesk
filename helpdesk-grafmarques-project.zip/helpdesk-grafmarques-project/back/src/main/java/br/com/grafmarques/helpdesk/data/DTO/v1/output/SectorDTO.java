package br.com.grafmarques.helpdesk.data.DTO.v1.output;

import org.springframework.hateoas.RepresentationModel;

import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;

public class SectorDTO extends RepresentationModel<SectorDTO> {
    private UUID id;
    private String name;
    private Boolean server;
    private LocalDateTime createdAt;
    private Boolean active;

    public SectorDTO() {}

    public SectorDTO(UUID id, String name, Boolean server, LocalDateTime createdAt, Boolean active) {
        this.id = id;
        this.name = name;
        this.server = server;
        this.createdAt = createdAt;
        this.active = active;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getServer() {
        return server;
    }

    public void setServer(Boolean server) {
        this.server = server;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        SectorDTO sectorDTO = (SectorDTO) o;
        return Objects.equals(id, sectorDTO.id)
                && Objects.equals(name, sectorDTO.name)
                && Objects.equals(server, sectorDTO.server)
                && Objects.equals(createdAt, sectorDTO.createdAt)
                && Objects.equals(active, sectorDTO.active);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), id, name, server, createdAt, active);
    }
}
