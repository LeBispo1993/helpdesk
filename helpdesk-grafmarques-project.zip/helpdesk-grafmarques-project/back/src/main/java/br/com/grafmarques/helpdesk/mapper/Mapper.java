package br.com.grafmarques.helpdesk.mapper;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.TicketDTO;
import br.com.grafmarques.helpdesk.projections.TicketDetailsProjection;

import java.util.List;

public interface Mapper {
    <O, D> D map(O origin, Class<D> destiny);

    <O, D> List<D> map(List<O> origin, Class<D> destiny);

    TicketDTO map(TicketDetailsProjection origin);
}
