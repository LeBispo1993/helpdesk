package br.com.grafmarques.helpdesk.services;

import br.com.grafmarques.helpdesk.controllers.NotificationController;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.NotificationDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.TicketDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.NotificationIdsDTO;
import br.com.grafmarques.helpdesk.exceptions.general.NotFoundException;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.Notification;
import br.com.grafmarques.helpdesk.projections.NotificationProjection;
import br.com.grafmarques.helpdesk.repositories.NotificationRepository;
import br.com.grafmarques.helpdesk.services.auth.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Service
public class NotificationService {
    private final Logger LOGGER = Logger.getLogger(NotificationService.class.getName());

    private final NotificationRepository repository;
    private final TokenService tokenService;
    private final PagedResourcesAssembler<NotificationDTO> assembler;
    private final Mapper mapper;

    @Autowired
    public NotificationService(
            NotificationRepository repository,
            TokenService tokenService,
            PagedResourcesAssembler<NotificationDTO> assembler,
            Mapper mapper
    ) {
        this.repository = repository;
        this.tokenService = tokenService;
        this.assembler = assembler;
        this.mapper = mapper;
    }

    private UUID findUserId() {
        return tokenService.getUserId();
    }

    private Notification findEntityById(UUID id) {
        LOGGER.info("Finding entity by id");
        return repository.findById(id).orElseThrow(() -> new NotFoundException("Nenhuma notificação encontrada para este id"));
    }

    public long countNotViewed() {
        return repository.countNotViewedByUserId(findUserId());
    }

    public PagedModel<EntityModel<NotificationDTO>> findAll(Pageable pageable) {
        LOGGER.info("Finding notifications by user id");
        UUID userId = findUserId();
        Page<NotificationProjection> entities = repository.findByRecipientIdOrderByCreatedAtDesc(userId, pageable);
        Page<NotificationDTO> notifications = entities.map(entity -> mapper.map(entity, NotificationDTO.class));

        notifications.map(this::addHateoasLinks);

        return assembler.toModel(
                notifications,
                linkTo(
                        methodOn(NotificationController.class)
                        .findAll(
                                pageable.getPageNumber(),
                                pageable.getPageSize(),
                                pageable.getSort().toString()
                        )
                ).withSelfRel()
        );
    }

    public void create(String content, UserDTO recipient, TicketDTO ticket) {
        LOGGER.info("Creating a notification");
        NotificationDTO notification = new NotificationDTO(null, content, recipient, ticket);
        Notification entity = mapper.map(notification, Notification.class);
        mapper.map(repository.save(entity), NotificationDTO.class);
    }

    public void view(NotificationIdsDTO notificationIds) {
        LOGGER.info("Marking notifications as see");
        List<Notification> entities = repository.findAllById(notificationIds.getIds());
        for (Notification entity : entities) {
            if (!entity.getViewed()) entity.setViewed(true);
        }
        repository.saveAll(entities);
    }

    public void delete(UUID id) {
        LOGGER.info("Deleting a notification by id");
        Notification notification = findEntityById(id);
        repository.delete(notification);
    }

    @Transactional
    public void deleteAll() {
        LOGGER.info("Deleting all user notifications");
        repository.deleteAllByUserId(findUserId());
    }

    private NotificationDTO addHateoasLinks(NotificationDTO notification) {
        notification.add(linkTo(methodOn(NotificationController.class).findAll(0, 7, "desc")).withRel("user notifications"));
        return notification;
    }
}
