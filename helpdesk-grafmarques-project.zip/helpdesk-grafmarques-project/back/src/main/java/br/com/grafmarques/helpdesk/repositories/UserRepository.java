package br.com.grafmarques.helpdesk.repositories;

import br.com.grafmarques.helpdesk.model.User;
import br.com.grafmarques.helpdesk.model.enums.Role;
import br.com.grafmarques.helpdesk.projections.UserProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface UserRepository extends JpaRepository<User, UUID> {

    UserDetails findByEmail(String email);

    @Query("SELECT u FROM User u WHERE UPPER(u.email) = UPPER(:email)")
    Optional<User> findUserByEmail(String email);

    @Query("SELECT u.id FROM User u WHERE UPPER(u.email) = UPPER(:email)")
    Optional<UUID> findIdByEmail(String email);

    @Query("SELECT u.id FROM User u WHERE UPPER(u.email) = UPPER(:email) AND u.id != :id")
    Optional<UUID> findIdByEmail(String email, UUID id);

    @Query(value = "SELECT u.active FROM User u WHERE u.email = :email")
    Optional<Boolean> findActiveByEmail(String email);

    List<UserProjection> findAllBy();

    List<UserProjection> findBySectorId(UUID id);

    long countUserIdByRoleAndActive(Role role, Boolean active);
}
