package br.com.grafmarques.helpdesk.data.DTO.v1.util;

public class ResponseDTO {
    String message;

    public ResponseDTO(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
