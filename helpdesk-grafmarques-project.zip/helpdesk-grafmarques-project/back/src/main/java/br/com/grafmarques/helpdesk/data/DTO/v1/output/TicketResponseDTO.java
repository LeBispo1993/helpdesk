package br.com.grafmarques.helpdesk.data.DTO.v1.output;

import br.com.grafmarques.helpdesk.model.enums.Priority;
import br.com.grafmarques.helpdesk.model.enums.Status;
import org.springframework.hateoas.RepresentationModel;

import java.time.LocalDateTime;
import java.util.UUID;

public class TicketResponseDTO extends RepresentationModel<TicketResponseDTO>{
    private UUID id;
    private Long os;
    private String title;
    private String applicant;
    private Priority priority;
    private LocalDateTime createdAt;
    private Boolean active;

    public TicketResponseDTO() {}

    public TicketResponseDTO(UUID id, Long os, String title, String applicant, Priority priority, LocalDateTime createdAt, Boolean active) {
        this.id = id;
        this.os = os;
        this.title = title;
        this.applicant = applicant;
        this.priority = priority;
        this.createdAt = createdAt;
        this.active = active;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Long getOs() {
        return os;
    }

    public void setOs(Long os) {
        this.os = os;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getApplicant() {
        return applicant;
    }

    public void setApplicant(String applicant) {
        this.applicant = applicant;
    }

    public Priority getPriority() {
        return priority;
    }

    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }
}