package br.com.grafmarques.helpdesk.projections;

import br.com.grafmarques.helpdesk.model.enums.Priority;
import br.com.grafmarques.helpdesk.model.enums.Status;

import java.time.LocalDateTime;
import java.util.UUID;

public interface TicketProjection {
    UUID getId();
    Long getOs();
    String getTitle();
    Status getStatus();
    Priority getPriority();
    CategoryProjection getCategory();
    LocalDateTime getCreatedAt();
    LocalDateTime getUpdatedAt();
    SectorProjection getSector();
    UserAgentProjection getAgent();
    String getApplicant();
    UserAuthorProjection getAuthor();
    Boolean getActive();
}
