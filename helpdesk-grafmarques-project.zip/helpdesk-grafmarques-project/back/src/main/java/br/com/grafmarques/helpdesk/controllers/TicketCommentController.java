package br.com.grafmarques.helpdesk.controllers;

import br.com.grafmarques.helpdesk.data.DTO.v1.create.TicketCommentCreateDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.TicketCommentResponseDTO;
import br.com.grafmarques.helpdesk.services.TicketCommentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = {"http://localhost:8080", "http://localhost:3000", "https://sistema-de-chamados-vo59.vercel.app"})
@RestController
@RequestMapping("/api/v1/tickets/comments")
@Tag(name = "Comments", description = "Endpoints to manage ticket comments")
public class TicketCommentController {

    private final TicketCommentService service;

    @Autowired
    public TicketCommentController(TicketCommentService service) {
        this.service = service;
    }

    @PostMapping(
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    @Operation(
            summary = "Create a ticket comment",
            description = "Create a ticket comment",
            tags = {"Comments"},
            method = "POST",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(
                                    requiredProperties = {"content", "ticket.id"}
                            ),
                            examples = @ExampleObject(
                                    value = """
                                               { "content*": "string", "ticket*": { "id": "uuid" } }
                                            """
                            )
                    )
            )
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "201",
                            description = "Success",
                            content = @Content(
                                    schema = @Schema(
                                            implementation = TicketCommentResponseDTO.class
                                    )
                            )
                    ),
                    @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content),
                    @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content),
                    @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content),
                    @ApiResponse(responseCode = "404", description = "Not Found", content = @Content),
                    @ApiResponse(responseCode = "500", description = "Internal Error", content = @Content),
            }
    )
    public ResponseEntity<TicketCommentResponseDTO> createComment(@Valid @RequestBody TicketCommentCreateDTO ticketCommentCreate) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(ticketCommentCreate));
    }
}
