package br.com.grafmarques.helpdesk.services;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.UserOperationLogDTO;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.UserOperationLog;
import br.com.grafmarques.helpdesk.repositories.UserOperationLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.logging.Logger;

@Service
public class UserOperationLogService {
    private final Logger LOGGER = Logger.getLogger(UserOperationLogService.class.getName());

    private final UserOperationLogRepository repository;
    private final Mapper mapper;

    @Autowired
    public UserOperationLogService(
            UserOperationLogRepository repository,
            Mapper mapper
    ) {
        this.repository = repository;
        this.mapper = mapper;
    }

    public void registerOperationLog(String operation, String details, UserDTO user) {
        LOGGER.info("Registering a new user operation log (user id: " + user.getId() + ")");
        UserOperationLogDTO log = new UserOperationLogDTO(null, operation, details, LocalDateTime.now(), user);
        repository.save(mapper.map(log, UserOperationLog.class));
    }
}
