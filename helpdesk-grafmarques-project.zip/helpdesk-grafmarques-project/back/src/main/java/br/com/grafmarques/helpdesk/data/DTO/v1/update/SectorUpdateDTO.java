package br.com.grafmarques.helpdesk.data.DTO.v1.update;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.UUID;

public class SectorUpdateDTO {

    @NotNull
    private UUID id;

    @Size(min = 2, max = 100)
    private String name;

    private Boolean server;

    public SectorUpdateDTO() {}

    public SectorUpdateDTO(UUID id, String name, Boolean server) {
        this.id = id;
        this.name = name;
        this.server = server;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getServer() {
        return server;
    }

    public void setServer(Boolean server) {
        this.server = server;
    }
}
