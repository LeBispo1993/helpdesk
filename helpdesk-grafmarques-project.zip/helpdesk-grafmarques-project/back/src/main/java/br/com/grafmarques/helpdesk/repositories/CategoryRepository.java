package br.com.grafmarques.helpdesk.repositories;

import br.com.grafmarques.helpdesk.model.Category;
import br.com.grafmarques.helpdesk.projections.CategoryProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface CategoryRepository extends JpaRepository<Category, UUID> {
    @Query("SELECT c.id FROM Category c WHERE UPPER(c.name) = UPPER(:name)")
    Optional<UUID> findIdByName(String name);

    @Query("SELECT c.id FROM Category c WHERE UPPER(c.name) = UPPER(:name) AND c.id != :id")
    Optional<UUID> findIdByName(String name, UUID id);

    List<CategoryProjection> findByActiveTrue();
}
