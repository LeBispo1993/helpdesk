package br.com.grafmarques.helpdesk;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@OpenAPIDefinition(
		info =
		@Info(
				title = "Helpdesk Grafmarques",
				version = "v1",
				description = "Helpdesk Grafmarques API RESTFull ",
//				termsOfService = "https://com.example.com/terms",
				license = @License(
						name = "Apache 2.0",
						url = "https://www.apache.org/licenses/LICENSE-2.0"
				)
		)
)
public class HelpdeskGrafmarquesApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelpdeskGrafmarquesApplication.class, args);
	}

}
