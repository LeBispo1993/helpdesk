package br.com.grafmarques.helpdesk.data.DTO.v1.util;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.UUID;

public class RecoverPasswordDTO {

    @NotNull
    private UUID id;

    @NotBlank
    @Size(min = 8, max = 50)
    private String password;

    public RecoverPasswordDTO() {}

    public RecoverPasswordDTO(UUID id, String password) {
        this.id = id;
        this.password = password.trim();
    }

    public @NotNull UUID getId() {
        return id;
    }

    public @NotBlank @Size(min = 8, max = 50) String getPassword() {
        return password;
    }
}
