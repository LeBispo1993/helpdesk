package br.com.grafmarques.helpdesk.config.security;

import br.com.grafmarques.helpdesk.services.auth.SecurityFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfigurations {

    @Autowired
    private SecurityFilter securityFilter;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http
                .csrf(AbstractHttpConfigurer::disable)
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(
                        authorize -> authorize
                                // hello world
                                .requestMatchers(HttpMethod.GET, "/api/v1/hello-world").permitAll()

                                // auth
                                .requestMatchers(HttpMethod.POST, "/auth/login").permitAll()
                                .requestMatchers(HttpMethod.POST, "/auth/register").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.POST, "/auth/check-token").authenticated()
                                .requestMatchers(HttpMethod.POST, "/auth/register-first-admin").permitAll()
                                .requestMatchers(HttpMethod.POST, "/auth/send-password-recovery-email").permitAll()
                                .requestMatchers(HttpMethod.POST, "/auth/recover-password").permitAll()

                                // users
                                .requestMatchers(HttpMethod.GET, "/api/v1/users").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.PUT, "/api/v1/users/change-password/{id}").authenticated()
                                .requestMatchers(HttpMethod.GET, "/api/v1/users/hasActiveAdmin").permitAll()
                                .requestMatchers(HttpMethod.GET, "/api/v1/users/{id}").authenticated()
                                .requestMatchers(HttpMethod.PUT, "/api/v1/users").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.PUT, "/api/v1/users/deactivate/{id}").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.PUT, "/api/v1/users/activate/{id}").hasRole("ADMIN")

                                // sectors
                                .requestMatchers(HttpMethod.GET, "/api/v1/sectors").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.GET, "/api/v1/sectors/list").authenticated()
                                .requestMatchers(HttpMethod.GET, "/api/v1/sectors/{id}").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.POST, "/api/v1/sectors").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.PUT, "/api/v1/sectors").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.PUT, "/api/v1/sectors/deactivate/{id}").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.PUT, "/api/v1/sectors/activate/{id}").hasRole("ADMIN")

                                // categories
                                .requestMatchers(HttpMethod.GET, "/api/v1/categories").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.GET, "/api/v1/categories/list").authenticated()
                                .requestMatchers(HttpMethod.GET, "/api/v1/categories/{id}").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.POST, "/api/v1/categories").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.PUT, "/api/v1/categories").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.PUT, "/api/v1/categories/deactivate/{id}").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.PUT, "/api/v1/categories/activate/{id}").hasRole("ADMIN")

                                // tickets
                                .requestMatchers(HttpMethod.GET, "/api/v1/tickets").hasRole("ADMIN")
                                .requestMatchers(HttpMethod.GET, "/api/v1/tickets/home").authenticated()
                                .requestMatchers(HttpMethod.GET, "/api/v1/tickets/{id}").authenticated()
                                .requestMatchers(HttpMethod.GET, "/api/v1/tickets/author").authenticated()
                                .requestMatchers(HttpMethod.POST, "/api/v1/tickets").authenticated()
                                .requestMatchers(HttpMethod.PUT, "/api/v1/tickets/assign/{id}").hasAnyRole("ADMIN", "AGENT")
                                .requestMatchers(HttpMethod.PUT, "/api/v1/tickets/close/{id}").hasAnyRole("ADMIN", "AGENT")
                                .requestMatchers(HttpMethod.PUT, "/api/v1/tickets/deactivate/{id}").authenticated()

                                // notifications
                                .requestMatchers(HttpMethod.GET, "/api/v1/notifications/count-not-viewed").authenticated()
                                .requestMatchers(HttpMethod.GET, "/api/v1/notifications/**").authenticated()
                                .requestMatchers(HttpMethod.PUT, "/api/v1/notifications/view").authenticated()
                                .requestMatchers(HttpMethod.DELETE, "/api/v1/notifications/{id}").authenticated()
                                .requestMatchers(HttpMethod.DELETE, "/api/v1/notifications/delete-all").authenticated()

                                // swagger
                                .requestMatchers("/v3/api-docs/**").permitAll()
                                .requestMatchers("/swagger-ui/**").permitAll()
                                .requestMatchers("/swagger-ui.html").permitAll()

                                .anyRequest().authenticated()
                )
                .addFilterBefore(securityFilter, UsernamePasswordAuthenticationFilter.class)
                .build();
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration authenticationConfiguration)
            throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}