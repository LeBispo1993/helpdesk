package br.com.grafmarques.helpdesk.data.DTO.v1.util;

import java.time.LocalDateTime;

public class Dates {
    private LocalDateTime startDate;
    private LocalDateTime endDate;

    public Dates(LocalDateTime startDate, LocalDateTime endDate) {
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }
}
