package br.com.grafmarques.helpdesk.services.util;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.SectorDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.TicketDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.exceptions.general.UnauthorizedException;
import br.com.grafmarques.helpdesk.model.enums.Role;
import br.com.grafmarques.helpdesk.model.enums.Status;
import br.com.grafmarques.helpdesk.services.CategoryService;
import br.com.grafmarques.helpdesk.services.SectorService;
import br.com.grafmarques.helpdesk.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.UUID;
import java.util.logging.Logger;

@Service
public class TicketValidatorService {
    private final Logger LOGGER = Logger.getLogger(TicketValidatorService.class.getName());

    private final UserService userService;
    private final CategoryService categoryService;
    private final SectorService sectorService;

    @Autowired
    public TicketValidatorService(
            UserService userService,
            CategoryService categoryService,
            SectorService sectorService
    ) {
        this.userService = userService;
        this.categoryService = categoryService;
        this.sectorService = sectorService;
    }

    public void validateTicketRelationships(UUID authorId, UUID sectorId, UUID categoryId) {
        LOGGER.info("Validating ticket relationships");
        userService.findById(authorId);
        SectorDTO sector = sectorService.findById(sectorId);
        if (!sector.getServer()) throw new UnauthorizedException("O setor selecionado não pode atender chamados");
        categoryService.findById(categoryId);
    }

    public void validatePermissionToComment(UUID userId, UUID ticketAuthorId) {
        LOGGER.info("Validating if user has permission to add a ticket comment");
        boolean userIsAuthor = userId.equals(ticketAuthorId);
        boolean hasUserRole = userService.findById(userId).getRole() == Role.USER;
        if (!userIsAuthor && hasUserRole) throw new UnauthorizedException("Você não tem permissão para adicionar um comentário neste chamado");
    }

    public void hasPermissionToUpdateActive(UserDTO user, TicketDTO ticket) {
        LOGGER.info("Validating permissions");
        boolean userIsAuthor = ticket.getAuthor().getId() == user.getId();
        boolean userIsAmin = user.getRole() == Role.ADMIN;
        if (!userIsAuthor && !userIsAmin) throw new UnauthorizedException("Você não tem permissão para realizar está ação");
    }

    public void validateStatus(Status ticketStatus , Status allowedStatus) {
        if (!ticketStatus.equals(allowedStatus)) throw new UnauthorizedException("Ação bloqueada devido ao status do chamado");
    }

    public void validateUpdateStatus(TicketDTO ticketDTO) {
        if (!ticketDTO.getActive()) throw new UnauthorizedException("Ação bloqueada, este chamado foi deletado");
        if (ticketDTO.getStatus() == Status.FECHADO) throw new UnauthorizedException("Ação bloqueada devido ao status do chamado");
    }

    public void hasPermissionForCloseTicket(TicketDTO ticket, UserDTO user) {
        if (ticket.getStatus() != Status.PROCESSANDO) throw new UnauthorizedException("O status do chamado deve ser '" + Status.PROCESSANDO + "'");
        UUID userSectorId = user.getSector().getId();
        UUID agentSectorId = ticket.getAgent().getSector().getId();
        boolean userIsAdmin = user.getRole() == Role.ADMIN;
        if (userSectorId != agentSectorId && !userIsAdmin)
            throw new UnauthorizedException("Ação bloqueada, esse chamado já está sendo processado por outra equipe");

    }

    public void hasPermissionForAssignTicket(SectorDTO currentTeam, SectorDTO team) {
        if (currentTeam.equals(team)) throw new UnauthorizedException("Esse chamado já está sendo processado por sua equipe");
    }
}
