package br.com.grafmarques.helpdesk.model.enums;

public enum Priority {
    BAIXA("baixa"),
    MÉDIA("média"),
    ALTA("alta"),
    AGENDAMENTO("agendamento");

    private String priority;

    Priority(String priority) {
        this.priority = priority;
    }

    public String getPriority() {
        return priority;
    }
}
