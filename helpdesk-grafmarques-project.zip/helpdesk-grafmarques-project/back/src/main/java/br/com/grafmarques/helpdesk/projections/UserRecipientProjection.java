package br.com.grafmarques.helpdesk.projections;

public interface UserRecipientProjection {
}
