package br.com.grafmarques.helpdesk.services;

import br.com.grafmarques.helpdesk.controllers.TicketController;
import br.com.grafmarques.helpdesk.data.DTO.v1.create.TicketCreateDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.TicketDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.TicketResponseDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.TicketFilterDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.Dates;
import br.com.grafmarques.helpdesk.exceptions.general.NotFoundException;
import br.com.grafmarques.helpdesk.exceptions.general.UnauthorizedException;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.Ticket;
import br.com.grafmarques.helpdesk.model.enums.Priority;
import br.com.grafmarques.helpdesk.model.enums.Status;
import br.com.grafmarques.helpdesk.projections.TicketProjection;
import br.com.grafmarques.helpdesk.repositories.TicketRepository;
import br.com.grafmarques.helpdesk.services.auth.TokenService;
import br.com.grafmarques.helpdesk.services.util.DateUtil;
import br.com.grafmarques.helpdesk.services.util.TicketValidatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.RepresentationModel;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.function.Function;
import java.util.logging.Logger;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Service
public class TicketService {
    private final Logger LOGGER = Logger.getLogger(TicketService.class.getName());

    private final TicketRepository repository;
    private final TicketValidatorService validator;
    private final UserService userService;
    private final TokenService tokenService;
    private final TicketOperationLogService ticketOperationLogService;
    private final NotificationService notificationService;
    private final Mapper mapper;

    @Autowired
    public TicketService(
            TicketRepository repository,
            TicketValidatorService validator,
            UserService userService,
            TokenService tokenService,
            TicketOperationLogService ticketOperationLogService,
            NotificationService notificationService,
            Mapper mapper
    ) {
        this.repository = repository;
        this.validator = validator;
        this.userService = userService;
        this.tokenService = tokenService;
        this.notificationService = notificationService;
        this.ticketOperationLogService = ticketOperationLogService;
        this.mapper = mapper;
    }

    public TicketDTO findById(UUID id) {
        LOGGER.info("Finding ticket details by id");
        TicketDTO ticket = mapper.map(
                repository
                        .findTicketDetailsById(id)
                        .orElseThrow(() -> new NotFoundException("Nenhum chamado encontrado para este id"))
        );
        return addHateoasLinks(ticket, TicketDTO::getId);
    }

    private Ticket findTicketById(UUID id) {
        LOGGER.info("Finding entity ticket by id");
        return repository.findById(id).orElseThrow(() -> new NotFoundException("Nenhum chamado encontrado para este id"));
    }

    public List<TicketDTO> findForAdminPage(TicketFilterDTO filter) {
        LOGGER.info("Finding tickets for home page");
        Dates dates = DateUtil.setDateFilter(filter.getStartDate(), filter.getEndDate());
        List<TicketDTO> tickets = mapper.map(
                repository.findByUpdatedAtBetweenOrderByUpdatedAtDesc(dates.getStartDate(), dates.getEndDate()),
                TicketDTO.class
        );
        tickets = applyFilters(tickets, filter);
        return addHateoasLinksToList(tickets, TicketDTO::getId);
    }

    public List<TicketDTO> findForHomePage(TicketFilterDTO filter) {
        LOGGER.info("Finding tickets for home page");
        Dates dates = DateUtil.setDateFilter(filter.getStartDate(), filter.getEndDate());
        List<TicketDTO> tickets = mapper.map(
                repository.findByUpdatedAtBetweenAndActiveTrueOrderByUpdatedAtDesc(dates.getStartDate(), dates.getEndDate()),
                TicketDTO.class
        );
        tickets = applyFilters(tickets, filter);
        return addHateoasLinksToList(tickets, TicketDTO::getId);
    }

    public List<TicketDTO> findByAuthor(TicketFilterDTO filter) {
        LOGGER.info("Finding tickets by author");
        Dates dates = DateUtil.setDateFilter(filter.getStartDate(), filter.getEndDate());
        UUID authorId = tokenService.getUserId();
        List<TicketProjection> ticketProjections =
                repository.findByAuthorIdAndActiveIsTrueAndUpdatedAtBetweenOrderByUpdatedAtDesc(
                        authorId,
                        dates.getStartDate(),
                        dates.getEndDate()
                );
        List<TicketDTO> tickets = mapper.map(ticketProjections, TicketDTO.class);
        tickets = applyFilters(tickets, filter);
        return addHateoasLinksToList(tickets, TicketDTO::getId);
    }

    @Transactional(rollbackFor = Exception.class)
    public TicketResponseDTO create(TicketCreateDTO ticketCreate) {
        LOGGER.info("Creating a ticket");
        ticketCreate.setAuthor(
                userService.findById(tokenService.getUserId())
        );
        validator.validateTicketRelationships(
                ticketCreate.getAuthor().getId(),
                ticketCreate.getSector().getId(),
                ticketCreate.getCategory().getId()
        );

        Ticket entity = mapper.map(ticketCreate, Ticket.class);
        entity.setTitle(entity.getTitle().trim());
        entity.setDescription(entity.getDescription().trim());
        entity.setApplicant(entity.getApplicant().trim());
        UUID ticketId = repository.save(entity).getId();
        repository.flush();

        TicketResponseDTO ticket = mapper.map(repository.findById(ticketId), TicketResponseDTO.class);

        ticketOperationLogService.registerOperationLog(
                "Ticket Creation",
                "Ticket Creation completed successfully",
                mapper.map(ticket, TicketDTO.class)
        );

        notificationService.create(
                "Chamado criado",
                ticketCreate.getAuthor(),
                mapper.map(ticket, TicketDTO.class)
        );

        return addHateoasLinks(ticket, TicketResponseDTO::getId);
    }

    @Transactional
    public TicketResponseDTO updateStatus(UUID id, Status desinedStatus) {
        LOGGER.info("Updating ticket status");
        TicketDTO ticketDTO = mapper.map(findTicketById(id), TicketDTO.class);
        UserDTO agent = userService.findById(tokenService.getUserId());
        validator.validateUpdateStatus(ticketDTO);

        if (desinedStatus == Status.PROCESSANDO) assignTicket(ticketDTO, agent);
        if (desinedStatus == Status.FECHADO) closeTicket(ticketDTO, agent);

        Ticket entity = mapper.map(ticketDTO, Ticket.class);
        TicketResponseDTO ticket = mapper.map(repository.save(entity), TicketResponseDTO.class);

        ticketOperationLogService.registerOperationLog(
                "Status Update",
                "Status update to '" + desinedStatus + "' successfully",
                mapper.map(ticket, TicketDTO.class)
        );

        notificationService.create(
                "O status de seu chamado foi alterado. Novo status: " + desinedStatus.getStatus(),
                ticketDTO.getAuthor(),
                mapper.map(ticket, TicketDTO.class)
        );

        return addHateoasLinks(ticket, TicketResponseDTO::getId);
    }

    @Transactional
    public TicketResponseDTO updateActivity(UUID id) {
        LOGGER.info("Updating ticket activity to false");
        Ticket entity = findTicketById(id);
        if (!entity.getActive()) throw new UnauthorizedException("Ação bloqueada, o chamado já foi deletado");
        UserDTO user = userService.findById(tokenService.getUserId());

        validator.validateStatus(entity.getStatus(), Status.ABERTO);
        validator.hasPermissionToUpdateActive(user, mapper.map(entity, TicketDTO.class));

        entity.setActive(false);
        repository.save(entity);

        TicketDTO ticket = mapper.map(entity, TicketDTO.class);
        ticketOperationLogService.registerOperationLog(
                "Activity Update",
                "Activity update to 'false' successfully",
                ticket
        );

        notificationService.create(
                "Seu chamado foi excluído",
                mapper.map(entity.getAuthor() ,UserDTO.class),
                ticket
        );

        TicketResponseDTO ticketResponse = mapper.map(entity, TicketResponseDTO.class);
        return addHateoasLinks(ticketResponse, TicketResponseDTO::getId);
    }

    private void assignTicket(TicketDTO ticket, UserDTO agent) {
        LOGGER.info("Assigning ticket");

        if (ticket.getStatus() == Status.PROCESSANDO) {
            validator.hasPermissionForAssignTicket(ticket.getAgent().getSector(), agent.getSector());
        }

        ticket.setAgent(agent);
        ticket.setStatus(Status.PROCESSANDO);
        ticket.setAssignedAt(LocalDateTime.now());
    }

    private void closeTicket(TicketDTO ticket, UserDTO user) {
        LOGGER.info("Closing ticket");
        validator.hasPermissionForCloseTicket(ticket, user);
        ticket.setStatus(Status.FECHADO);
        ticket.setClosedAt(LocalDateTime.now());
    }

    private <T extends TicketFilterDTO> List<TicketDTO> applyFilters(List<TicketDTO> tickets, T filter ) {
        if (hasItems(filter.getStatus()))
            tickets = filterByStatus(tickets, filter.getStatus());
        if (hasItems(filter.getPriorities()))
            tickets = filterByPriorities(tickets, filter.getPriorities());
        if (hasItems(filter.getCategories()))
            tickets = filterByCategories(tickets, filter.getCategories());

        return tickets;
    }

    private <T> boolean hasItems(List<T> list) {
        return list != null && !list.isEmpty();
    }

    private List<TicketDTO> filterByStatus(List<TicketDTO> tickets, List<Status> status) {
        return tickets.stream().filter(
                ticket -> status.contains(ticket.getStatus())
        ).toList();
    }

    private List<TicketDTO> filterByPriorities(List<TicketDTO> tickets, List<Priority> priorities) {
        return tickets.stream().filter(
                ticket -> priorities.contains(ticket.getPriority())
        ).toList();
    }

    private List<TicketDTO> filterByCategories(List<TicketDTO> tickets, List<UUID> categories) {
        return tickets.stream().filter(
                ticket -> categories.contains(ticket.getCategory().getId())
        ).toList();
    }

    private <T extends RepresentationModel<T>> T addHateoasLinks(T ticket, Function<T, UUID> idExtractor) {
        ticket.add(linkTo(methodOn(TicketController.class).findForHomePage(DateUtil.DEFAULT_DATE_FILTER)).withRel("tickets(users)"));
        ticket.add(linkTo(methodOn(TicketController.class).findById(idExtractor.apply(ticket))).withSelfRel());
        return ticket;
    }

    private <T extends RepresentationModel<T>> List<T> addHateoasLinksToList(List<T> tickets, Function<T, UUID> idExtractor) {
        return tickets.stream().map(
                ticket -> addHateoasLinks(ticket, idExtractor)
        ).toList();
    }
}
