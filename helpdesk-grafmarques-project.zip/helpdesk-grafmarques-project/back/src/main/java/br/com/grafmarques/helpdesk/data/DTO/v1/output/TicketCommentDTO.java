package br.com.grafmarques.helpdesk.data.DTO.v1.output;

import java.time.LocalDateTime;
import java.util.UUID;

public class TicketCommentDTO {
    private UUID id;
    private String content;
    private LocalDateTime createdAt;
    private TicketDTO ticket;
    private UserDTO user;

    public TicketCommentDTO() {}

    public TicketCommentDTO(UUID id, String content, LocalDateTime createdAt, TicketDTO ticket, UserDTO user) {
        this.id = id;
        this.content = content;
        this.createdAt = createdAt;
        this.ticket = ticket;
        this.user = user;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public TicketDTO getTicket() {
        return ticket;
    }

    public void setTicket(TicketDTO ticket) {
        this.ticket = ticket;
    }

    public UserDTO getUser() {
        return user;
    }

    public void setUser(UserDTO user) {
        this.user = user;
    }
}
