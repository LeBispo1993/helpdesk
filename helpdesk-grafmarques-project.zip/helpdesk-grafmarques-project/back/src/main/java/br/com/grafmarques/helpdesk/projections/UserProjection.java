package br.com.grafmarques.helpdesk.projections;

import br.com.grafmarques.helpdesk.model.enums.Role;

import java.time.LocalDateTime;
import java.util.UUID;

public interface UserProjection {
    UUID getId();
    String getName();
    String getEmail();
    Role getRole();
    SectorProjection getSector();
    LocalDateTime getCreatedAt();
    Boolean getActive();
}
