package br.com.grafmarques.helpdesk.model;

import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Entity
@Table(name = "sectors")
public class Sector implements Serializable {

    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(unique = true, length = 100, nullable = false)
    private String name;

    @Column(nullable = false)
    private Boolean server;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private Boolean active;

    @OneToMany(mappedBy = "sector")
    private List<User> users;

    @OneToMany(mappedBy = "sector")
    private List<Ticket> tickets;

    public Sector() {}

    public Sector(UUID id, String name, Boolean server, LocalDateTime createdAt, Boolean active, List<User> users, List<Ticket> tickets) {
        this.id = id;
        this.name = name;
        this.server = server;
        this.createdAt = createdAt;
        this.active = active;
        this.users = users;
        this.tickets = tickets;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getServer() {
        return server;
    }

    public void setServer(Boolean server) {
        this.server = server;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    public List<Ticket> getTickets() {
        return tickets;
    }

    public void setTickets(List<Ticket> tickets) {
        this.tickets = tickets;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Sector sector = (Sector) o;
        return Objects.equals(id, sector.id)
                && Objects.equals(name, sector.name)
                && Objects.equals(server, sector.server)
                && Objects.equals(createdAt, sector.createdAt)
                && Objects.equals(active, sector.active)
                && Objects.equals(users, sector.users)
                && Objects.equals(tickets, sector.tickets);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, server, createdAt, active, users, tickets);
    }
}
