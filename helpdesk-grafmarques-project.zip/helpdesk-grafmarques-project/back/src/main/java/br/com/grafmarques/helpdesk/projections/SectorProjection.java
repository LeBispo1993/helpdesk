package br.com.grafmarques.helpdesk.projections;

import java.util.UUID;

public interface SectorProjection {
    UUID getId();
    String getName();
}
