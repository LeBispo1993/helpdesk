package br.com.grafmarques.helpdesk.services;

import br.com.grafmarques.helpdesk.data.DTO.v1.create.TicketCommentCreateDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.*;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.TicketComment;
import br.com.grafmarques.helpdesk.repositories.TicketCommentRepository;
import br.com.grafmarques.helpdesk.services.auth.TokenService;
import br.com.grafmarques.helpdesk.services.util.TicketValidatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.logging.Logger;

@Service
public class TicketCommentService {
    private final Logger LOGGER = Logger.getLogger(TicketCommentService.class.getName());

    private final TicketCommentRepository repository;
    private final TicketValidatorService validatorService;
    private final TicketService ticketService;
    private final TicketOperationLogService ticketOperationLogService;
    private final NotificationService notificationService;
    private final UserService userService;
    private final TokenService tokenService;
    private final Mapper mapper;

    @Autowired
    public TicketCommentService(
            TicketCommentRepository repository,
            TicketValidatorService validatorService,
            TicketService ticketService,
            TicketOperationLogService ticketOperationLogService,
            NotificationService notificationService,
            UserService userService,
            TokenService tokenService,
            Mapper mapper
    ) {
        this.repository = repository;
        this.validatorService = validatorService;
        this.ticketService = ticketService;
        this.ticketOperationLogService = ticketOperationLogService;
        this.notificationService = notificationService;
        this.userService = userService;
        this.tokenService = tokenService;
        this.mapper = mapper;
    }

    public TicketCommentResponseDTO create(TicketCommentCreateDTO ticketCommentCreate) {
        LOGGER.info("Creating a ticket comment");
        TicketCommentDTO ticketCommentDTO = mapper.map(ticketCommentCreate, TicketCommentDTO.class);
        TicketDTO ticket = ticketService.findById(ticketCommentDTO.getTicket().getId());
        validatorService.validatePermissionToComment(
                tokenService.getUserId(),
                ticket.getAuthor().getId()
        );
        ticketCommentDTO.setUser(
                userService.findById(tokenService.getUserId())
        );
        ticketCommentDTO.setContent(ticketCommentDTO.getContent().trim());
        TicketComment entity = mapper.map(ticketCommentDTO, TicketComment.class);
        TicketCommentResponseDTO response = mapper.map(repository.save(entity), TicketCommentResponseDTO.class);
        ticketOperationLogService.registerOperationLog(
                "Comment Creation",
                "Ticket comment creation completed successfully",
                ticket
        );

        if (ticketCommentDTO.getUser().getId() != ticket.getAuthor().getId()) {
            notificationService.create(
                    "Um comentário foi adicionado ao seu chamado",
                    ticket.getAuthor(),
                    ticket
            );
        }

        if (ticket.getAgent() != null) sendNotificationsToAgents(ticket);

        return response;
    }

    private void sendNotificationsToAgents(TicketDTO ticket) {
        List<UserDTO> agents = userService.findBySectorId(ticket.getAgent().getSector().getId());

        for (UserDTO agent : agents) {
            notificationService.create(
                    "Um comentário foi adicionado a um chamado que sua equipe está atribuída",
                    agent,
                    ticket
            );
        }
    }
}
