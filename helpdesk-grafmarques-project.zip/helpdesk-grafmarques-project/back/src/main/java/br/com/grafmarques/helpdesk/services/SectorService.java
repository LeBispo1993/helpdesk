package br.com.grafmarques.helpdesk.services;

import br.com.grafmarques.helpdesk.controllers.SectorController;
import br.com.grafmarques.helpdesk.data.DTO.v1.create.SectorCreateDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.SectorDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.update.SectorUpdateDTO;
import br.com.grafmarques.helpdesk.exceptions.general.NotFoundException;
import br.com.grafmarques.helpdesk.exceptions.general.RepeatedDataException;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.Sector;
import br.com.grafmarques.helpdesk.repositories.SectorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Service
public class SectorService {
    private final Logger LOGGER = Logger.getLogger(SectorService.class.getName());

    private final SectorRepository repository;
    private final Mapper mapper;

    @Autowired
    public SectorService(
            SectorRepository repository,
            Mapper mapper
    ) {
        this.repository = repository;
        this.mapper = mapper;
    }

    public SectorDTO findById(UUID id) {
        LOGGER.info("Finding sector by id");
        SectorDTO sector = mapper.map(
                repository.findById(id)
                        .orElseThrow(() -> new NotFoundException("Nenhum setor encontrado para este id")),
                SectorDTO.class
        );
        return addHateoasLinks(sector);
    }

    public SectorDTO findByName(String name) {
        LOGGER.info("Finding sector by name");
        return mapper.map(
                repository.findByName(name)
                        .orElseThrow(() -> new NotFoundException("Nenhum setor encontrado para este nome")),
                SectorDTO.class
        );
    }

    public List<SectorDTO> findAll() {
        LOGGER.info("Finding all sectors");
        List<SectorDTO> sectors = mapper.map(repository.findAll(), SectorDTO.class);
        return addHateoasLinksToList(sectors);
    }

    public List<SectorDTO> findList(boolean value) {
        LOGGER.info("Finding list of sectors");
        List<SectorDTO> sectors =
                value ?
                        mapper.map(repository.findByActiveIsTrueAndServerIsTrue(), SectorDTO.class)
                        :
                        mapper.map(repository.findByActiveIsTrue(), SectorDTO.class);
        return addHateoasLinksToList(sectors);
    }

    public SectorDTO create(SectorCreateDTO data) {
        LOGGER.info("Creating a sector");
        if ( nameAlreadyInUse(data.getName().trim()) ) throw new RepeatedDataException("Esse setor já existe");

        Sector entity = mapper.map(data, Sector.class);
        entity.setName(entity.getName().trim());
        SectorDTO sector = mapper.map(repository.save(entity), SectorDTO.class);
        return addHateoasLinks(sector);
    }

    public SectorDTO update(SectorUpdateDTO data) {
        LOGGER.info("Updating a sector");
        SectorDTO sectorDTO = findById(data.getId());

        if ( nameAlreadyInUse(data.getName().trim(), data.getId()) ) throw new RepeatedDataException("Esse setor já existe");
        if (data.getName() != null) sectorDTO.setName(data.getName().trim());
        if (data.getServer() != null) sectorDTO.setServer(data.getServer());

        Sector entity = mapper.map(sectorDTO, Sector.class);
        SectorDTO sector = mapper.map(repository.save(entity), SectorDTO.class);
        return addHateoasLinks(sector);
    }

    public SectorDTO changeActive(UUID id, boolean value) {
        LOGGER.info("Changing sector activity to " + value);
        Sector entity = mapper.map(findById(id), Sector.class);
        entity.setActive(value);
        SectorDTO sector = mapper.map(repository.save(entity), SectorDTO.class);
        return addHateoasLinks(sector);
    }

    private boolean nameAlreadyInUse(String name) {
        return repository.findIdByName(name).isPresent();
    }

    private boolean nameAlreadyInUse(String name, UUID id) {
        return repository.findIdByName(name, id).isPresent();
    }

    private SectorDTO addHateoasLinks(SectorDTO sector) {
        sector.add(linkTo(methodOn(SectorController.class).findAll()).withRel("sectors"));
        sector.add(linkTo(methodOn(SectorController.class).findById(sector.getId())).withSelfRel());
        return sector;
    }

    private List<SectorDTO> addHateoasLinksToList(List<SectorDTO> sectors) {
        return sectors.stream().map(
                this::addHateoasLinks
        ).toList();
    }
}
