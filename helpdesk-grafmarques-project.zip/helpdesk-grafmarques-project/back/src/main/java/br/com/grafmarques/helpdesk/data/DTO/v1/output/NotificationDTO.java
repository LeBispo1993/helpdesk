package br.com.grafmarques.helpdesk.data.DTO.v1.output;

import org.springframework.hateoas.RepresentationModel;

import java.time.LocalDateTime;
import java.util.UUID;

public class NotificationDTO extends RepresentationModel<NotificationDTO> {
    private UUID id;
    private String content;
    private UserDTO recipient;
    private TicketDTO ticket;

    private Boolean viewed = false;
    private LocalDateTime createdAt = LocalDateTime.now();

    public NotificationDTO() {}

    public NotificationDTO(
            UUID id,
            String content,
            UserDTO recipient,
            TicketDTO ticket
    ) {
        this.id = id;
        this.content = content;
        this.recipient = recipient;
        this.ticket = ticket;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public UserDTO getRecipient() {
        return recipient;
    }

    public void setRecipient(UserDTO recipient) {
        this.recipient = recipient;
    }

    public TicketDTO getTicket() {
        return ticket;
    }

    public void setTicket(TicketDTO ticket) {
        this.ticket = ticket;
    }

    public Boolean getViewed() {
        return viewed;
    }

    public void setViewed(Boolean viewed) {
        this.viewed = viewed;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
