package br.com.grafmarques.helpdesk.projections;

import br.com.grafmarques.helpdesk.model.enums.Priority;
import br.com.grafmarques.helpdesk.model.enums.Status;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

public interface TicketDetailsProjection extends TicketProjection {
    UUID getId();
    Long getOs();
    String getTitle();
    Status getStatus();
    Priority getPriority();
    CategoryProjection getCategory();
    LocalDateTime getCreatedAt();
    LocalDateTime getUpdatedAt();
    UserAgentProjection getAgent();
    String getApplicant();
    Boolean getActive();
    UserAuthorProjection getAuthor();
    SectorProjection getSector();
    String getDescription();
    LocalDateTime getAssignedAt();
    LocalDateTime getClosedAt();
    List<TicketCommentProjection> getComments();
}
