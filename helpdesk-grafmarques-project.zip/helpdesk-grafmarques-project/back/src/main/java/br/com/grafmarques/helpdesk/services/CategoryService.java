package br.com.grafmarques.helpdesk.services;

import br.com.grafmarques.helpdesk.controllers.CategoryController;
import br.com.grafmarques.helpdesk.data.DTO.v1.create.CategoryCreateDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.CategoryDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.update.CategoryUpdateDTO;
import br.com.grafmarques.helpdesk.exceptions.general.NotFoundException;
import br.com.grafmarques.helpdesk.exceptions.general.RepeatedDataException;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.Category;
import br.com.grafmarques.helpdesk.repositories.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Service
public class CategoryService {
    private final Logger LOGGER = Logger.getLogger(CategoryService.class.getName());

    private final CategoryRepository repository;
    private final Mapper mapper;

    @Autowired
    public CategoryService(
            CategoryRepository repository,
            Mapper mapper
    ) {
        this.repository = repository;
        this.mapper = mapper;
    }

    public CategoryDTO findById(UUID id) {
        LOGGER.info("Finding category by id");
        CategoryDTO category = mapper.map(
                repository.findById(id)
                        .orElseThrow(() -> new NotFoundException("Nenhuma categoria encontrada para este id")),
                CategoryDTO.class
        );
        return addHateoasLinks(category);
}

    public List<CategoryDTO> findAll() {
        LOGGER.info("Finding all categories");
        List<CategoryDTO> categories = mapper.map(repository.findAll(), CategoryDTO.class);
        return addHateoasLinksToList(categories);
    }

    public List<CategoryDTO> findList() {
        LOGGER.info("Finding list of categories");
        List<CategoryDTO> categories = mapper.map(repository.findByActiveTrue(), CategoryDTO.class);
        return addHateoasLinksToList(categories);
    }

    public CategoryDTO create(CategoryCreateDTO data) {
        LOGGER.info("Creating a category");
        if ( nameAlreadyInUse(data.getName().trim()) ) throw new RepeatedDataException("Essa categoria já existe");

        Category entity = mapper.map(data, Category.class);
        entity.setName(entity.getName().trim());
        CategoryDTO category = mapper.map(repository.save(entity), CategoryDTO.class);
        return addHateoasLinks(category);
    }

    public CategoryDTO update(CategoryUpdateDTO data) {
        LOGGER.info("Updating category");
        CategoryDTO categoryDTO = findById(data.getId());

        if ( nameAlreadyInUse(data.getName().trim(), data.getId()) ) throw new RepeatedDataException("Essa categoria já existe");
        if (data.getName() != null) categoryDTO.setName(data.getName().trim());

        Category entity = mapper.map(categoryDTO, Category.class);
        CategoryDTO category = mapper.map(repository.save(entity), CategoryDTO.class);
        return addHateoasLinks(category);
    }

    public CategoryDTO changeActive(UUID id, boolean value) {
        LOGGER.info("Changing category activity to " + value);

        Category entity = mapper.map(findById(id), Category.class);
        entity.setActive(value);
        CategoryDTO category = mapper.map(repository.save(entity), CategoryDTO.class);

        return addHateoasLinks(category);
    }

    // used for register
    private boolean nameAlreadyInUse(String name) {
        return repository.findIdByName(name).isPresent();
    }

    // used for update
    private boolean nameAlreadyInUse(String name, UUID id) {
        return repository.findIdByName(name, id).isPresent();
    }

    private CategoryDTO addHateoasLinks(CategoryDTO category) {
        category.add(linkTo(methodOn(CategoryController.class).findAll()).withRel("categories"));
        category.add(linkTo(methodOn(CategoryController.class).findById(category.getId())).withSelfRel());
        return category;
    }

    private List<CategoryDTO> addHateoasLinksToList(List<CategoryDTO> categories) {
        return categories.stream().map(
                this::addHateoasLinks
        ).toList();
    }
}
