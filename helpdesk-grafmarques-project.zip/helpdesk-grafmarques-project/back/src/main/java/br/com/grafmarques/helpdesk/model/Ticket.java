package br.com.grafmarques.helpdesk.model;

import br.com.grafmarques.helpdesk.model.enums.Priority;
import br.com.grafmarques.helpdesk.model.enums.Status;
import jakarta.persistence.*;
import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Entity
@Table(name = "tickets")
public class Ticket implements Serializable {
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Generated
    @Column(unique = true, nullable = false, updatable = false)
    private Long os;

    @Column(unique = true, length = 50, nullable = false, updatable = false)
    private String title;

    @Enumerated(EnumType.STRING)
    private Status status;

    @Column(length = 500, nullable = false, updatable = false)
    private String description;

    @Column(length = 50, nullable = false, updatable = false)
    private String applicant;

    @Enumerated(EnumType.STRING)
    private Priority priority;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @Column(name = "assigned_at")
    private LocalDateTime assignedAt;

    @Column(name = "closed_at")
    private LocalDateTime closedAt;

    @Column(nullable = false)
    private Boolean active;

    @ManyToOne @JoinColumn(name = "author_id", referencedColumnName = "id", nullable = false, updatable = false)
    private User author;

    @ManyToOne @JoinColumn(name = "sector_id", referencedColumnName = "id", nullable = false, updatable = false)
    private Sector sector;

    @ManyToOne @JoinColumn(name = "agent_id", referencedColumnName = "id")
    private User agent;

    @ManyToOne @JoinColumn(name = "category_id", referencedColumnName = "id", nullable = false, updatable = false)
    private Category category;

    @OneToMany(mappedBy = "ticket")
    private List<TicketComment> comments;

    @OneToMany(mappedBy = "ticket")
    private List<Notification> notifications;

    @OneToMany(mappedBy = "ticket")
    private List<TicketOperationLog> logs;

    public Ticket() {}

    public Ticket(UUID id, Long os, String title, String description, String applicant, LocalDateTime createdAt, LocalDateTime updatedAt, LocalDateTime assignedAt, LocalDateTime closedAt, Boolean active, Status status, User author, Priority priority, Sector sector, User agent, Category category, List<TicketComment> comments, List<Notification> notifications, List<TicketOperationLog> logs) {
        this.id = id;
        this.os = os;
        this.title = title;
        this.description = description;
        this.applicant = applicant;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.assignedAt = assignedAt;
        this.closedAt = closedAt;
        this.active = active;
        this.status = status;
        this.author = author;
        this.priority = priority;
        this.sector = sector;
        this.agent = agent;
        this.category = category;
        this.comments = comments;
        this.notifications = notifications;
        this.logs = logs;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Long getOs() {
        return os;
    }

    public void setOs(Long os) {
        this.os = os;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getApplicant() {
        return applicant;
    }

    public void setApplicant(String applicant) {
        this.applicant = applicant;
    }

    public Priority getPriority() {
        return priority;
    }

    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public LocalDateTime getAssignedAt() {
        return assignedAt;
    }

    public void setAssignedAt(LocalDateTime assignedAt) {
        this.assignedAt = assignedAt;
    }

    public LocalDateTime getClosedAt() {
        return closedAt;
    }

    public void setClosedAt(LocalDateTime closedAt) {
        this.closedAt = closedAt;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public User getAuthor() {
        return author;
    }

    public void setAuthor(User author) {
        this.author = author;
    }

    public Sector getSector() {
        return sector;
    }

    public void setSector(Sector sector) {
        this.sector = sector;
    }

    public User getAgent() {
        return agent;
    }

    public void setAgent(User agent) {
        this.agent = agent;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public List<TicketComment> getComments() {
        return comments;
    }

    public void setComments(List<TicketComment> comments) {
        this.comments = comments;
    }

    public List<Notification> getNotifications() {
        return notifications;
    }

    public void setNotifications(List<Notification> notifications) {
        this.notifications = notifications;
    }

    public List<TicketOperationLog> getLogs() {
        return logs;
    }

    public void setLogs(List<TicketOperationLog> logs) {
        this.logs = logs;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Ticket ticket = (Ticket) o;
        return Objects.equals(id, ticket.id)
                && Objects.equals(os, ticket.os)
                && Objects.equals(title, ticket.title)
                && Objects.equals(description, ticket.description)
                && Objects.equals(applicant, ticket.applicant)
                && Objects.equals(createdAt, ticket.createdAt)
                && Objects.equals(updatedAt, ticket.updatedAt)
                && Objects.equals(assignedAt, ticket.assignedAt)
                && Objects.equals(closedAt, ticket.closedAt)
                && Objects.equals(active, ticket.active)
                && Objects.equals(status, ticket.status)
                && Objects.equals(author, ticket.author)
                && Objects.equals(priority, ticket.priority)
                && Objects.equals(sector, ticket.sector)
                && Objects.equals(agent, ticket.agent)
                && Objects.equals(category, ticket.category)
                && Objects.equals(comments, ticket.comments)
                && Objects.equals(notifications, ticket.notifications)
                && Objects.equals(logs, ticket.logs);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                id,
                os,
                title,
                description,
                applicant,
                createdAt,
                updatedAt,
                assignedAt,
                closedAt,
                active,
                status,
                author,
                priority,
                sector,
                agent,
                category,
                comments,
                notifications,
                logs
        );
    }
}
