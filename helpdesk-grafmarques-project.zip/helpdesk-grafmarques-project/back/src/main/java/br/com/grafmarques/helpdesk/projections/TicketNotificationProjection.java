package br.com.grafmarques.helpdesk.projections;

import java.util.UUID;

public interface TicketNotificationProjection {
    UUID getId();
    Long getOs();
}
