package br.com.grafmarques.helpdesk.model;

import br.com.grafmarques.helpdesk.model.enums.Role;
import jakarta.persistence.*;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Entity
@Table(name = "users")
public class User implements UserDetails, Serializable {

    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(length = 50, nullable = false)
    private String name;

    @Column(length = 60, unique = true, nullable = false)
    private String email;

    @Column(length = 100, nullable = false)
    private String password;

    @Enumerated(EnumType.STRING)
    private Role role;

    @Column(name = "created_at", nullable = false, updatable = false, insertable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false, insertable = false)
    private Boolean active;

    @ManyToOne @JoinColumn(name = "sector_id", referencedColumnName = "id", nullable = false)
    private Sector sector;

    @OneToMany(mappedBy = "author")
    private List<Ticket> openedTickets;

    @OneToMany(mappedBy = "agent")
    private List<Ticket> assignedTickets;

    @OneToMany(mappedBy = "user")
    private List<TicketComment> ticketsComments;

    @OneToMany(mappedBy = "recipient")
    private List<Notification> notifications;

    @OneToMany(mappedBy = "user")
    private List<UserOperationLog> logs;

    @OneToMany(mappedBy = "user")
    private List<TicketOperationLog> ticketLogs;

    public User() {}

    public User(
            UUID id,
            String name,
            String email,
            String password,
            Role role,
            LocalDateTime createdAt,
            Boolean active,
            Sector sector,
            List<Ticket> openedTickets,
            List<Ticket> assignedTickets,
            List<TicketComment> ticketsComments,
            List<Notification> notifications,
            List<UserOperationLog> logs,
            List<TicketOperationLog> ticketLogs
    ) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
        this.createdAt = createdAt;
        this.active = active;
        this.sector = sector;
        this.openedTickets = openedTickets;
        this.assignedTickets = assignedTickets;
        this.ticketsComments = ticketsComments;
        this.notifications = notifications;
        this.logs = logs;
        this.ticketLogs = ticketLogs;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        if (role == Role.ADMIN) return List.of(new SimpleGrantedAuthority("ROLE_ADMIN"));
        if (role == Role.AGENT) return List.of(new SimpleGrantedAuthority("ROLE_AGENT"));
        return List.of(new SimpleGrantedAuthority("ROLE_USER"));
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Sector getSector() {
        return sector;
    }

    public void setSector(Sector sector) {
        this.sector = sector;
    }

    public List<Ticket> getOpenedTickets() {
        return openedTickets;
    }

    public void setOpenedTickets(List<Ticket> openedTickets) {
        this.openedTickets = openedTickets;
    }

    public List<Ticket> getAssignedTickets() {
        return assignedTickets;
    }

    public void setAssignedTickets(List<Ticket> assignedTickets) {
        this.assignedTickets = assignedTickets;
    }

    public List<TicketComment> getTicketsComments() {
        return ticketsComments;
    }

    public void setTicketsComments(List<TicketComment> ticketsComments) {
        this.ticketsComments = ticketsComments;
    }

    public List<Notification> getNotifications() {
        return notifications;
    }

    public void setNotifications(List<Notification> notifications) {
        this.notifications = notifications;
    }

    public List<UserOperationLog> getLogs() {
        return logs;
    }

    public void setLogs(List<UserOperationLog> logs) {
        this.logs = logs;
    }

    public List<TicketOperationLog> getTicketLogs() {
        return ticketLogs;
    }

    public void setTicketLogs(List<TicketOperationLog> ticketLogs) {
        this.ticketLogs = ticketLogs;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(id, user.id)
                && Objects.equals(name, user.name)
                && Objects.equals(email, user.email)
                && Objects.equals(password, user.password)
                && role == user.role
                && Objects.equals(createdAt, user.createdAt)
                && Objects.equals(active, user.active)
                && Objects.equals(sector, user.sector)
                && Objects.equals(openedTickets, user.openedTickets)
                && Objects.equals(assignedTickets, user.assignedTickets)
                && Objects.equals(ticketsComments, user.ticketsComments)
                && Objects.equals(notifications, user.notifications)
                && Objects.equals(logs, user.logs)
                && Objects.equals(ticketLogs, user.ticketLogs);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                id,
                name,
                email,
                password,
                role,
                createdAt,
                active,
                sector,
                openedTickets,
                assignedTickets,
                ticketsComments,
                notifications,
                logs,
                ticketLogs
        );
    }
}
