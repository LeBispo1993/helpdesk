package br.com.grafmarques.helpdesk.data.DTO.v1.output;

import java.time.LocalDateTime;
import java.util.UUID;

public class TicketCommentResponseDTO {
    private UUID id;
    private LocalDateTime createdAt;
    private TicketDTO ticket;

    public TicketCommentResponseDTO() {}

    public TicketCommentResponseDTO(UUID id, LocalDateTime createdAt, TicketDTO ticket) {
        this.id = id;
        this.createdAt = createdAt;
        this.ticket = ticket;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public TicketDTO getTicket() {
        return ticket;
    }

    public void setTicket(TicketDTO ticket) {
        this.ticket = ticket;
    }
}
