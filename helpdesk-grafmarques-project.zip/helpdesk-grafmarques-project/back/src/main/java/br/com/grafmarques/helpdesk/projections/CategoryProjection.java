package br.com.grafmarques.helpdesk.projections;

import java.util.UUID;

public interface CategoryProjection {
    UUID getId();
    String getName();
}
