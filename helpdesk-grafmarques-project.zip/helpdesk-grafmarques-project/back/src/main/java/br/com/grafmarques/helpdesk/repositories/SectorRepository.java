package br.com.grafmarques.helpdesk.repositories;

import br.com.grafmarques.helpdesk.model.Sector;
import br.com.grafmarques.helpdesk.projections.SectorProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface SectorRepository extends JpaRepository<Sector, UUID> {
    @Query("SELECT s FROM Sector s WHERE UPPER(s.name) = UPPER(:name)")
    Optional<Sector> findByName(String name);

    @Query("SELECT s.id FROM Sector s WHERE UPPER(s.name) = UPPER(:name)")
    Optional<UUID> findIdByName(String name);

    @Query("SELECT s.id FROM Sector s WHERE UPPER(s.name) = UPPER(:name) AND s.id != :id")
    Optional<UUID> findIdByName(String name, UUID id);

    List<SectorProjection> findByActiveIsTrue();

    List<SectorProjection> findByActiveIsTrueAndServerIsTrue();
}
