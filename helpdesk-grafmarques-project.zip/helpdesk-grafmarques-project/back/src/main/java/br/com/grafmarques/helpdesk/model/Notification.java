package br.com.grafmarques.helpdesk.model;

import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;

@Entity
@Table(name = "notifications")
public class Notification implements Serializable {

    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(unique = true, length = 100, nullable = false)
    private String content;

    @Column(nullable = false)
    private Boolean viewed;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @ManyToOne @JoinColumn(name = "recipient_id", referencedColumnName = "id", nullable = false)
    private User recipient;

    @ManyToOne @JoinColumn(name = "ticket_id", referencedColumnName = "id")
    private Ticket ticket;

    public Notification() {}

    public Notification(UUID id, String content, Boolean viewed, LocalDateTime createdAt, User recipient, Ticket ticket) {
        this.id = id;
        this.content = content;
        this.viewed = viewed;
        this.createdAt = createdAt;
        this.recipient = recipient;
        this.ticket = ticket;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Boolean getViewed() {
        return viewed;
    }

    public void setViewed(Boolean viewed) {
        this.viewed = viewed;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public User getRecipient() {
        return recipient;
    }

    public void setRecipient(User recipient) {
        this.recipient = recipient;
    }

    public Ticket getTicket() {
        return ticket;
    }

    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Notification that = (Notification) o;
        return Objects.equals(id, that.id)
                && Objects.equals(content, that.content)
                && Objects.equals(viewed, that.viewed)
                && Objects.equals(createdAt, that.createdAt)
                && Objects.equals(recipient, that.recipient)
                && Objects.equals(ticket, that.ticket);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, content, viewed, createdAt, recipient, ticket);
    }
}
