package br.com.grafmarques.helpdesk.projections;

import java.time.LocalDateTime;

public interface TicketCommentProjection {
    String getContent();
    LocalDateTime getCreatedAt();
    UserAuthorProjection getUser();
}
