package br.com.grafmarques.helpdesk.data.DTO.v1.output;

import java.time.LocalDateTime;
import java.util.UUID;

public class StatusDTO {
    private UUID id;
    private String name;
    private LocalDateTime createdAt;
    private Boolean active;

    public StatusDTO() {}

    public StatusDTO(UUID id, String name, LocalDateTime createdAt, Boolean active) {
        this.id = id;
        this.name = name;
        this.createdAt = createdAt;
        this.active = active;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }
}
