package br.com.grafmarques.helpdesk.projections;

import java.util.UUID;

public interface UserAuthorProjection {
    UUID getId();
    String getName();
}
