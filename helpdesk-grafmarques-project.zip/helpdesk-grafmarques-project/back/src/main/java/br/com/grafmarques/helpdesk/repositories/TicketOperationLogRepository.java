package br.com.grafmarques.helpdesk.repositories;

import br.com.grafmarques.helpdesk.model.TicketOperationLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface TicketOperationLogRepository extends JpaRepository<TicketOperationLog, UUID> {
}
