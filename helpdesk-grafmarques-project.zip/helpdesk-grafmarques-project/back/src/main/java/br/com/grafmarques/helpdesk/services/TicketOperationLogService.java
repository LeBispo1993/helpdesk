package br.com.grafmarques.helpdesk.services;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.TicketDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.TicketOperationLogDTO;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.TicketOperationLog;
import br.com.grafmarques.helpdesk.repositories.TicketOperationLogRepository;
import br.com.grafmarques.helpdesk.services.auth.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.logging.Logger;

@Service
public class TicketOperationLogService {
    private final Logger LOGGER = Logger.getLogger(TicketOperationLogService.class.getName());

    private final TicketOperationLogRepository repository;
    private final UserService userService;
    private final TokenService tokenService;
    private final Mapper mapper;

    @Autowired
    public TicketOperationLogService(
            TicketOperationLogRepository repository,
            TokenService tokenService,
            UserService userService,
            Mapper mapper
    ) {
        this.repository = repository;
        this.userService = userService;
        this.tokenService = tokenService;
        this.mapper = mapper;
    }

    public void registerOperationLog(String operation, String details, TicketDTO ticket) {
        LOGGER.info("Registering a new ticket operation log (ticket id: " + ticket.getId() + ")");
        UserDTO user = userService.findById(tokenService.getUserId());
        TicketOperationLogDTO log = new TicketOperationLogDTO(null, ticket, operation, details, LocalDateTime.now(), user);
        repository.save(mapper.map(log, TicketOperationLog.class));
    }
}
