package br.com.grafmarques.helpdesk.data.DTO.v1.create;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.TicketDTO;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

public class TicketCommentCreateDTO {

    @NotBlank
    @Size(max = 200)
    private String content;

    @JsonIgnore
    private LocalDateTime createdAt = LocalDateTime.now();

    @NotNull
    private TicketDTO ticket;

    public TicketCommentCreateDTO() {}

    public TicketCommentCreateDTO(String content, TicketDTO ticket) {
        this.content = content;
        this.ticket = ticket;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public TicketDTO getTicket() {
        return ticket;
    }

    public void setTicket(TicketDTO ticket) {
        this.ticket = ticket;
    }
}
