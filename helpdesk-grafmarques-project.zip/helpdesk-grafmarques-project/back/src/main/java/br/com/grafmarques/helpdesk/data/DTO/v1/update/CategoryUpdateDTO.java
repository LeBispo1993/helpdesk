package br.com.grafmarques.helpdesk.data.DTO.v1.update;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.UUID;

public class CategoryUpdateDTO {

    @NotNull
    private UUID id;

    @NotBlank
    @Size(min = 2, max = 100)
    private String name;

    public CategoryUpdateDTO() {}

    public CategoryUpdateDTO(UUID id, String name) {
        this.id = id;
        this.name = name;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
