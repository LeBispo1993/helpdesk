package br.com.grafmarques.helpdesk.services.auth;

import br.com.grafmarques.helpdesk.data.DTO.v1.auth.TokenDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.exceptions.auth.JwtCreationTokenException;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.User;
import br.com.grafmarques.helpdesk.model.enums.Role;
import br.com.grafmarques.helpdesk.services.UserOperationLogService;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TokenServiceTest {

    @Autowired
    @InjectMocks
    private TokenService tokenService;

    @Mock
    private UserOperationLogService userOperationLogService;

    @Mock
    private Mapper mapper;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(tokenService, "secretKey", "testSecretKey");
    }

    @Test
    void testGenerateTokenSuccess() {
        User user = new User();
        user.setId(UUID.randomUUID());
        user.setRole(Role.USER);

        UserDTO userDTO = new UserDTO();
        when(mapper.map(user, UserDTO.class)).thenReturn(userDTO);

        TokenDTO tokenDTO = tokenService.generateToken(user);

        assertNotNull(tokenDTO);
        assertEquals(user.getId(), tokenDTO.getUserId());
        assertEquals(Role.USER, tokenDTO.getUserRole());
        assertNotNull(tokenDTO.getToken());
        assertNotNull(tokenDTO.getCreatedAt());
        assertNotNull(tokenDTO.getExpiresAt());

        verify(userOperationLogService, times(1))
                .registerOperationLog(anyString(), anyString(), eq(userDTO));
    }

    @Test
    void testGenerateTokenThrowsJwtCreationException() {
        User user = new User();
        user.setId(UUID.randomUUID());

        ReflectionTestUtils.setField(tokenService, "secretKey", null);

        JwtCreationTokenException exception = assertThrows(JwtCreationTokenException.class, () -> {
            tokenService.generateToken(user);
        });

        assertEquals("Erro durante a geração do token", exception.getMessage());
    }

    @Test
    void testValidateTokenSuccess() {
        User user = new User();
        user.setId(UUID.randomUUID());

        String token = JWT.create()
                .withIssuer("grafmarques")
                .withSubject(user.getId().toString())
                .withIssuedAt(Instant.now())
                .withExpiresAt(Instant.now().plusSeconds(3600))
                .sign(Algorithm.HMAC256("testSecretKey"));

        UUID userId = tokenService.validateToken(token);

        assertNotNull(userId);
        assertEquals(user.getId(), userId);
    }

    @Test
    void testValidateTokenThrowsJwtVerificationException() {
        String invalidToken = "invalidToken";

        UUID userId = tokenService.validateToken(invalidToken);

        assertNull(userId);
    }
}