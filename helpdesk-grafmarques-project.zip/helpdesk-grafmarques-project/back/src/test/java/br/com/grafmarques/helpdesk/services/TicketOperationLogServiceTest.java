package br.com.grafmarques.helpdesk.services;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.TicketDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.TicketOperationLogDTO;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.TicketOperationLog;
import br.com.grafmarques.helpdesk.repositories.TicketOperationLogRepository;
import br.com.grafmarques.helpdesk.services.auth.TokenService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TicketOperationLogServiceTest {

    @Autowired
    @InjectMocks
    private TicketOperationLogService service;

    @Mock
    private TicketOperationLogRepository repository;
    @Mock
    private UserService userService;
    @Mock
    private TokenService tokenService;
    @Mock
    private Mapper mapper;

    private UUID userId;
    private TicketOperationLog ticketOperationLog;
    private UserDTO userDTO;

    @BeforeEach
    void setup() {
        userId = UUID.randomUUID();
        ticketOperationLog = new TicketOperationLog();
        userDTO = new UserDTO();
        userDTO.setId(userId);
    }

    @Test
    @DisplayName("Should register a new ticket operation log")
    void registerOperationLog() {
        when(tokenService.getUserId()).thenReturn(userId);
        when(userService.findById(userId)).thenReturn(userDTO);
        when(mapper.map(any(TicketOperationLogDTO.class), eq(TicketOperationLog.class))).thenReturn(ticketOperationLog);
        when(repository.save(ticketOperationLog)).thenReturn(ticketOperationLog);

        service.registerOperationLog("Test Operation", "Test Details", Mockito.mock(TicketDTO.class));

        verify(tokenService, times(1)).getUserId();
        verify(userService, times(1)).findById(userId);
        verify(repository, times(1)).save(ticketOperationLog);
    }
}