package br.com.grafmarques.helpdesk.mapper.implementations;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.CategoryDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.TicketDTO;
import br.com.grafmarques.helpdesk.model.Category;
import br.com.grafmarques.helpdesk.model.enums.Priority;
import br.com.grafmarques.helpdesk.model.enums.Status;
import br.com.grafmarques.helpdesk.projections.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ModelMapperImplTest {

    @Autowired
    private ModelMapperImpl mapper;

    @BeforeEach
    void setup() {
        mapper = new ModelMapperImpl();
    }

    @Test
    @DisplayName("Should map a object")
    void mapObject() {
        // Arrange
        UUID id = UUID.randomUUID();
        LocalDateTime createdAt = LocalDateTime.now();
        Category category = new Category(id, "Test Category", createdAt, true, null);
        CategoryDTO categoryDTO = new CategoryDTO(id, "Test Category", createdAt, true);

        // Act
        CategoryDTO result = mapper.map(category, CategoryDTO.class);

        // Assert
        assertThat(result).isNotNull().isInstanceOf(CategoryDTO.class);
        assertThat(result.getId()).isEqualTo(categoryDTO.getId());
        assertThat(result.getName()).isEqualTo(categoryDTO.getName());
        assertThat(result.getCreatedAt()).isEqualTo(categoryDTO.getCreatedAt());
        assertThat(result.getActive()).isEqualTo(categoryDTO.getActive());
    }

    @Test
    @DisplayName("Should map list of objects")
    void mapListObject() {
        // Arrange
        UUID id = UUID.randomUUID();
        LocalDateTime createdAt = LocalDateTime.now();
        List<Category> categories = new ArrayList<>(List.of(
                new Category(id, "Test Category", createdAt, true, null)
        ));

        List<CategoryDTO> categoriesDTO = new ArrayList<>(List.of(
                new CategoryDTO(id, "Test Category", createdAt, true)
        ));

        // Act
        List<CategoryDTO> result = mapper.map(categories, CategoryDTO.class);

        // Assert
        assertThat(result).isNotNull().isNotEmpty();
        assertThat(result.getFirst()).isNotNull().isInstanceOf(CategoryDTO.class);
        assertThat(result.getFirst().getId()).isEqualTo(categoriesDTO.getFirst().getId());
        assertThat(result.getFirst().getName()).isEqualTo(categoriesDTO.getFirst().getName());
        assertThat(result.getFirst().getCreatedAt()).isEqualTo(categoriesDTO.getFirst().getCreatedAt());
        assertThat(result.getFirst().getActive()).isEqualTo(categoriesDTO.getFirst().getActive());
    }

    @Test
    @DisplayName("Should map TicketDetailsProjection to TicketDTO")
    void mapTicketProjection() {
        // Arrange
        UUID id = UUID.randomUUID();
        TicketDetailsProjection mockTicketProjection = Mockito.mock(TicketDetailsProjection.class);
        UserAuthorProjection mockAuthor = Mockito.mock(UserAuthorProjection.class);
        when(mockAuthor.getName()).thenReturn("John Doe");
        when(mockTicketProjection.getId()).thenReturn(id);
        when(mockTicketProjection.getOs()).thenReturn(1L);
        when(mockTicketProjection.getTitle()).thenReturn("Ticket Title");
        when(mockTicketProjection.getStatus()).thenReturn(Status.ABERTO);
        when(mockTicketProjection.getDescription()).thenReturn("A ticket description");
        when(mockTicketProjection.getApplicant()).thenReturn("Applicant Name");
        when(mockTicketProjection.getPriority()).thenReturn(Priority.ALTA);
        when(mockTicketProjection.getCreatedAt()).thenReturn(LocalDateTime.now());
        when(mockTicketProjection.getAuthor()).thenReturn(mockAuthor);
        when(mockTicketProjection.getActive()).thenReturn(true);

        SectorProjection mockSector = Mockito.mock(SectorProjection.class);
        when(mockSector.getName()).thenReturn("IT");
        when(mockTicketProjection.getSector()).thenReturn(mockSector);

        CategoryProjection mockCategory = Mockito.mock(CategoryProjection.class);
        when(mockCategory.getName()).thenReturn("Technical Support");
        when(mockTicketProjection.getCategory()).thenReturn(mockCategory);

        List<TicketCommentProjection> mockComments = new ArrayList<>();
        TicketCommentProjection comment = Mockito.mock(TicketCommentProjection.class);
        when(comment.getContent()).thenReturn("Comment Content");
        when(comment.getCreatedAt()).thenReturn(LocalDateTime.now());
        when(comment.getUser()).thenReturn(mockAuthor);
        mockComments.add(comment);

        when(mockTicketProjection.getComments()).thenReturn(mockComments);

        // Act
        TicketDTO ticketDTO = mapper.map(mockTicketProjection);

        // Assert
        assertThat(ticketDTO).isNotNull();
        assertThat(id).isEqualTo(ticketDTO.getId());
        assertThat(1L).isEqualTo(ticketDTO.getOs());
        assertThat("Ticket Title").isEqualTo(ticketDTO.getTitle());
        assertThat(Status.ABERTO).isEqualTo(ticketDTO.getStatus());
        assertThat("A ticket description").isEqualTo(ticketDTO.getDescription());
        assertThat("John Doe").isEqualTo(ticketDTO.getAuthor().getName());
        assertThat("IT").isEqualTo(ticketDTO.getSector().getName());
        assertThat("Technical Support").isEqualTo(ticketDTO.getCategory().getName());
        assertThat(1).isEqualTo(ticketDTO.getComments().size());
        assertThat("Comment Content").isEqualTo(ticketDTO.getComments().getFirst().getContent());
    }
}