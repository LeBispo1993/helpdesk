package br.com.grafmarques.helpdesk.services.util;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.CategoryDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.SectorDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.TicketDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.exceptions.general.NotFoundException;
import br.com.grafmarques.helpdesk.exceptions.general.UnauthorizedException;
import br.com.grafmarques.helpdesk.model.enums.Role;
import br.com.grafmarques.helpdesk.model.enums.Status;
import br.com.grafmarques.helpdesk.services.CategoryService;
import br.com.grafmarques.helpdesk.services.SectorService;
import br.com.grafmarques.helpdesk.services.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TicketValidatorServiceTest {

    @Autowired
    @InjectMocks
    private TicketValidatorService service;

    @Mock
    private UserService userService;
    @Mock
    private CategoryService categoryService;
    @Mock
    private SectorService sectorService;

    private UUID userId;
    private UUID sectorId;
    private UUID categoryId;

    @BeforeEach
    void setup() {
        userId = UUID.randomUUID();
        sectorId = UUID.randomUUID();
        categoryId = UUID.randomUUID();
    }

    @Test
    @DisplayName("Should not throw exception when everything is OK")
    void validateTicketRelationshipsCase1() {
        when(userService.findById(userId)).thenReturn(Mockito.mock(UserDTO.class));
        SectorDTO sectorMock = Mockito.mock(SectorDTO.class);
        when(sectorService.findById(sectorId)).thenReturn(sectorMock);
        when(sectorMock.getServer()).thenReturn(true);
        when(categoryService.findById(categoryId)).thenReturn(Mockito.mock(CategoryDTO.class));

        service.validateTicketRelationships(userId, sectorId, categoryId);

        verify(userService, times(1)).findById(userId);
        verify(sectorService, times(1)).findById(sectorId);
        verify(sectorMock, times(1)).getServer();
        verify(categoryService, times(1)).findById(categoryId);
    }

    @Test
    @DisplayName("Should throw NotFoundException when user id is invalid")
    void validateTicketRelationshipsCase2() {
        when(userService.findById(userId)).thenThrow(new NotFoundException("Nenhum usuário encontrado para este id"));

        NotFoundException thrown = assertThrows(NotFoundException.class, () -> service.validateTicketRelationships(userId, UUID.randomUUID(), UUID.randomUUID()));

        assertThat(thrown.getMessage()).isEqualTo("Nenhum usuário encontrado para este id");

        verify(userService, times(1)).findById(userId);
    }

    @Test
    @DisplayName("Should throw NotFoundException when sector id is invalid")
    void validateTicketRelationshipsCase3() {
        when(userService.findById(userId)).thenReturn(Mockito.mock(UserDTO.class));
        when(sectorService.findById(sectorId)).thenThrow(new NotFoundException("Nenhum setor encontrado para este id"));

        NotFoundException thrown = assertThrows(NotFoundException.class, () -> service.validateTicketRelationships(userId, sectorId, UUID.randomUUID()));

        assertThat(thrown.getMessage()).isEqualTo("Nenhum setor encontrado para este id");

        verify(userService, times(1)).findById(userId);
        verify(sectorService, times(1)).findById(sectorId);
    }

    @Test
    @DisplayName("Should throw UnauthorizedException when sector is not a server")
    void validateTicketRelationshipsCase4() {
        when(userService.findById(userId)).thenReturn(Mockito.mock(UserDTO.class));
        SectorDTO sectorMock = Mockito.mock(SectorDTO.class);
        when(sectorService.findById(sectorId)).thenReturn(sectorMock);
        when(sectorMock.getServer()).thenReturn(false);

        UnauthorizedException thrown = assertThrows(UnauthorizedException.class, () -> service.validateTicketRelationships(userId, sectorId, UUID.randomUUID()));

        assertThat(thrown.getMessage()).isEqualTo("O setor selecionado não pode atender chamados");

        verify(userService, times(1)).findById(userId);
        verify(sectorService, times(1)).findById(sectorId);
        verify(sectorMock, times(1)).getServer();
        verify(sectorMock, times(1)).getServer();
    }

    @Test
    @DisplayName("Should throw NotFoundException when category id is invalid")
    void validateTicketRelationshipsCase5() {
        when(userService.findById(userId)).thenReturn(Mockito.mock(UserDTO.class));
        SectorDTO sectorMock = Mockito.mock(SectorDTO.class);
        when(sectorService.findById(sectorId)).thenReturn(sectorMock);
        when(sectorMock.getServer()).thenReturn(true);
        when(categoryService.findById(categoryId)).thenThrow(new NotFoundException("Nenhuma categoria encontrada para este id"));

        NotFoundException thrown = assertThrows(NotFoundException.class, () -> service.validateTicketRelationships(userId, sectorId, categoryId));

        assertThat(thrown.getMessage()).isEqualTo("Nenhuma categoria encontrada para este id");

        verify(userService, times(1)).findById(userId);
        verify(sectorService, times(1)).findById(sectorId);
        verify(sectorMock, times(1)).getServer();

        verify(categoryService, times(1)).findById(categoryId);
    }

    @Test
    @DisplayName("Should not throw UnauthorizedException when user is the ticket author")
    public void validatePermissionToCommentCase1() {
        UserDTO userMock = Mockito.mock(UserDTO.class);
        when(userService.findById(userId)).thenReturn(userMock);
        when(userMock.getRole()).thenReturn(Role.USER);

        service.validatePermissionToComment(userId, userId);

        verify(userService, times(1)).findById(userId);
        verify(userMock, times(1)).getRole();
    }

    @Test
    @DisplayName("Should not throw UnauthorizedException when user role is agent")
    public void validatePermissionToCommentCase2() {
        UserDTO userMock = Mockito.mock(UserDTO.class);
        when(userService.findById(userId)).thenReturn(userMock);
        when(userMock.getRole()).thenReturn(Role.AGENT);

        service.validatePermissionToComment(userId, UUID.randomUUID());

        verify(userService, times(1)).findById(userId);
        verify(userMock, times(1)).getRole();
    }

    @Test
    @DisplayName("Should throw UnauthorizedException when user is not the ticket author")
    public void validatePermissionToCommentCase3() {
        UserDTO userMock = Mockito.mock(UserDTO.class);
        when(userService.findById(userId)).thenReturn(userMock);
        when(userMock.getRole()).thenReturn(Role.USER);

        UnauthorizedException thrown = assertThrows(UnauthorizedException.class, () -> service.validatePermissionToComment(userId, UUID.randomUUID()));

        assertThat(thrown.getMessage()).isEqualTo("Você não tem permissão para adicionar um comentário neste chamado");
        verify(userService, times(1)).findById(userId);
        verify(userMock, times(1)).getRole();
    }

    @Test
    @DisplayName("Should not throw exceptions when user is the author")
    void hasPermissionToUpdateActiveCase1() {
        UserDTO userDTO = new UserDTO();
        userDTO.setId(userId);
        userDTO.setRole(Role.USER);

        TicketDTO ticketDTO = new TicketDTO();
        ticketDTO.setAuthor(userDTO);

        assertDoesNotThrow(() -> service.hasPermissionToUpdateActive(userDTO, ticketDTO));
    }

    @Test
    @DisplayName("Should not throw exceptions when user is admin")
    void hasPermissionToUpdateActiveCase2() {
        UserDTO userDTO = new UserDTO();
        userDTO.setId(userId);
        userDTO.setRole(Role.ADMIN);

        TicketDTO ticketDTO = new TicketDTO();
        ticketDTO.setAuthor(new UserDTO());

        assertDoesNotThrow(() -> service.hasPermissionToUpdateActive(userDTO, ticketDTO));
    }

    @Test
    @DisplayName("Should throw UnauthorizedException when user is not author and not admin")
    void hasPermissionToUpdateActiveCase3() {
        UserDTO userDTO = new UserDTO();
        userDTO.setId(userId);
        userDTO.setRole(Role.USER);
        TicketDTO ticketDTO = new TicketDTO();
        ticketDTO.setAuthor(new UserDTO());

        UnauthorizedException thrown = assertThrows(UnauthorizedException.class, () -> service.hasPermissionToUpdateActive(userDTO, ticketDTO));

        assertThat(thrown.getMessage()).isEqualTo("Você não tem permissão para realizar está ação");
    }

    @Test
    @DisplayName("Should not throw exception when everything is OK")
    void validateStatusCase1() {
        assertDoesNotThrow(() -> service.validateStatus(Status.PROCESSANDO, Status.PROCESSANDO));
    }

    @Test
    @DisplayName("Should throw UnauthorizedException when ticket status is not the same as as allowed status")
    void validateStatusCase2() {
        UnauthorizedException thrown = assertThrows(UnauthorizedException.class, () -> service.validateStatus(Status.ABERTO, Status.FECHADO));
        assertThat(thrown.getMessage()).isEqualTo("Ação bloqueada devido ao status do chamado");
    }

    @Test
    @DisplayName("Should not throw exception when everything is OK")
    void validateUpdateStatusCase1() {
        TicketDTO ticketDTO = new TicketDTO();
        ticketDTO.setActive(true);
        ticketDTO.setStatus(Status.ABERTO);

        assertDoesNotThrow(() -> service.validateUpdateStatus(ticketDTO));
    }

    @Test
    @DisplayName("Should throw UnauthorizedException when ticket active is false")
    void validateUpdateStatusCase2() {
        TicketDTO ticketDTO = new TicketDTO();
        ticketDTO.setActive(false);

        UnauthorizedException thrown = assertThrows(UnauthorizedException.class, () -> service.validateUpdateStatus(ticketDTO));

        assertThat(thrown.getMessage()).isEqualTo("Ação bloqueada, este chamado foi deletado");
    }

    @Test
    @DisplayName("Should throw UnauthorizedException when ticket status is FECHADO")
    void validateUpdateStatusCase3() {
        TicketDTO ticketDTO = new TicketDTO();
        ticketDTO.setActive(true);
        ticketDTO.setStatus(Status.FECHADO);

        UnauthorizedException thrown = assertThrows(UnauthorizedException.class, () -> service.validateUpdateStatus(ticketDTO));

        assertThat(thrown.getMessage()).isEqualTo("Ação bloqueada devido ao status do chamado");
    }

    @Test
    @DisplayName("Should not throw exception when user is the ticket agent")
    void hasPermissionForCloseTicketCase1() {
        SectorDTO sectorDTO = new SectorDTO();
        sectorDTO.setId(UUID.randomUUID());

        UserDTO userDTO = new UserDTO();
        userDTO.setId(userId);
        userDTO.setRole(Role.AGENT);
        userDTO.setSector(sectorDTO);

        TicketDTO ticketDTO = new TicketDTO();
        ticketDTO.setStatus(Status.PROCESSANDO);
        ticketDTO.setAgent(userDTO);

        assertDoesNotThrow(() -> service.hasPermissionForCloseTicket(ticketDTO, userDTO));
    }

    @Test
    @DisplayName("Should not throw exception when user is admin")
    void hasPermissionForCloseTicketCase2() {
        SectorDTO sectorDTO = new SectorDTO();
        sectorDTO.setId(UUID.randomUUID());

        UserDTO userDTO = new UserDTO();
        userDTO.setId(userId);
        userDTO.setRole(Role.ADMIN);
        userDTO.setSector(sectorDTO);

        TicketDTO ticketDTO = new TicketDTO();
        ticketDTO.setStatus(Status.PROCESSANDO);
        UserDTO otherUserDTO = new UserDTO();
        otherUserDTO.setId(UUID.randomUUID());
        otherUserDTO.setSector(new SectorDTO());
        ticketDTO.setAgent(otherUserDTO);

        assertDoesNotThrow(() -> service.hasPermissionForCloseTicket(ticketDTO, userDTO));
    }

    @Test
    @DisplayName("Should throw UnauthorizedException when ticket status is not PROCESSANDO")
    void hasPermissionForCloseTicketCase3() {
        UserDTO userDTO = new UserDTO();
        TicketDTO ticketDTO = new TicketDTO();
        ticketDTO.setStatus(Status.ABERTO);

        UnauthorizedException thrown = assertThrows(UnauthorizedException.class, () -> service.hasPermissionForCloseTicket(ticketDTO, userDTO));

        assertThat(thrown.getMessage()).isEqualTo("O status do chamado deve ser 'PROCESSANDO'");
    }

    @Test
    @DisplayName("Should throw UnauthorizedException when user is not the ticket agent and not admin")
    void hasPermissionForCloseTicketCase4() {
        SectorDTO sectorDTO = new SectorDTO();
        sectorDTO.setId(UUID.randomUUID());

        UserDTO userDTO = new UserDTO();
        userDTO.setId(userId);
        userDTO.setRole(Role.AGENT);
        userDTO.setSector(sectorDTO);

        TicketDTO ticketDTO = new TicketDTO();
        ticketDTO.setStatus(Status.PROCESSANDO);
        UserDTO otherUserDTO = new UserDTO();
        otherUserDTO.setId(UUID.randomUUID());
        otherUserDTO.setSector(new SectorDTO());
        ticketDTO.setAgent(otherUserDTO);

        UnauthorizedException thrown = assertThrows(UnauthorizedException.class, () -> service.hasPermissionForCloseTicket(ticketDTO, userDTO));

        assertThat(thrown.getMessage()).isEqualTo("Ação bloqueada, esse chamado já está sendo processado por outra equipe");
    }

    @Test
    @DisplayName("Should not throw exception when sectors are different")
    void hasPermissionForAssignTicketCase1() {
        SectorDTO currentTeam = new SectorDTO();
        currentTeam.setId(UUID.randomUUID());
        SectorDTO team = new SectorDTO();
        team.setId(UUID.randomUUID());

        assertDoesNotThrow(() -> service.hasPermissionForAssignTicket(currentTeam, team));
    }

    @Test
    @DisplayName("Should not throw exception when everything is OK")
    void hasPermissionForAssignTicketCase2() {
        SectorDTO team = new SectorDTO();
        UnauthorizedException thrown = assertThrows(UnauthorizedException.class, () -> service.hasPermissionForAssignTicket(team, team));
        assertThat(thrown.getMessage()).isEqualTo("Esse chamado já está sendo processado por sua equipe");
    }
}