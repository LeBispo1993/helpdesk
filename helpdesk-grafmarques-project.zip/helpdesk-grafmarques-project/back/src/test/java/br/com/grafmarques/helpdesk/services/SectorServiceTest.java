package br.com.grafmarques.helpdesk.services;

import br.com.grafmarques.helpdesk.data.DTO.v1.create.SectorCreateDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.SectorDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.update.SectorUpdateDTO;
import br.com.grafmarques.helpdesk.exceptions.general.NotFoundException;
import br.com.grafmarques.helpdesk.exceptions.general.RepeatedDataException;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.Sector;
import br.com.grafmarques.helpdesk.projections.SectorProjection;
import br.com.grafmarques.helpdesk.repositories.SectorRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SectorServiceTest {

    @Autowired
    @InjectMocks
    private SectorService sectorService;

    @Mock
    private SectorRepository sectorRepository;

    @Mock
    private Mapper mapper;

    private UUID id;
    private Sector sector;
    private SectorDTO sectorDTO;
    private SectorCreateDTO sectorCreateDTO;
    private SectorUpdateDTO sectorUpdateDTO;

    @BeforeEach
    void setup() {
        id = UUID.randomUUID();
        sector = new Sector();
        sector.setId(id);
        sector.setName("Test Sector");

        sectorDTO = new SectorDTO();
        sectorDTO.setId(id);
        sectorDTO.setName("Test Sector");

        sectorCreateDTO = new SectorCreateDTO("Test Sector", false);

        sectorUpdateDTO = new SectorUpdateDTO();
        sectorUpdateDTO.setId(id);
        sectorUpdateDTO.setName("Updated Sector");
    }

    @Test
    @DisplayName("Should find sector by id when everything is OK")
    void findByIdCase1() {
        when(sectorRepository.findById(id)).thenReturn(Optional.of(sector));
        when(mapper.map(any(Sector.class), eq(SectorDTO.class))).thenReturn(sectorDTO);

        SectorDTO result = sectorService.findById(id);

        assertThat(result).isNotNull();
        assertThat(result).isInstanceOf(SectorDTO.class);
        assertThat(result.getId()).isEqualTo(id);

        verify(sectorRepository, times(1)).findById(id);
    }

    @Test
    @DisplayName("Should throw NotFoundException when id is invalid")
    void findByIdCase2() {
        NotFoundException thrown = assertThrows(NotFoundException.class, () -> sectorService.findById(UUID.randomUUID()));
        assertThat(thrown.getMessage()).isEqualTo("Nenhum setor encontrado para este id");

        verify(sectorRepository, times(1)).findById(any());
    }

    @Test
    @DisplayName("Should find sector by name when everything is OK")
    void findByNameCase1() {
        when(sectorRepository.findByName(sector.getName())).thenReturn(Optional.of(sector));
        when(mapper.map(any(Sector.class), eq(SectorDTO.class))).thenReturn(sectorDTO);

        SectorDTO result = sectorService.findByName(sector.getName());

        assertThat(result).isNotNull();
        assertThat(result).isInstanceOf(SectorDTO.class);
        assertThat(result.getId()).isEqualTo(id);
        assertThat(result.getName()).isEqualTo(sector.getName());

        verify(sectorRepository, times(1)).findByName(sector.getName());
    }

    @Test
    @DisplayName("Should throw NotFoundException when id is invalid")
    void findByNameCase2() {
        NotFoundException thrown = assertThrows(NotFoundException.class, () -> sectorService.findByName("sector name"));

        assertThat(thrown.getMessage()).isEqualTo("Nenhum setor encontrado para este nome");

        verify(sectorRepository, times(1)).findByName(any());
    }

    @Test
    @DisplayName("Should find all sectors")
    void findAll() {
        List<Sector> sectors = new ArrayList<>(List.of(sector));
        List<SectorDTO> sectorsDTOs = new ArrayList<>(List.of(sectorDTO));

        when(sectorRepository.findAll()).thenReturn(sectors);
        when(mapper.map(sectors, SectorDTO.class)).thenReturn(sectorsDTOs);

        List<SectorDTO> result = sectorService.findAll();

        assertThat(result).isNotNull().isNotEmpty();
        assertThat(result.getFirst().getId()).isEqualTo(id);
        assertThat(result.size()).isEqualTo(1);

        verify(sectorRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Should find sector list")
    void findList() {
        List<SectorProjection> projections = List.of(
                new SectorProjection() {
                    public UUID getId() {
                        return id;
                    }

                    public String getName() {
                        return "Test Sector";
                    }
                }
        );
        List<SectorDTO> categoriesDTOs = new ArrayList<>(List.of(sectorDTO));

        when(sectorRepository.findByActiveIsTrue()).thenReturn(projections);
        when(mapper.map(projections, SectorDTO.class)).thenReturn(categoriesDTOs);

        List<SectorDTO> result = sectorService.findList(false);

        assertThat(result).isNotEmpty().isNotNull();
        assertThat(result.size()).isEqualTo(1);
        assertThat(result.getFirst().getId()).isEqualTo(id);

        verify(sectorRepository, times(1)).findByActiveIsTrue();
    }

    @Test
    @DisplayName("Should find server sector list")
    void findListServer() {
        List<SectorProjection> projections = List.of(
                new SectorProjection() {
                    public UUID getId() {
                        return id;
                    }

                    public String getName() {
                        return "Test Sector";
                    }
                }
        );
        List<SectorDTO> categoriesDTOs = new ArrayList<>(List.of(sectorDTO));

        when(sectorRepository.findByActiveIsTrueAndServerIsTrue()).thenReturn(projections);
        when(mapper.map(projections, SectorDTO.class)).thenReturn(categoriesDTOs);

        List<SectorDTO> result = sectorService.findList(true);

        assertThat(result).isNotEmpty().isNotNull();
        assertThat(result.size()).isEqualTo(1);
        assertThat(result.getFirst().getId()).isEqualTo(id);

        verify(sectorRepository, times(1)).findByActiveIsTrueAndServerIsTrue();
    }

    @Test
    @DisplayName("Should create a new sector when everything is OK")
    void createCase1() {
        when(sectorRepository.findIdByName(sectorCreateDTO.getName().trim())).thenReturn(Optional.empty());
        when(mapper.map(any(SectorCreateDTO.class), eq(Sector.class))).thenReturn(sector);
        when(sectorRepository.save(sector)).thenReturn(sector);
        when(mapper.map(any(Sector.class), eq(SectorDTO.class))).thenReturn(sectorDTO);

        SectorDTO result = sectorService.create(sectorCreateDTO);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(id);

        verify(sectorRepository, times(1)).findIdByName(sectorCreateDTO.getName());
        verify(sectorRepository, times(1)).save(sector);
    }

    @Test
    @DisplayName("Should throw a RepeatedDataException when sector name already exists")
    void createCase2() {
        when(sectorRepository.findIdByName(sectorCreateDTO.getName())).thenReturn(Optional.of(UUID.randomUUID()));

        RepeatedDataException thrown =
                assertThrows(RepeatedDataException.class, () -> sectorService.create(sectorCreateDTO));

        assertThat(thrown.getMessage()).isEqualTo("Esse setor já existe");

        verify(sectorRepository, times(1)).findIdByName(sectorCreateDTO.getName());
    }

    @Test
    @DisplayName("Should update a sector when everything is OK")
    void update() {
        when(sectorRepository.findById(id)).thenReturn(Optional.of(sector));
        when(mapper.map(any(SectorDTO.class), eq(Sector.class))).thenReturn(sector);
        when(sectorRepository.save(sector)).thenReturn(sector);
        when(mapper.map(any(Sector.class), eq(SectorDTO.class))).thenReturn(sectorDTO);

        SectorDTO result = sectorService.update(sectorUpdateDTO);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(sectorDTO.getId());

        verify(sectorRepository, times(1)).findById(id);
        verify(sectorRepository, times(1)).save(sector);
    }

    @Test
    @DisplayName("Should update sector active status")
    void changeActive() {
        when(sectorRepository.findById(id)).thenReturn(Optional.of(sector));
        when(mapper.map(any(SectorDTO.class), eq(Sector.class))).thenReturn(sector);
        when(sectorRepository.save(sector)).thenReturn(sector);
        when(mapper.map(any(Sector.class), eq(SectorDTO.class))).thenReturn(sectorDTO);


        SectorDTO result = sectorService.changeActive(id, false);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(id);
        assertThat(sector.getActive()).isEqualTo(false);

        verify(sectorRepository, times(1)).save(sector);
    }
}