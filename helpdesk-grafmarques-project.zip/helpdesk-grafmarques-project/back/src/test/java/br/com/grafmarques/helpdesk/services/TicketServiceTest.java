package br.com.grafmarques.helpdesk.services;

import br.com.grafmarques.helpdesk.data.DTO.v1.create.TicketCreateDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.*;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.TicketFilterDTO;
import br.com.grafmarques.helpdesk.exceptions.general.NotFoundException;
import br.com.grafmarques.helpdesk.exceptions.general.UnauthorizedException;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.Ticket;
import br.com.grafmarques.helpdesk.model.User;
import br.com.grafmarques.helpdesk.model.enums.Priority;
import br.com.grafmarques.helpdesk.model.enums.Status;
import br.com.grafmarques.helpdesk.projections.*;
import br.com.grafmarques.helpdesk.repositories.TicketRepository;
import br.com.grafmarques.helpdesk.services.auth.TokenService;
import br.com.grafmarques.helpdesk.services.util.TicketValidatorService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TicketServiceTest {

    @Autowired
    @InjectMocks
    private TicketService service;

    @Mock
    private TicketRepository repository;
    @Mock
    private TicketValidatorService validator;
    @Mock
    private UserService userService;
    @Mock
    private TokenService tokenService;
    @Mock
    private TicketOperationLogService ticketOperationLogService;
    @Mock
    private NotificationService notificationService;
    @Mock
    private Mapper mapper;

    private UUID id;
    private UUID userId;
    private Ticket ticket;
    private TicketDTO ticketDTO;
    private TicketCreateDTO createDTO;
    private TicketResponseDTO responseDTO;
    private UserDTO userDTO;
    private TicketProjection ticketProjection;
    private TicketDetailsProjection detailsProjection;
    private List<TicketProjection> projections;
    private List<TicketDTO> ticketsDTO;
    private LocalDateTime startDate;
    private LocalDateTime endDate;

    @BeforeEach
    void setup() {
        id = UUID.randomUUID();
        ticket = new Ticket();
        ticket.setId(id);
        ticket.setTitle("");
        ticket.setDescription("");
        ticket.setApplicant("");
        ticketDTO = new TicketDTO();
        ticketDTO.setId(id);

        responseDTO = new TicketResponseDTO();
        responseDTO.setId(id);

        userId = UUID.randomUUID();
        userDTO = new UserDTO();
        userDTO.setId(userId);

        ticketDTO.setAuthor(userDTO);

        createDTO = new TicketCreateDTO("", null, "", "", null, userDTO, Mockito.mock(SectorDTO.class), Mockito.mock(CategoryDTO.class));
        createDTO.setAuthor(userDTO);

        ticketProjection = new TicketProjection() {
            @Override
            public UUID getId() {
                return id;
            }

            @Override
            public Long getOs() {
                return 1L;
            }

            @Override
            public String getTitle() {
                return "Test Title";
            }

            @Override
            public Status getStatus() {
                return null;
            }

            @Override
            public Priority getPriority() {
                return null;
            }

            @Override
            public CategoryProjection getCategory() {
                return null;
            }

            @Override
            public LocalDateTime getCreatedAt() {
                return null;
            }

            @Override
            public LocalDateTime getUpdatedAt() {
                return null;
            }

            @Override
            public SectorProjection getSector() {
                return null;
            }

            @Override
            public UserAgentProjection getAgent() {
                return null;
            }

            @Override
            public String getApplicant() {
                return "";
            }

            @Override
            public UserAuthorProjection getAuthor() {
                return null;
            }

            @Override
            public Boolean getActive() {
                return null;
            }
        };
        detailsProjection = new TicketDetailsProjection() {
            @Override
            public UUID getId() {
                return id;
            }

            @Override
            public Long getOs() {
                return 1L;
            }

            @Override
            public String getTitle() {
                return "Test Title";
            }

            @Override
            public Status getStatus() {
                return Status.ABERTO;
            }

            @Override
            public Priority getPriority() {
                return Priority.ALTA;
            }

            @Override
            public CategoryProjection getCategory() {
                return null;
            }

            @Override
            public LocalDateTime getCreatedAt() {
                return null;
            }

            @Override
            public LocalDateTime getUpdatedAt() {
                return null;
            }

            @Override
            public UserAgentProjection getAgent() {
                return null;
            }

            @Override
            public String getApplicant() {
                return "Test Applicant Name";
            }

            @Override
            public Boolean getActive() {
                return null;
            }

            @Override
            public String getDescription() {
                return "";
            }

            @Override
            public UserAuthorProjection getAuthor() {
                return null;
            }

            @Override
            public SectorProjection getSector() {
                return null;
            }

            @Override
            public LocalDateTime getAssignedAt() {
                return null;
            }

            @Override
            public LocalDateTime getClosedAt() {
                return null;
            }

            @Override
            public List<TicketCommentProjection> getComments() {
                return List.of();
            }
        };

        ticketsDTO = new ArrayList<>(List.of(ticketDTO));
        projections = new ArrayList<>(List.of(ticketProjection));;

        startDate = LocalDate.now().minusDays(7).atTime(0, 0, 0);
        endDate = LocalDate.now().atTime(23, 59, 59);
    }

    @Test
    @DisplayName("Should find ticket by id when everything is OK")
    void findByIdCase1() {
        when(repository.findTicketDetailsById(id)).thenReturn(Optional.of(detailsProjection));
        when(mapper.map(any(TicketDetailsProjection.class))).thenReturn(ticketDTO);

        TicketDTO result = service.findById(id);

        assertThat(result).isNotNull();

        verify(repository, times(1)).findTicketDetailsById(id);
    }

    @Test
    @DisplayName("Should throw NotFoundException when id is invalid")
    void findByIdCase2() {
        NotFoundException thrown = assertThrows(NotFoundException.class, () -> service.findById(id));

        assertThat(thrown.getMessage()).isEqualTo("Nenhum chamado encontrado para este id");

        verify(repository, times(1)).findTicketDetailsById(id);
    }

    @Test
    @DisplayName("Should find all ticketsDTO for admin page")
    void findForAdminPage() {
        // Arrange
        when(
                repository
                .findByUpdatedAtBetweenOrderByUpdatedAtDesc(startDate, endDate)
        ).thenReturn(projections);
        when(mapper.map(any(), eq(TicketDTO.class))).thenReturn(ticketsDTO);

        // Act
        List<TicketDTO> result = service.findForAdminPage(Mockito.mock(TicketFilterDTO.class));

        // Assert
        assertThat(result).isNotNull().isNotEmpty();
        assertThat(result.getFirst()).isInstanceOf(TicketDTO.class);
        assertThat(result.getFirst().getId()).isEqualTo(ticketsDTO.getFirst().getId());

        // Verify
        verify(repository, times(1))
                .findByUpdatedAtBetweenOrderByUpdatedAtDesc(
                        startDate,
                        endDate
                );
    }

    @Test
    @DisplayName("Should find all ticketsDTO for home page")
    void findForHomePage() {
        // Arrange
        when(
                repository
                .findByUpdatedAtBetweenAndActiveTrueOrderByUpdatedAtDesc(startDate, endDate)
        ).thenReturn(projections);
        when(mapper.map(any(), eq(TicketDTO.class))).thenReturn(ticketsDTO);

        // Act
        List<TicketDTO> result = service.findForHomePage(Mockito.mock(TicketFilterDTO.class));

        // Assert
        assertThat(result).isNotNull().isNotEmpty();
        assertThat(result.getFirst()).isInstanceOf(TicketDTO.class);
        assertThat(result.getFirst().getId()).isEqualTo(ticketsDTO.getFirst().getId());

        // Verify
        verify(repository, times(1))
                .findByUpdatedAtBetweenAndActiveTrueOrderByUpdatedAtDesc(
                    startDate,
                    endDate
                );
    }

    @Test
    @DisplayName("Should find tickets by author id")
    void findByAuthor() {
        // Arrange
        when(tokenService.getUserId()).thenReturn(userId);
        when(
                repository
                .findByAuthorIdAndActiveIsTrueAndUpdatedAtBetweenOrderByUpdatedAtDesc(
                        userId, startDate, endDate
                )
        ).thenReturn(projections);
        when(mapper.map(any(), eq(TicketDTO.class))).thenReturn(ticketsDTO);

        // Act
        List<TicketDTO> result = service.findByAuthor(Mockito.mock(TicketFilterDTO.class));

        // Assert
        assertThat(result).isNotNull().isNotEmpty();
        assertThat(result.getFirst()).isInstanceOf(TicketDTO.class);
        assertThat(result.getFirst().getId()).isEqualTo(ticketsDTO.getFirst().getId());

        // Verify
        verify(repository, times(1))
                .findByAuthorIdAndActiveIsTrueAndUpdatedAtBetweenOrderByUpdatedAtDesc(
                        userId, startDate, endDate
                );

    }

    @Test
    @DisplayName("Should create a new ticket")
    void create() {
        // Arrange
        when(tokenService.getUserId()).thenReturn(userId);
        when(userService.findById(userId)).thenReturn(userDTO);
        when(mapper.map(createDTO, Ticket.class)).thenReturn(ticket);
        when(repository.save(ticket)).thenReturn(ticket);
        when(repository.findById(id)).thenReturn(Optional.of(ticket));
        when(mapper.map(Optional.of(ticket), TicketResponseDTO.class)).thenReturn(responseDTO);
        when(mapper.map(responseDTO, TicketDTO.class)).thenReturn(ticketDTO);

        // Act
        TicketResponseDTO result = service.create(createDTO);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result).isInstanceOf(TicketResponseDTO.class);
        assertThat(result.getId()).isEqualTo(ticketDTO.getId());

        // Verify
        verify(tokenService, times(1)).getUserId();
        verify(userService, times(1)).findById(userId);
        verify(validator, times(1))
                .validateTicketRelationships(userId, null, null);
        verify(repository, times(1)).save(ticket);
        verify(repository, times(1)).findById(id);
        verify(ticketOperationLogService, times(1))
                .registerOperationLog(
                        "Ticket Creation",
                        "Ticket Creation completed successfully",
                        ticketDTO
                );
        verify(notificationService, times(1))
                .create(
                        "Chamado criado",
                        createDTO.getAuthor(),
                        ticketDTO
                );

    }

    @Test
    @DisplayName("Should update status to 'PROCESSANDO'")
    void updateStatusCase1() {
        // Arrange
        when(repository.findById(id)).thenReturn(Optional.of(ticket));
        when(mapper.map(any(Ticket.class), eq(TicketDTO.class))).thenReturn(ticketDTO);
        when(tokenService.getUserId()).thenReturn(userId);
        when(userService.findById(userId)).thenReturn(userDTO);
        when(mapper.map(any(TicketDTO.class), eq(Ticket.class))).thenReturn(ticket);
        when(repository.save(ticket)).thenReturn(ticket);
        when(mapper.map(any(Ticket.class), eq(TicketResponseDTO.class))).thenReturn(responseDTO);
        when(mapper.map(any(TicketResponseDTO.class), eq(TicketDTO.class))).thenReturn(ticketDTO);

        // Act
        TicketResponseDTO result = service.updateStatus(id, Status.PROCESSANDO);

        // Assert
        assertThat(result).isNotNull().isInstanceOf(TicketResponseDTO.class);
        assertThat(result.getId()).isEqualTo(responseDTO.getId());

        // Verify
        verify(tokenService, times(1)).getUserId();
        verify(userService, times(1)).findById(userId);
        verify(validator, times(1)).validateUpdateStatus(ticketDTO);
        verify(repository, times(1)).save(ticket);
        verify(ticketOperationLogService, times(1))
                .registerOperationLog(
                        "Status Update",
                        "Status update to 'PROCESSANDO' successfully",
                        ticketDTO
                );
        verify(notificationService, times(1))
                .create(
                        "O status de seu chamado foi alterado. Novo status: processando",
                        userDTO,
                        ticketDTO
                );
    }

    @Test
    @DisplayName("Should update status to 'FECHADO'")
    void updateStatusCase2() {
        // Arrange
        when(repository.findById(id)).thenReturn(Optional.of(ticket));
        when(mapper.map(any(Ticket.class), eq(TicketDTO.class))).thenReturn(ticketDTO);
        when(tokenService.getUserId()).thenReturn(userId);
        when(userService.findById(userId)).thenReturn(userDTO);
        when(mapper.map(any(TicketDTO.class), eq(Ticket.class))).thenReturn(ticket);
        when(repository.save(ticket)).thenReturn(ticket);
        when(mapper.map(any(Ticket.class), eq(TicketResponseDTO.class))).thenReturn(responseDTO);
        when(mapper.map(any(TicketResponseDTO.class), eq(TicketDTO.class))).thenReturn(ticketDTO);

        // Act
        TicketResponseDTO result = service.updateStatus(id, Status.FECHADO);

        // Assert
        assertThat(result).isNotNull().isInstanceOf(TicketResponseDTO.class);
        assertThat(result.getId()).isEqualTo(responseDTO.getId());

        // Verify
        verify(tokenService, times(1)).getUserId();
        verify(userService, times(1)).findById(userId);
        verify(validator, times(1)).validateUpdateStatus(ticketDTO);
        verify(validator, times(1)).hasPermissionForCloseTicket(ticketDTO, userDTO);
        verify(repository, times(1)).save(ticket);
        verify(ticketOperationLogService, times(1))
                .registerOperationLog(
                        "Status Update",
                        "Status update to 'FECHADO' successfully",
                        ticketDTO
                );
        verify(notificationService, times(1))
                .create(
                        "O status de seu chamado foi alterado. Novo status: fechado",
                        userDTO,
                        ticketDTO
                );
    }

    @Test
    @DisplayName("Should throw NotFoundException when ticket id is invalid")
    void updateStatusCase3() {
        when(repository.findById(id)).thenReturn(Optional.empty());
        NotFoundException thrown = assertThrows(NotFoundException.class, () -> service.updateStatus(id, Status.PROCESSANDO));
        assertThat(thrown.getMessage()).isEqualTo("Nenhum chamado encontrado para este id");

        verify(repository, times(1)).findById(id);
    }

    @Test
    @DisplayName("Should throw NotFoundException when user id is invalid")
    void updateStatusCase4() {
        when(repository.findById(id)).thenReturn(Optional.of(ticket));
        when(tokenService.getUserId()).thenReturn(userId);
        when(userService.findById(userId)).thenThrow(new NotFoundException("Nenhum usuário encontrado para este id"));

        NotFoundException thrown = assertThrows(NotFoundException.class, () -> service.updateStatus(id, Status.PROCESSANDO));

        assertThat(thrown.getMessage()).isEqualTo("Nenhum usuário encontrado para este id");

        verify(repository, times(1)).findById(id);
        verify(tokenService, times(1)).getUserId();
        verify(userService, times(1)).findById(userId);
    }

    @Test
    @DisplayName("Should update activity when everything is OK")
    void updateActivityCase1() {
        // Arrange
        ticketDTO.setAuthor(mock(UserDTO.class));
        ticket.setAuthor(mock(User.class));
        ticket.setActive(true);
        when(repository.findById(id)).thenReturn(Optional.of(ticket));
        when(tokenService.getUserId()).thenReturn(userId);
        when(userService.findById(userId)).thenReturn(userDTO);
        when(mapper.map(any(Ticket.class), eq(TicketDTO.class))).thenReturn(ticketDTO);
        when(repository.save(ticket)).thenReturn(ticket);
        when(mapper.map(any(Ticket.class), eq(TicketResponseDTO.class))).thenReturn(responseDTO);
        when(mapper.map(any(User.class), eq(UserDTO.class))).thenReturn(userDTO);

        // Act
        TicketResponseDTO result = service.updateActivity(id);

        // Assert
        assertThat(result).isNotNull().isInstanceOf(TicketResponseDTO.class);
        assertThat(result.getId()).isEqualTo(responseDTO.getId());

        // Verify
        verify(repository, times(1)).findById(id);
        verify(tokenService, times(1)).getUserId();
        verify(userService, times(1)).findById(userId);
        verify(validator, times(1)).validateStatus(ticket.getStatus(), Status.ABERTO);
        verify(validator, times(1)).hasPermissionToUpdateActive(userDTO, ticketDTO);
        verify(repository, times(1)).save(ticket);
        verify(ticketOperationLogService, times(1))
                .registerOperationLog(
                        "Activity Update",
                        "Activity update to 'false' successfully",
                        ticketDTO
                );
        verify(notificationService, times(1))
                .create(
                        "Seu chamado foi excluído",
                        userDTO,
                        ticketDTO
                );
    }

    @Test
    @DisplayName("Should throw UnauthorizedException when ticket active is false")
    void updateActivityCase2() {
        ticket.setActive(false);
        when(repository.findById(id)).thenReturn(Optional.of(ticket));

        UnauthorizedException thrown = assertThrows(UnauthorizedException.class, () -> service.updateActivity(id));

        assertThat(thrown.getMessage()).isEqualTo("Ação bloqueada, o chamado já foi deletado");

        verify(repository, times(1)).findById(id);
    }

    @Test
    @DisplayName("Should throw NotFoundException when ticket id is invalid")
    void updateActivityCase3() {
        when(repository.findById(id)).thenReturn(Optional.empty());

        NotFoundException thrown = assertThrows(NotFoundException.class, () -> service.updateActivity(id));

        assertThat(thrown.getMessage()).isEqualTo("Nenhum chamado encontrado para este id");

        verify(repository, times(1)).findById(id);
    }
}