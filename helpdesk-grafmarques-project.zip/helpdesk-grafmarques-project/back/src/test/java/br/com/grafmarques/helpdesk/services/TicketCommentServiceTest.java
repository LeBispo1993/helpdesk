package br.com.grafmarques.helpdesk.services;

import br.com.grafmarques.helpdesk.data.DTO.v1.create.TicketCommentCreateDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.TicketCommentDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.TicketCommentResponseDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.TicketDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.TicketComment;
import br.com.grafmarques.helpdesk.repositories.TicketCommentRepository;
import br.com.grafmarques.helpdesk.services.auth.TokenService;
import br.com.grafmarques.helpdesk.services.util.TicketValidatorService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TicketCommentServiceTest {

    @Autowired
    @InjectMocks
    private TicketCommentService ticketCommentService;

    @Mock
    private TicketCommentRepository ticketCommentRepository;
    @Mock
    private TicketValidatorService validatorService;
    @Mock
    private TicketService ticketService;
    @Mock
    private TicketOperationLogService ticketOperationLogService;
    @Mock
    private NotificationService notificationService;
    @Mock
    private UserService userService;
    @Mock
    private TokenService tokenService;
    @Mock
    private Mapper mapper;

    private UUID ticketId;
    private UUID userId;
    private TicketComment ticketComment;
    private TicketCommentDTO commentDTO;
    private TicketCommentCreateDTO createDTO;
    private TicketCommentResponseDTO responseDTO;
    private TicketDTO ticketDTO;
    private UserDTO userDTO;

    @BeforeEach
    void setup() {
        userId = UUID.randomUUID();
        ticketId = UUID.randomUUID();

        createDTO = new TicketCommentCreateDTO();
        createDTO.setContent("");

        commentDTO = new TicketCommentDTO();
        commentDTO.setContent("");
        ticketDTO = new TicketDTO();
        ticketDTO.setId(ticketId);
        commentDTO.setTicket(ticketDTO);

        ticketComment = new TicketComment();
        responseDTO = new TicketCommentResponseDTO();

        userDTO = new UserDTO();
        userDTO.setId(userId);
        ticketDTO.setAuthor(userDTO);
    }

    @Test
    @DisplayName("Should create a ticket comment")
    void create() {
        // Arrange
        when(mapper.map(any(TicketCommentCreateDTO.class), eq(TicketCommentDTO.class))).thenReturn(commentDTO);
        when(ticketService.findById(ticketId)).thenReturn(ticketDTO);
        when(tokenService.getUserId()).thenReturn(userId);
        when(userService.findById(userId)).thenReturn(userDTO);
        when(mapper.map(any(TicketCommentDTO.class), eq(TicketComment.class))).thenReturn(ticketComment);
        when(ticketCommentRepository.save(ticketComment)).thenReturn(ticketComment);
        when(mapper.map(any(TicketComment.class), eq(TicketCommentResponseDTO.class))).thenReturn(responseDTO);

        // Act
        TicketCommentResponseDTO result = ticketCommentService.create(createDTO);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result).isEqualTo(responseDTO);

        // Verify
        verify(mapper).map(createDTO, TicketCommentDTO.class);
        verify(ticketService, times(1)).findById(ticketId);
        verify(validatorService, times(1)).validatePermissionToComment(userId, userId);
        verify(tokenService, times(2)).getUserId();
        verify(userService).findById(userId);
        verify(mapper).map(commentDTO, TicketComment.class);
        verify(ticketOperationLogService).registerOperationLog(
                eq("Comment Creation"),
                eq("Ticket comment creation completed successfully"),
                eq(ticketDTO)
        );
        verify(ticketCommentRepository).save(ticketComment);
        verify(mapper).map(ticketComment, TicketCommentResponseDTO.class);
    }
}