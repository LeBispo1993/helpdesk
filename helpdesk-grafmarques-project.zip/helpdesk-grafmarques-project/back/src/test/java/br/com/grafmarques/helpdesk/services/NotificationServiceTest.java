package br.com.grafmarques.helpdesk.services;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.NotificationDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.TicketDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.NotificationIdsDTO;
import br.com.grafmarques.helpdesk.exceptions.general.NotFoundException;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.Notification;
import br.com.grafmarques.helpdesk.projections.NotificationProjection;
import br.com.grafmarques.helpdesk.repositories.NotificationRepository;
import br.com.grafmarques.helpdesk.services.auth.TokenService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationServiceTest {
    @Autowired
    @InjectMocks
    private NotificationService notificationService;

    @Mock
    private NotificationRepository notificationRepository;
    @Mock
    private TokenService tokenService;
    @Mock
    private PagedResourcesAssembler<NotificationDTO> assembler;
    @Mock
    private Mapper mapper;

    private UUID id;
    private UUID userId;
    private Notification notification;
    private List<Notification> notifications;
    private NotificationDTO notificationDTO;

    @BeforeEach
    void setup() {
        id = UUID.randomUUID();
        userId = UUID.randomUUID();
        notification = new Notification();
        notification.setId(id);
        notification.setContent("Test Content");
        notification.setViewed(false);

        notifications = List.of(notification);

        notificationDTO = new NotificationDTO();
        notificationDTO.setId(id);
        notificationDTO.setContent("Test Content");
    }

    @Test
    @DisplayName("Should find number of notifications not viewed by user id")
    void countNotViewed() {
        // Arrange
        when(tokenService.getUserId()).thenReturn(userId);
        when(notificationRepository.countNotViewedByUserId(userId)).thenReturn(5L);

        // Act
        long result = notificationService.countNotViewed();

        // Assert
        assertThat(result).isPositive();
        assertThat(result).isEqualTo(5L);
    }

    @Test
    @DisplayName("Should find all notifications by user id with pagination")
    void findAll() {
        // Arrange
        Pageable pageable = PageRequest.of(0, 10);
        NotificationProjection notificationProjection = mock(NotificationProjection.class);
        Page<NotificationProjection> page = new PageImpl<>(Collections.singletonList(notificationProjection));
        when(tokenService.getUserId()).thenReturn(userId);
        when(notificationRepository.findByRecipientIdOrderByCreatedAtDesc(userId, pageable)).thenReturn(page);
        NotificationDTO notificationDTO = mock(NotificationDTO.class);
        when(mapper.map(any(NotificationProjection.class), eq(NotificationDTO.class))).thenReturn(notificationDTO);

        // Act
        notificationService.findAll(pageable);

        // Verifications
        verify(notificationRepository, times(1)).findByRecipientIdOrderByCreatedAtDesc(userId, pageable);
        verify(mapper, times(1)).map(any(NotificationProjection.class), eq(NotificationDTO.class));
    }

    @Test
    @DisplayName("Should create a new notification")
    void create() {
        // Arrange
        when(mapper.map(any(NotificationDTO.class), eq(Notification.class))).thenReturn(notification);
        when(notificationRepository.save(notification)).thenReturn(notification);
        when(mapper.map(any(Notification.class), eq(NotificationDTO.class))).thenReturn(notificationDTO);

        // Act
        notificationService.create("Content", Mockito.mock(UserDTO.class), Mockito.mock(TicketDTO.class));

        // Assert
        verify(notificationRepository, times(1)).save(notification);
    }

    @Test
    @DisplayName("Should update field viewed to true")
    void view() {
        // Arrange
        List<UUID> ids = List.of(id);
        NotificationIdsDTO notificationIdsDTO = new NotificationIdsDTO(ids);

        when(notificationRepository.findAllById(notificationIdsDTO.getIds())).thenReturn(notifications);
        when(notificationRepository.saveAll(notifications)).thenReturn(notifications);

        // Act
        notificationService.view(notificationIdsDTO);

        // Verify
        verify(notificationRepository, times(1)).findAllById(ids);
        verify(notificationRepository, times(1)).saveAll(notifications);
    }

    @Test
    @DisplayName("Should delete notification by id when everything is OK")
    void deleteCase1() {
        when(notificationRepository.findById(id)).thenReturn(Optional.of(notification));

        notificationService.delete(id);

        verify(notificationRepository, times(1)).findById(id);
        verify(notificationRepository, times(1)).delete(notification);
    }

    @Test
    @DisplayName("Should throw NotFoundException when notification id is invalid")
    void deleteCase2() {
        NotFoundException thrown = assertThrows(NotFoundException.class, () -> notificationService.delete(UUID.randomUUID()));

        assertThat(thrown.getMessage()).isEqualTo("Nenhuma notificação encontrada para este id");

        verify(notificationRepository, times(1)).findById(any());
    }

    @Test
    @DisplayName("Should delete all notifications by user id")
    void deleteAll() {
        when(tokenService.getUserId()).thenReturn(userId);

        notificationService.deleteAll();

        verify(notificationRepository, times(1)).deleteAllByUserId(userId);
    }
}