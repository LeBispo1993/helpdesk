package br.com.grafmarques.helpdesk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")
class HelpdeskGrafmarquesApplicationTests {

	@Test
	void contextLoads() {
	}

}
