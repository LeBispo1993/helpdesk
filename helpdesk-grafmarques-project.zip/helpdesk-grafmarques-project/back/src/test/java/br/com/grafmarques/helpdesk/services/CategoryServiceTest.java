package br.com.grafmarques.helpdesk.services;

import br.com.grafmarques.helpdesk.data.DTO.v1.create.CategoryCreateDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.CategoryDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.update.CategoryUpdateDTO;
import br.com.grafmarques.helpdesk.exceptions.general.NotFoundException;
import br.com.grafmarques.helpdesk.exceptions.general.RepeatedDataException;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.Category;
import br.com.grafmarques.helpdesk.projections.CategoryProjection;
import br.com.grafmarques.helpdesk.repositories.CategoryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CategoryServiceTest {

    @Autowired
    @InjectMocks
    private CategoryService categoryService;

    @Mock
    private CategoryRepository categoryRepository;

    @Mock
    private Mapper mapper;

    private UUID id;
    private Category category;
    private CategoryDTO categoryDTO;
    private CategoryCreateDTO categoryCreateDTO;
    private CategoryUpdateDTO categoryUpdateDTO;

    @BeforeEach
    void setup() {
        id = UUID.randomUUID();
        category = new Category();
        category.setId(id);
        category.setName("Test Category");

        categoryDTO = new CategoryDTO();
        categoryDTO.setId(id);
        categoryDTO.setName("Test Category");

        categoryCreateDTO = new CategoryCreateDTO("Test Category");

        categoryUpdateDTO = new CategoryUpdateDTO();
        categoryUpdateDTO.setId(id);
        categoryUpdateDTO.setName("Updated Category");
    }

    @Test
    @DisplayName("Should find category by id when everything is OK")
    void findByIdCase1() {
        when(categoryRepository.findById(id)).thenReturn(Optional.of(category));
        when(mapper.map(any(Category.class), eq(CategoryDTO.class))).thenReturn(categoryDTO);

        CategoryDTO result = categoryService.findById(id);

        assertThat(result).isNotNull();
        assertThat(result).isInstanceOf(CategoryDTO.class);
        assertThat(result.getId()).isEqualTo(id);

        verify(categoryRepository, times(1)).findById(any());
    }

    @Test
    @DisplayName("Should throw NotFoundException when id is invalid")
    void findByIdCase2() {
        NotFoundException thrown = assertThrows(NotFoundException.class, () -> categoryService.findById(UUID.randomUUID()));
        assertThat(thrown.getMessage()).isEqualTo("Nenhuma categoria encontrada para este id");

        verify(categoryRepository, times(1)).findById(any());
    }

    @Test
    @DisplayName("Should find all categories")
    void findAll() {
        List<Category> categories = new ArrayList<>(List.of(category));
        List<CategoryDTO> categoriesDTOs = new ArrayList<>(List.of(categoryDTO));

        when(categoryRepository.findAll()).thenReturn(categories);
        when(mapper.map(categories, CategoryDTO.class)).thenReturn(categoriesDTOs);

        List<CategoryDTO> result = categoryService.findAll();

        assertThat(result).isNotNull().isNotEmpty();
        assertThat(result.getFirst().getId()).isEqualTo(id);
        assertThat(result.size()).isEqualTo(1);

        verify(categoryRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Should find categories list")
    void findList() {
        List<CategoryProjection> projections = List.of(
                new CategoryProjection() {
                    public UUID getId() {
                        return id;
                    }

                    public String getName() {
                        return "Test Category";
                    }
                }
        );
        List<CategoryDTO> categoriesDTOs = new ArrayList<>(List.of(categoryDTO));

        when(categoryRepository.findByActiveTrue()).thenReturn(projections);
        when(mapper.map(projections, CategoryDTO.class)).thenReturn(categoriesDTOs);

        List<CategoryDTO> result = categoryService.findList();

        assertThat(result).isNotEmpty().isNotNull();
        assertThat(result.size()).isEqualTo(1);
        assertThat(result.getFirst().getId()).isEqualTo(id);

        verify(categoryRepository, times(1)).findByActiveTrue();
    }

    @Test
    @DisplayName("Should create a new category when everything is OK")
    void createCase1() {
        when(categoryRepository.findIdByName(categoryCreateDTO.getName())).thenReturn(Optional.empty());
        when(mapper.map(any(CategoryCreateDTO.class), eq(Category.class))).thenReturn(category);
        when(categoryRepository.save(category)).thenReturn(category);
        when(mapper.map(any(Category.class), eq(CategoryDTO.class))).thenReturn(categoryDTO);

        CategoryDTO result = categoryService.create(categoryCreateDTO);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(id);

        verify(categoryRepository, times(1)).findIdByName(categoryCreateDTO.getName());
        verify(categoryRepository, times(1)).save(category);
    }

    @Test
    @DisplayName("Should throw a RepeatedDataException when category name already exists")
    void createCase2() {
        when(categoryRepository.findIdByName(categoryCreateDTO.getName())).thenReturn(Optional.of(UUID.randomUUID()));

        RepeatedDataException thrown =
                assertThrows(RepeatedDataException.class, () -> categoryService.create(categoryCreateDTO));

        assertThat(thrown.getMessage()).isEqualTo("Essa categoria já existe");

        verify(categoryRepository, times(1)).findIdByName(categoryCreateDTO.getName());
    }

    @Test
    @DisplayName("Should update a category")
    void update() {
        when(categoryRepository.findById(id)).thenReturn(Optional.of(category));
        when(mapper.map(any(CategoryDTO.class), eq(Category.class))).thenReturn(category);
        when(categoryRepository.save(category)).thenReturn(category);
        when(mapper.map(any(Category.class), eq(CategoryDTO.class))).thenReturn(categoryDTO);

        CategoryDTO result = categoryService.update(categoryUpdateDTO);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(categoryDTO.getId());

        verify(categoryRepository, times(1)).findById(id);
        verify(categoryRepository, times(1)).save(category);
    }

    @Test
    @DisplayName("Should update category active status")
    void changeActive() {
        when(categoryRepository.findById(id)).thenReturn(Optional.of(category));
        when(mapper.map(any(CategoryDTO.class), eq(Category.class))).thenReturn(category);
        when(categoryRepository.save(category)).thenReturn(category);
        when(mapper.map(any(Category.class), eq(CategoryDTO.class))).thenReturn(categoryDTO);


        CategoryDTO result = categoryService.changeActive(id, false);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(id);
        assertThat(category.getActive()).isEqualTo(false);

        verify(categoryRepository, times(1)).save(category);
    }
}