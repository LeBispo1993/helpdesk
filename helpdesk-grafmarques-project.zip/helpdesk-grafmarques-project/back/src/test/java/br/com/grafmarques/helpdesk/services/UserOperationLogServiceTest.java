package br.com.grafmarques.helpdesk.services;

import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.UserOperationLogDTO;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.UserOperationLog;
import br.com.grafmarques.helpdesk.repositories.UserOperationLogRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserOperationLogServiceTest {

    @Autowired
    @InjectMocks
    private UserOperationLogService service;

    @Mock
    private UserOperationLogRepository repository;
    @Mock
    private Mapper mapper;

    @Test
    @DisplayName("Should register a new user operation log")
    void registerOperationLog() {
        UserOperationLog logEntity = Mockito.mock(UserOperationLog.class);
        UserDTO userDTO = Mockito.mock(UserDTO.class);
        when(mapper.map(any(UserOperationLogDTO.class), eq(UserOperationLog.class))).thenReturn(logEntity);
        when(repository.save(logEntity)).thenReturn(logEntity);

        service.registerOperationLog("Test Operation", "Test Details", userDTO);

        verify(repository, times(1)).save(logEntity);
    }
}