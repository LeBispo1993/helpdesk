package br.com.grafmarques.helpdesk.services.util;

import br.com.grafmarques.helpdesk.data.DTO.v1.util.Dates;
import br.com.grafmarques.helpdesk.exceptions.general.DateFilterException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class DateUtilTest {
    @Test
    @DisplayName("Test when 'startDate' and 'endDate' is null")
    void setDateFilterCase1() {
        Dates result = DateUtil.setDateFilter(null, null);
        LocalDate today = LocalDate.now();

        assertEquals(today.minusDays(7).atTime(0, 0, 0), result.getStartDate());
        assertEquals(today.atTime(23, 59, 59), result.getEndDate());
    }

    @Test
    @DisplayName("Test when everything is OK")
    void setDateFilterCase2() {
        LocalDate startDate = LocalDate.of(2023, 10, 10);
        LocalDate endDate = LocalDate.of(2023, 10, 15);

        Dates result = DateUtil.setDateFilter(startDate, endDate);

        assertEquals(LocalDateTime.of(2023, 10, 10, 0, 0, 0), result.getStartDate());
        assertEquals(LocalDateTime.of(2023, 10, 15, 23, 59, 59), result.getEndDate());
    }

    @Test
    @DisplayName("Should throw DateFilterException when 'endDate' is before 'startDate'")
    void setDateFilterCase3() {
        LocalDate startDate = LocalDate.of(2023, 10, 15);
        LocalDate endDate = LocalDate.of(2023, 10, 10);

        assertThrows(DateFilterException.class, () -> DateUtil.setDateFilter(startDate, endDate));
    }

    @Test
    @DisplayName("Test when only 'startDate' is null")
    void setDateFilterCase4() {
        LocalDate endDate = LocalDate.of(2023, 10, 15);

        Dates result = DateUtil.setDateFilter(null, endDate);

        assertEquals(endDate.minusDays(7).atTime(0, 0, 0), result.getStartDate());
        assertEquals(endDate.atTime(23, 59, 59), result.getEndDate());
    }

    @Test
    @DisplayName("Test when only 'endDate' is null")
    void setDateFilterCase5() {
        LocalDate startDate = LocalDate.of(2023, 10, 10);

        Dates result = DateUtil.setDateFilter(startDate, null);
        LocalDate today = LocalDate.now();

        assertEquals(startDate.atTime(0, 0, 0), result.getStartDate());
        assertEquals(today.atTime(23, 59, 59), result.getEndDate());
    }
}