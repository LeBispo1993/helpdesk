package br.com.grafmarques.helpdesk.services;

import br.com.grafmarques.helpdesk.data.DTO.v1.auth.RegisterDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.SectorDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.output.UserDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.update.UserUpdateDTO;
import br.com.grafmarques.helpdesk.data.DTO.v1.util.ChangePasswordDTO;
import br.com.grafmarques.helpdesk.exceptions.auth.EmailAlreadyInUseException;
import br.com.grafmarques.helpdesk.exceptions.auth.InactiveUserException;
import br.com.grafmarques.helpdesk.exceptions.auth.RegisterFirstAdminException;
import br.com.grafmarques.helpdesk.exceptions.auth.WrongPasswordException;
import br.com.grafmarques.helpdesk.exceptions.general.NotFoundException;
import br.com.grafmarques.helpdesk.exceptions.general.RepeatedDataException;
import br.com.grafmarques.helpdesk.exceptions.general.UnauthorizedException;
import br.com.grafmarques.helpdesk.mapper.Mapper;
import br.com.grafmarques.helpdesk.model.User;
import br.com.grafmarques.helpdesk.model.enums.Role;
import br.com.grafmarques.helpdesk.projections.SectorProjection;
import br.com.grafmarques.helpdesk.projections.UserProjection;
import br.com.grafmarques.helpdesk.repositories.UserRepository;
import br.com.grafmarques.helpdesk.services.auth.TokenService;
import br.com.grafmarques.helpdesk.services.email.EmailService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Autowired
    @InjectMocks
    private UserService service;

    @Mock
    private UserRepository repository;
    @Mock
    private SectorService sectorService;
    @Mock
    private TokenService tokenService;
    @Mock
    private UserOperationLogService userOperationLogService;
    @Mock
    private NotificationService notificationService;
    @Mock
    private EmailService emailService;
    @Mock
    private Mapper mapper;

    private UUID id;
    private String email;
    private User userEntity;
    private UserDTO userDTO;
    private RegisterDTO registerDTO;
    private SectorDTO sectorDTO;
    private UserUpdateDTO updateDTO;
    private UserProjection projection;
    private List<UserDTO> userDTOs;
    private List<UserProjection> projections;

    @BeforeEach
    void setup() {
        id = UUID.randomUUID();
        email = "user@email.com";

        userEntity = new User();
        userEntity.setEmail("");
        userEntity.setPassword("");
        userEntity.setName("");

        userDTO = new UserDTO();
        sectorDTO = new SectorDTO();
        sectorDTO.setName("");
        registerDTO = new RegisterDTO("", email, null, "12345678", sectorDTO);
        updateDTO = new UserUpdateDTO();
        updateDTO.setId(id);
        userDTOs = new ArrayList<>(List.of(userDTO));

        projection = new UserProjection() {
            @Override
            public UUID getId() {
                return id;
            }

            @Override
            public String getName() {
                return "";
            }

            @Override
            public String getEmail() {
                return "";
            }

            @Override
            public Role getRole() {
                return null;
            }

            @Override
            public SectorProjection getSector() {
                return null;
            }

            @Override
            public LocalDateTime getCreatedAt() {
                return null;
            }

            @Override
            public Boolean getActive() {
                return null;
            }
        };
        projections = new ArrayList<>(List.of(projection));
    }

    @Test
    @DisplayName("Should find user details by email")
    void findUserDetailsByEmail() {
        UserDetails userDetails = Mockito.mock(UserDetails.class);
        when(repository.findByEmail(email)).thenReturn(userDetails);

        UserDetails result = service.findUserDetailsByEmail(email);

        assertThat(result).isNotNull();

        verify(repository, times(1)).findByEmail(email);
    }

    @Test
    @DisplayName("Should find user by id when everything is OK")
    void findByIdCase1() {
        // Arrange
        when(repository.findById(id)).thenReturn(Optional.of(userEntity));
        when(mapper.map(any(User.class), eq(UserDTO.class))).thenReturn(userDTO);

        // Act
        UserDTO result = service.findById(id);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(userDTO.getId());

        // Verify
        verify(repository, times(1)).findById(id);
    }

    @Test
    @DisplayName("Should throw a NotFoundException when id is invalid")
    void findByIdCase2() {
        NotFoundException thrown = assertThrows(NotFoundException.class, () -> service.findById(UUID.randomUUID()));

        assertThat(thrown.getMessage()).isEqualTo("Nenhum usuário encontrado para este id");

        verify(repository, times(1)).findById(any());
    }

    @Test
    @DisplayName("Should find all users")
    void findAll() {
        // Arrange
        when(repository.findAllBy()).thenReturn(projections);
        when(mapper.map(projections, UserDTO.class)).thenReturn(userDTOs);

        // Act
        List<UserDTO> result = service.findAll();

        // Assert
        assertThat(result).isNotNull().isNotEmpty();
        assertThat(result.getFirst().getId()).isEqualTo(userDTOs.getFirst().getId());

        // Verify
        verify(repository, times(1)).findAllBy();
    }

    @Test
    @DisplayName("Should check activity status")
    void checkActiveCase1() {
        // Arrange
        when(repository.findActiveByEmail(email)).thenReturn(Optional.of(true));

        // Act
        service.checkActivity(email);

        // Verify
        verify(repository, times(1)).findActiveByEmail(email);
    }

    @Test
    @DisplayName("Should throw NotFoundException when id is invalid")
    void checkActiveCase2() {
        // Arrange
        NotFoundException thrown = assertThrows(NotFoundException.class, () -> service.checkActivity(email));

        assertThat(thrown.getMessage()).isEqualTo("Nenhum usuário encontrado para este e-mail");

        verify(repository, times(1)).findActiveByEmail(email);
    }

    @Test
    @DisplayName("Should throw InactiveUserException when user field active is false")
    void checkActiveCase3() {
        // Arrange
        when(repository.findActiveByEmail(email)).thenReturn(Optional.of(false));
        InactiveUserException thrown = assertThrows(InactiveUserException.class, () -> service.checkActivity(email));

        assertThat(thrown.getMessage()).isEqualTo("Usuário inativo");

        verify(repository, times(1)).findActiveByEmail(email);
    }

    @Test
    @DisplayName("Should register a new user when everything is OK")
    void registerCase1() {
        // Arrange
        when(repository.findIdByEmail(email)).thenReturn(Optional.empty());
        when(mapper.map(any(RegisterDTO.class), eq(User.class))).thenReturn(userEntity);
        when(repository.save(userEntity)).thenReturn(userEntity);
        when(mapper.map(any(User.class), eq(UserDTO.class))).thenReturn(userDTO);

        // Act
        UserDTO result = service.register(registerDTO);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(userDTO.getId());

        // Verify
        verify(repository, times(1)).findIdByEmail(email);
        verify(repository, times(1)).save(userEntity);
        verify(userOperationLogService, times(1))
                .registerOperationLog(
                        "Registration",
                        "User registration completed successfully",
                        userDTO
                );
        verify(notificationService, times(1))
                .create(
                        "Seja bem-vindo!",
                        userDTO,
                        null
                );
    }

    @Test
    @DisplayName("Should throw EmailAlreadyInUseException when email already in use")
    void registerCase2() {
        when(repository.findIdByEmail(email)).thenReturn(Optional.of(UUID.randomUUID()));
        EmailAlreadyInUseException thrown = assertThrows(EmailAlreadyInUseException.class, () -> service.register(registerDTO));

        // Assert
        assertThat(thrown.getMessage()).isEqualTo("Este e-mail já está em uso");

        // Verify
        verify(repository, times(1)).findIdByEmail(email);
    }

    @Test
    @DisplayName("Should register first admin when every thing is OK")
    void registerFirstAdminCase1() {
        // Arrange
        when(repository.countUserIdByRoleAndActive(Role.ADMIN, true)).thenReturn(0L);
        when(sectorService.findByName(registerDTO.getSector().getName().trim())).thenReturn(sectorDTO);
        when(repository.findIdByEmail(email)).thenReturn(Optional.empty());
        when(mapper.map(any(RegisterDTO.class), eq(User.class))).thenReturn(userEntity);
        when(repository.save(userEntity)).thenReturn(userEntity);
        when(mapper.map(any(User.class), eq(UserDTO.class))).thenReturn(userDTO);

        // Act
        UserDTO result = service.registerFirstAdmin(registerDTO);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(userDTO.getId());

        // Verify
        verify(repository, times(1)).countUserIdByRoleAndActive(Role.ADMIN, true);
        verify(sectorService, times(1)).findByName(registerDTO.getSector().getName());
        verify(repository, times(1)).findIdByEmail(email);
        verify(repository, times(1)).save(userEntity);
        verify(userOperationLogService, times(1))
                .registerOperationLog(
                        "Registration",
                        "User registration completed successfully",
                        userDTO
                );
        verify(notificationService, times(1))
                .create(
                        "Seja bem-vindo!",
                        userDTO,
                        null
                );
    }

    @Test
    @DisplayName("Should throw RegisterFirstAdminException when already exists admin(s) user(s)")
    void registerFirstAdminCase2() {
        when(repository.countUserIdByRoleAndActive(Role.ADMIN, true)).thenReturn(1L);

        RegisterFirstAdminException thrown = assertThrows(RegisterFirstAdminException.class, () -> service.registerFirstAdmin(registerDTO));

        assertThat(thrown.getMessage()).isEqualTo("Já existem usuários administradores");

        verify(repository, times(1)).countUserIdByRoleAndActive(Role.ADMIN, true);
    }

    @Test
    @DisplayName("Should update user when every thing is OK")
    void updateCase1() {
        // Arrange
        when(repository.findById(updateDTO.getId())).thenReturn(Optional.of(userEntity));
        when(repository.save(userEntity)).thenReturn(userEntity);
        when(mapper.map(any(User.class), eq(UserDTO.class))).thenReturn(userDTO);

        // Act
        UserDTO result = service.update(updateDTO);

        // Assert
        assertThat(result).isNotNull();

        // verify
        verify(repository, times(1)).findById(id);
        verify(repository, times(1)).save(userEntity);
        verify(userOperationLogService, times(1))
                .registerOperationLog(
                        "Update",
                        "User updated successfully. Field(s): ",
                        userDTO
                );
        verify(notificationService, times(1))
                .create(
                        "Alguns de seus dados foram alterados. Contate o administrador para mais informações",
                        userDTO,
                        null
                );
    }

    @Test
    @DisplayName("Should throw NotFoundException in updating when id is invalid")
    void updateCase2() {
        when(repository.findById(any())).thenReturn(Optional.empty());

        NotFoundException thrown = assertThrows(NotFoundException.class, () -> service.update(updateDTO));

        assertThat(thrown.getMessage()).isEqualTo("Nenhum usuário encontrado para este id");

        verify(repository, times(1)).findById(any());
    }

    @Test
    @DisplayName("Should change user activity when everything is OK")
    void changeActiveCase1() {
        // Arrange
        when(repository.findById(id)).thenReturn(Optional.of(userEntity));
        when(tokenService.getUserId()).thenReturn(UUID.randomUUID());
        when(repository.save(userEntity)).thenReturn(userEntity);
        when(mapper.map(any(User.class), eq(UserDTO.class))).thenReturn(userDTO);

        // Act
        UserDTO result = service.changeActive(id, false);

        // Assert
        assertThat(result).isNotNull();

        // verify
        verify(repository, times(1)).findById(id);
        verify(tokenService, times(1)).getUserId();
        verify(repository, times(1)).save(userEntity);
        verify(userOperationLogService, times(1))
                .registerOperationLog(
                        "Change of activity",
                        "User activity changed with successfully to " + false + " value",
                        userDTO
                );
    }

    @Test
    @DisplayName("Should throw UnauthorizedException when try change the activity itself")
    void changeActiveCase2() {
        // Arrange
        when(repository.findById(id)).thenReturn(Optional.of(userEntity));
        when(tokenService.getUserId()).thenReturn(id);

        // Act
        UnauthorizedException thrown = assertThrows(UnauthorizedException.class, () -> service.changeActive(id, false));

        // Assert
        assertThat(thrown.getMessage()).isEqualTo("Não é possível desativar sua própria conta");

        // verify
        verify(repository, times(1)).findById(id);
        verify(tokenService, times(1)).getUserId();
    }

    @Test
    @DisplayName("Should throw NotFoundException in change active active when id is invalid")
    void changeActiveCase3() {
        when(repository.findById(any())).thenReturn(Optional.empty());

        NotFoundException thrown = assertThrows(NotFoundException.class, () -> service.changeActive(any(), false));

        assertThat(thrown.getMessage()).isEqualTo("Nenhum usuário encontrado para este id");

        verify(repository, times(1)).findById(any());
    }

    @Test
    @DisplayName("Should change user password when everything is OK")
    void changePasswordCase1() {
        ChangePasswordDTO passwords = new ChangePasswordDTO("oldPassword", "newPassword");
        userEntity.setPassword(new BCryptPasswordEncoder().encode("oldPassword"));
        when(repository.findById(id)).thenReturn(Optional.of(userEntity));
        when(repository.save(userEntity)).thenReturn(userEntity);
        when(mapper.map(any(User.class), eq(UserDTO.class))).thenReturn(userDTO);

        UserDTO result = service.changePassword(id, passwords);

        assertThat(result).isNotNull();

        verify(repository, times(1)).findById(id);
        verify(repository, times(1)).save(userEntity);
        verify(userOperationLogService, times(1))
                .registerOperationLog(
                        "Change of password",
                        "User password changed successfully",
                        userDTO
                );
        verify(notificationService, times(1))
                .create(
                        "Sua senha foi alterada",
                        userDTO,
                        null
                );
    }

    @Test
    @DisplayName("Should throw RepeatedDataException when passwords are the same")
    void changePasswordCase2() {
        ChangePasswordDTO passwords = new ChangePasswordDTO("samePassword", "samePassword");

        RepeatedDataException thrown = assertThrows(RepeatedDataException.class, () -> service.changePassword(id, passwords));

        assertThat(thrown.getMessage()).isEqualTo("As senhas são iguais");
    }


    @Test
    @DisplayName("Should throw NotFoundException in change password active when id is invalid")
    void changePasswordCase3() {
        ChangePasswordDTO changePassword = new ChangePasswordDTO("oldPassword", "newPassword");
        when(repository.findById(any())).thenReturn(Optional.empty());

        NotFoundException thrown = assertThrows(NotFoundException.class, () -> service.changePassword(any(), changePassword));

        assertThat(thrown.getMessage()).isEqualTo("Nenhum usuário encontrado para este id");

        verify(repository, times(1)).findById(any());
    }

    @Test
    @DisplayName("Should throw WrongPasswordException in change password active when id is invalid")
    void changePasswordCase4() {
        ChangePasswordDTO changePassword = new ChangePasswordDTO("wrongPassword", "newPassword");
        when(repository.findById(id)).thenReturn(Optional.of(userEntity));
        userEntity.setPassword(new BCryptPasswordEncoder().encode("correctPassword"));

        WrongPasswordException thrown = assertThrows(WrongPasswordException.class, () -> service.changePassword(id, changePassword));

        assertThat(thrown.getMessage()).isEqualTo("Senha incorreta");

        verify(repository, times(1)).findById(id);
    }

    @Test
    void sendPasswordRecoveryEmail() {

    }

    @Test
    void recoverPassword() {

    }
}